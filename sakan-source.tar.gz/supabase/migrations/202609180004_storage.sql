-- Supabase Storage only. Test harness provisions the same minimal tables for policy checks.
begin;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values
 ('unit-images','unit-images',true,10485760,array['image/jpeg','image/png','image/webp']),
 ('operations','operations',false,10485760,array['image/jpeg','image/png','image/webp']) on conflict(id) do nothing;
create policy unit_image_upload on storage.objects for insert to authenticated with check(bucket_id='unit-images' and public.has_permission('catalog.write'));
create policy unit_image_update on storage.objects for update to authenticated using(bucket_id='unit-images' and public.has_permission('catalog.write')) with check(bucket_id='unit-images' and public.has_permission('catalog.write'));
create policy unit_image_delete on storage.objects for delete to authenticated using(bucket_id='unit-images' and public.has_permission('catalog.write'));
create policy operations_files on storage.objects for all to authenticated using(bucket_id='operations' and public.has_permission('operations.write')) with check(bucket_id='operations' and public.has_permission('operations.write'));
commit;
