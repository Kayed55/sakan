begin;
create function public.set_cover_image(p_image uuid) returns void language plpgsql security definer set search_path='' as $$
declare u uuid;
begin
 if not public.has_permission('catalog.write') then raise exception 'FORBIDDEN'; end if;
 select unit_id into u from public.unit_images where id=p_image;
 if u is null then raise exception 'IMAGE_NOT_FOUND'; end if;
 perform 1 from public.units where id=u for update;
 update public.unit_images set is_cover=false where unit_id=u and is_cover;
 update public.unit_images set is_cover=true,sort_order=0 where id=p_image;
end $$;
create function public.moderate_review(p_review uuid,p_publish boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.has_permission('content.write') then raise exception 'FORBIDDEN'; end if;
 update public.reviews set published=p_publish where id=p_review;
 if not found then raise exception 'REVIEW_NOT_FOUND'; end if;
end $$;
create function public.resolve_support(p_request uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.has_permission('customer.read') then raise exception 'FORBIDDEN'; end if;
 update public.support_requests set status='resolved' where id=p_request and kind<>'account_deletion';
 if not found then raise exception 'REQUEST_REQUIRES_SPECIAL_HANDLING'; end if;
end $$;
create trigger audit_reviews after update on public.reviews for each row execute function private.audit_change();
create trigger audit_support after update on public.support_requests for each row execute function private.audit_change();
revoke execute on function public.set_cover_image(uuid),public.moderate_review(uuid,boolean),public.resolve_support(uuid) from public,anon,authenticated;
grant execute on function public.set_cover_image(uuid),public.moderate_review(uuid,boolean),public.resolve_support(uuid) to authenticated;
commit;
