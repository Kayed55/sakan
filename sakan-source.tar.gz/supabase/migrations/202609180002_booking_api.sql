begin;
create function private.expire_holds(p_unit uuid) returns void language plpgsql set search_path='' as $$
begin
 update public.bookings set status='expired' where unit_id=p_unit and status='hold' and hold_expires_at<=now();
 delete from public.inventory_locks where unit_id=p_unit and kind='hold' and expires_at<=now();
end $$;
create function public.quote_stay(p_unit uuid,p_check_in date,p_check_out date,p_guests int,p_coupon text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare u public.units; c public.coupons; cfg jsonb; subtotal int; fee int; discount int:=0; tax int; lines jsonb; city uuid; minimum_nights int;
begin
 if p_check_in is null or p_check_out is null or p_guests is null or p_check_in<(now() at time zone 'Asia/Riyadh')::date or p_check_out<=p_check_in or p_check_out-p_check_in>60 or p_guests<1 then raise exception 'INVALID_STAY'; end if;
 select * into u from public.units where id=p_unit and status='published';
 select d.city_id into city from public.properties p join public.districts d on d.id=p.district_id join public.cities city_row on city_row.id=d.city_id where p.id=u.property_id and p.is_active and city_row.is_active;
 if u.id is null or city is null then raise exception 'UNIT_UNAVAILABLE'; end if;
 if p_guests>u.capacity then raise exception 'CAPACITY_EXCEEDED'; end if;
 select sum(coalesce(r.price,u.base_price))::int,max(greatest(coalesce(r.min_nights,1),u.min_nights)),
 jsonb_agg(jsonb_build_object('day',s.day::date,'price',coalesce(r.price,u.base_price)) order by s.day)
 into subtotal,minimum_nights,lines from generate_series(p_check_in::timestamp,(p_check_out-1)::timestamp,'1 day') s(day)
 left join public.unit_rates r on r.unit_id=p_unit and r.day=s.day::date;
 if p_check_out-p_check_in<minimum_nights then raise exception 'MINIMUM_NIGHTS'; end if;
 select value into cfg from public.settings where key='booking';
 fee:=coalesce((cfg->>'service_fee')::int,0);
 if nullif(trim(p_coupon),'') is not null then
 select * into c from public.coupons where code=upper(trim(p_coupon)) and is_active and now() between starts_at and ends_at;
 if c.id is null or auth.uid() is null or subtotal<c.minimum or (c.unit_id is not null and c.unit_id<>p_unit) or (c.city_id is not null and c.city_id<>city) then raise exception 'INVALID_COUPON'; end if;
 if (select count(*) from public.bookings where coupon_id=c.id and (status in ('confirmed','checked_in','completed') or (status='hold' and hold_expires_at>now())))>=c.max_uses then raise exception 'COUPON_EXHAUSTED'; end if;
 if (select count(*) from public.bookings where coupon_id=c.id and customer_id=auth.uid() and (status in ('confirmed','checked_in','completed') or (status='hold' and hold_expires_at>now())))>=c.per_customer then raise exception 'COUPON_CUSTOMER_LIMIT'; end if;
 discount:=least(c.max_discount,(subtotal::bigint*c.percent/100)::int);
 end if;
 tax:=round((subtotal+fee-discount)::numeric*coalesce((cfg->>'tax_basis_points')::int,0)/10000)::int;
 return jsonb_build_object('subtotal',subtotal,'service_fee',fee,'discount',discount,'tax',tax,'total',subtotal+fee-discount+tax,'currency','SAR','nights',lines,'coupon_id',c.id,'coupon_code',c.code);
end $$;
create function public.search_units(p_check_in date,p_check_out date,p_guests int default 1)
returns setof public.units language plpgsql security definer set search_path='' as $$
begin
 if p_check_in is null or p_check_out is null or p_guests is null or p_check_in<(now() at time zone 'Asia/Riyadh')::date or p_check_out<=p_check_in or p_check_out-p_check_in>60 or p_guests<1 then raise exception 'INVALID_STAY'; end if;
 return query select u.* from public.units u join public.properties p on p.id=u.property_id join public.districts d on d.id=p.district_id join public.cities c on c.id=d.city_id
 where u.status='published' and p.is_active and c.is_active and u.capacity>=p_guests and u.min_nights<=p_check_out-p_check_in
 and not exists(select 1 from public.unit_rates r where r.unit_id=u.id and r.day>=p_check_in and r.day<p_check_out and r.min_nights>p_check_out-p_check_in)
 and not exists(select 1 from public.inventory_locks l where l.unit_id=u.id and l.stay&&daterange(p_check_in,p_check_out,'[)') and (l.kind<>'hold' or l.expires_at>now())) order by u.base_price;
end $$;
create function public.create_booking_hold(p_unit uuid,p_check_in date,p_check_out date,p_guests int,p_request_key uuid,p_coupon text default null)
returns public.bookings language plpgsql security definer set search_path='' as $$
declare q jsonb; b public.bookings; minutes int;
begin
 if not exists(select 1 from public.profiles where id=auth.uid() and status='active') then raise exception 'AUTH_REQUIRED'; end if;
 perform 1 from public.profiles where id=auth.uid() for update;
 if p_request_key is null then raise exception 'REQUEST_KEY_REQUIRED'; end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text||p_request_key::text,0));
 select * into b from public.bookings where customer_id=auth.uid() and request_key=p_request_key;
 if b.id is not null then
 if b.unit_id<>p_unit or b.check_in<>p_check_in or b.check_out<>p_check_out or b.guests_count<>p_guests or coalesce(b.price_snapshot->>'coupon_code','')<>upper(trim(coalesce(p_coupon,''))) then raise exception 'IDEMPOTENCY_CONFLICT'; end if;
 return b; end if;
 perform 1 from public.units where id=p_unit for update;
 perform private.expire_holds(p_unit);
 if (select count(*) from public.bookings where customer_id=auth.uid() and status='hold' and hold_expires_at>now())>=3 then raise exception 'TOO_MANY_HOLDS'; end if;
 if nullif(trim(p_coupon),'') is not null then perform 1 from public.coupons where code=upper(trim(p_coupon)) for update; end if;
 q:=public.quote_stay(p_unit,p_check_in,p_check_out,p_guests,p_coupon);
 select greatest(1,least(30,(value->>'hold_minutes')::int)) into minutes from public.settings where key='booking';
 insert into public.bookings(customer_id,unit_id,check_in,check_out,guests_count,hold_expires_at,subtotal,service_fee,discount,tax,total,coupon_id,price_snapshot,request_key)
 values(auth.uid(),p_unit,p_check_in,p_check_out,p_guests,now()+make_interval(mins=>coalesce(minutes,10)),(q->>'subtotal')::int,(q->>'service_fee')::int,(q->>'discount')::int,(q->>'tax')::int,(q->>'total')::int,(q->>'coupon_id')::uuid,q,p_request_key) returning * into b;
 insert into public.inventory_locks(unit_id,booking_id,stay,kind,expires_at) values(p_unit,b.id,daterange(p_check_in,p_check_out,'[)'),'hold',b.hold_expires_at);
 return b;
 exception when exclusion_violation then raise exception 'DATES_UNAVAILABLE';
end $$;
create function public.set_booking_guest(p_booking uuid,p_name text,p_phone text,p_email text default null) returns void language plpgsql security definer set search_path='' as $$
begin
 if length(trim(p_name))<2 or p_phone!~'^\+9665[0-9]{8}$' then raise exception 'INVALID_GUEST'; end if;
 perform 1 from public.bookings where id=p_booking and customer_id=auth.uid() and status='hold' and hold_expires_at>now() for update;
 if not found then raise exception 'BOOKING_UNAVAILABLE'; end if;
 insert into public.booking_guests(booking_id,full_name,phone,email,is_primary) values(p_booking,trim(p_name),p_phone,nullif(p_email,''),true)
 on conflict(booking_id) where is_primary do update set full_name=excluded.full_name,phone=excluded.phone,email=excluded.email;
end $$;
-- Called ONLY from a verified server payment adapter. No client execution grant.
create function public.record_verified_payment(p_event text,p_booking uuid,p_provider text,p_provider_id text,p_amount int,p_currency text)
returns text language plpgsql security definer set search_path='' as $$
declare b public.bookings; p public.payments; u uuid;
begin
 select unit_id into u from public.bookings where id=p_booking;
 perform 1 from public.units where id=u for update;
 select * into b from public.bookings where id=p_booking for update;
 if b.id is null or p_amount<>b.total or p_currency<>b.currency then raise exception 'PAYMENT_MISMATCH'; end if;
 if exists(select 1 from public.payment_events where id=p_event) then return 'duplicate'; end if;
 select * into p from public.payments where provider_id=p_provider_id;
 if p.id is not null then
 if p.booking_id<>b.id or p.amount<>p_amount then raise exception 'PAYMENT_MISMATCH'; end if;
 insert into public.payment_events(id,payment_id) values(p_event,p.id); return 'duplicate'; end if;
 insert into public.payments(booking_id,provider,provider_id,amount,currency,status) values(b.id,p_provider,p_provider_id,p_amount,p_currency,'pending') returning * into p;
 insert into public.payment_events(id,payment_id) values(p_event,p.id);
 if b.status<>'hold' or b.hold_expires_at<=now() or not exists(select 1 from public.inventory_locks where booking_id=b.id) then
 update public.payments set status='refund_required' where id=p.id;
 insert into public.refunds(booking_id,payment_id,amount,reason) values(b.id,p.id,p_amount,'Late or duplicate payment: reservation cannot be confirmed');
 perform private.expire_holds(u); return 'refund_required'; end if;
 if not exists(select 1 from public.booking_guests where booking_id=b.id and is_primary) then raise exception 'GUEST_REQUIRED'; end if;
 update public.payments set status='paid' where id=p.id;
 update public.bookings set status='confirmed' where id=b.id;
 update public.inventory_locks set kind='booking',expires_at=null where booking_id=b.id;
 insert into public.notifications(customer_id,title,body,booking_id) values(b.customer_id,'تم تأكيد حجزك',b.booking_number,b.id);
 return 'confirmed';
end $$;
create function public.cancel_booking(p_booking uuid) returns void language plpgsql security definer set search_path='' as $$
declare b public.bookings; u uuid;
begin
 select unit_id into u from public.bookings where id=p_booking;
 perform 1 from public.units where id=u for update;
 select * into b from public.bookings where id=p_booking for update;
 if b.id is null or not (b.customer_id=auth.uid() or public.has_permission('booking.cancel')) then raise exception 'FORBIDDEN'; end if;
 if b.status='cancelled' then return; end if;
 if b.status='hold' then
 update public.bookings set status='cancelled' where id=b.id; delete from public.inventory_locks where booking_id=b.id;
 elsif b.status='confirmed' then
 insert into public.support_requests(customer_id,booking_id,kind,message) values(b.customer_id,b.id,'cancellation','طلب إلغاء يحتاج مراجعة سياسة الإلغاء والاسترداد');
 else raise exception 'CANNOT_CANCEL'; end if;
end $$;
create function public.booking_access(p_booking uuid) returns jsonb language plpgsql security definer set search_path='' as $$
declare result jsonb;
begin
 select jsonb_build_object('instructions',a.instructions,'entry_code',a.entry_code,'address',p.address,'latitude',p.latitude,'longitude',p.longitude)
 into result from public.access_instructions a join public.bookings b on b.id=a.booking_id join public.units u on u.id=b.unit_id join public.property_private p on p.property_id=u.property_id
 where b.id=p_booking and b.customer_id=auth.uid() and b.status in ('confirmed','checked_in') and now()>=a.release_at and now()<a.expires_at
 and exists(select 1 from public.payments x where x.booking_id=b.id and x.status='paid');
 if result is not null then insert into public.audit_logs(actor_id,table_name,record_id,action) values(auth.uid(),'access_instructions',p_booking::text,'READ'); end if;
 return result;
end $$;
create function public.block_unit(p_unit uuid,p_from date,p_to date,p_reason text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if not public.has_permission('catalog.write') then raise exception 'FORBIDDEN'; end if;
 if p_to<=p_from then raise exception 'INVALID_STAY'; end if;
 perform 1 from public.units where id=p_unit for update;
 perform private.expire_holds(p_unit);
 insert into public.inventory_locks(unit_id,stay,kind,reason) values(p_unit,daterange(p_from,p_to,'[)'),'blocked',p_reason) returning id into result;
 return result;
end $$;
create function public.transition_booking(p_booking uuid,p_status text) returns void language plpgsql security definer set search_path='' as $$
declare b public.bookings;
begin
 if not public.has_permission('operations.write') then raise exception 'FORBIDDEN'; end if;
 select * into b from public.bookings where id=p_booking for update;
 if not ((b.status='confirmed' and p_status='checked_in' and b.check_in<=(now() at time zone 'Asia/Riyadh')::date) or (b.status='checked_in' and p_status='completed')) then raise exception 'INVALID_TRANSITION'; end if;
 update public.bookings set status=p_status where id=b.id;
 if p_status='completed' then
 insert into public.operations_tasks(unit_id,booking_id,kind,due_at) values(b.unit_id,b.id,'cleaning',now());
 insert into public.notifications(customer_id,title,body,booking_id) values(b.customer_id,'كيف كانت إقامتك؟','شاركنا تقييم إقامتك',b.id);
 end if;
end $$;
create function public.update_assigned_task(p_task uuid,p_status text,p_checklist jsonb) returns void language plpgsql security definer set search_path='' as $$
begin
 if p_status not in ('in_progress','inspection') then raise exception 'INVALID_TRANSITION'; end if;
 update public.operations_tasks set status=p_status,checklist=p_checklist where id=p_task and assigned_to=auth.uid() and public.has_permission('tasks.assigned') and status in ('assigned','in_progress');
 if not found then raise exception 'FORBIDDEN'; end if;
end $$;
create function private.maintenance_guard() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.blocks_sale and new.status<>'resolved' then update public.units set status='maintenance' where id=new.unit_id; end if;
 -- Resolution never republishes automatically: supervisor must inspect and republish.
 return new;
end $$;
create trigger maintenance_guard after insert or update on public.maintenance_requests for each row execute function private.maintenance_guard();
create function private.enqueue_notification() returns trigger language plpgsql security definer set search_path='' as $$
begin insert into public.notification_outbox(notification_id) values(new.id); return new; end $$;
create trigger enqueue_notification after insert on public.notifications for each row execute function private.enqueue_notification();
-- Function execution is opt-in, including every SECURITY DEFINER endpoint.
revoke execute on all functions in schema public from public,anon,authenticated;
revoke execute on all functions in schema private from public,anon,authenticated;
grant execute on function public.has_permission(text),public.search_units(date,date,int),public.quote_stay(uuid,date,date,int,text) to anon,authenticated;
grant execute on function public.create_booking_hold(uuid,date,date,int,uuid,text),public.set_booking_guest(uuid,text,text,text),public.cancel_booking(uuid),public.booking_access(uuid),public.block_unit(uuid,date,date,text),public.transition_booking(uuid,text),public.update_assigned_task(uuid,text,jsonb) to authenticated;
grant execute on function public.record_verified_payment(text,uuid,text,text,int,text) to service_role;
grant all on all tables in schema public to service_role;
grant usage,select on all sequences in schema public to service_role;
commit;
