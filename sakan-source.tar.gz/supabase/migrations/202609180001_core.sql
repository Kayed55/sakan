begin;
create extension if not exists btree_gist;
create schema if not exists private;
revoke all on schema private from public;

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', email text, status text not null default 'active' check(status in ('active','suspended')),
 created_at timestamptz not null default now()
);
create table public.roles (id text primary key);
insert into public.roles values ('super_admin'),('operations'),('customer_service'),('accountant'),('staff');
create table public.role_permissions (role_id text references public.roles(id), permission text, primary key(role_id, permission));
insert into public.role_permissions values
 ('operations','catalog.write'),('operations','booking.read'),('operations','operations.write'),('operations','reports.read'),
 ('customer_service','booking.read'),('customer_service','customer.read'),('customer_service','booking.cancel'),
 ('accountant','finance.read'),('accountant','finance.refund'),('accountant','reports.read'),('staff','tasks.assigned');
create table public.user_roles(user_id uuid references public.profiles(id) on delete cascade, role_id text references public.roles(id), primary key(user_id,role_id));
create function public.has_permission(p_permission text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.user_roles r join public.profiles p on p.id=r.user_id
 where r.user_id=auth.uid() and p.status='active' and (r.role_id='super_admin' or exists
 (select 1 from public.role_permissions rp where rp.role_id=r.role_id and rp.permission=p_permission)))
$$;
create function private.new_profile() returns trigger language plpgsql security definer set search_path='' as $$
begin insert into public.profiles(id) values(new.id); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function private.new_profile();

create table public.regions(id uuid primary key default gen_random_uuid(), name_ar text not null, name_en text not null, code text unique not null);
create table public.cities(id uuid primary key default gen_random_uuid(), region_id uuid not null references public.regions, name_ar text not null,name_en text not null,is_active boolean not null default false);
create table public.districts(id uuid primary key default gen_random_uuid(),city_id uuid not null references public.cities,name_ar text not null,name_en text not null);
create table public.properties(id uuid primary key default gen_random_uuid(), district_id uuid not null references public.districts,
 code text unique not null,name_ar text not null,name_en text not null, approx_lat numeric not null,approx_lng numeric not null,
 check_in_time time not null default '16:00',check_out_time time not null default '12:00',is_active boolean not null default true);
create table public.property_private(property_id uuid primary key references public.properties on delete cascade,address text not null,latitude numeric,longitude numeric);
create table public.units(id uuid primary key default gen_random_uuid(),property_id uuid not null references public.properties,
 code text unique not null,name_ar text not null,name_en text not null,description_ar text not null default '',description_en text not null default '',
 kind text not null check(kind in ('studio','apartment')),capacity int not null check(capacity>0),bedrooms int not null default 0 check(bedrooms>=0),
 beds int not null default 1 check(beds>0),bathrooms int not null default 1 check(bathrooms>0),area int check(area>0),
 base_price int not null check(base_price>0),min_nights int not null default 1 check(min_nights>0),
 status text not null default 'draft' check(status in ('draft','published','hidden','maintenance')),
 rules_ar text not null default 'يمنع التدخين والحفلات',rules_en text not null default 'No smoking or parties',created_at timestamptz not null default now());
create table public.unit_images(id uuid primary key default gen_random_uuid(),unit_id uuid not null references public.units on delete cascade,image_url text not null,sort_order int not null default 0,is_cover boolean not null default false);
create unique index unit_cover on public.unit_images(unit_id) where is_cover;
create table public.amenities(id text primary key,name_ar text not null,name_en text not null);
create table public.unit_amenities(unit_id uuid references public.units on delete cascade,amenity_id text references public.amenities,primary key(unit_id,amenity_id));
create table public.unit_rates(unit_id uuid references public.units on delete cascade,day date,price int not null check(price>0),min_nights int not null default 1 check(min_nights>0),primary key(unit_id,day));
create table public.settings(key text primary key,value jsonb not null);
insert into public.settings values('booking','{"hold_minutes":10,"service_fee":0,"tax_basis_points":0,"access_hours_before":2}');
create table public.coupons(id uuid primary key default gen_random_uuid(),code text unique not null check(code=upper(code)),
 percent int not null check(percent between 1 and 100),max_discount int not null check(max_discount>0),minimum int not null default 0 check(minimum>=0),
 starts_at timestamptz not null,ends_at timestamptz not null, max_uses int not null check(max_uses>0),per_customer int not null default 1 check(per_customer>0),
 city_id uuid references public.cities,unit_id uuid references public.units,is_active boolean not null default true,check(ends_at>starts_at));
create sequence public.booking_number_seq start 100001;
create table public.bookings(id uuid primary key default gen_random_uuid(),booking_number text unique not null default ('SKN-'||nextval('public.booking_number_seq')),
 customer_id uuid not null references public.profiles,unit_id uuid not null references public.units,check_in date not null,check_out date not null,
 guests_count int not null check(guests_count>0),nights int generated always as(check_out-check_in) stored,
 status text not null default 'hold' check(status in ('hold','confirmed','checked_in','completed','cancelled','expired')),
 hold_expires_at timestamptz not null,subtotal int not null check(subtotal>=0),service_fee int not null check(service_fee>=0),
 discount int not null check(discount>=0),tax int not null check(tax>=0),total int not null check(total>=0),currency text not null default 'SAR' check(currency='SAR'),
 coupon_id uuid references public.coupons,price_snapshot jsonb not null,request_key uuid not null,
 created_at timestamptz not null default now(),unique(customer_id,request_key),check(check_out>check_in),check(total=subtotal+service_fee-discount+tax));
-- Single inventory ledger for holds, bookings AND administrative blocks.
create table public.inventory_locks(id uuid primary key default gen_random_uuid(),unit_id uuid not null references public.units,
 booking_id uuid unique references public.bookings,stay daterange not null,kind text not null check(kind in ('hold','booking','blocked','maintenance')),
 expires_at timestamptz,reason text,check(not isempty(stay) and lower(stay) is not null and upper(stay) is not null),
 exclude using gist(unit_id with =,stay with &&));
create index booking_customer on public.bookings(customer_id,created_at desc);
create table public.booking_guests(id uuid primary key default gen_random_uuid(),booking_id uuid not null references public.bookings on delete cascade,
 full_name text not null,phone text,email text,is_primary boolean not null default false);
create unique index one_primary_guest on public.booking_guests(booking_id) where is_primary;
create table public.payments(id uuid primary key default gen_random_uuid(),booking_id uuid not null references public.bookings,
 provider text not null,provider_id text unique,amount int not null check(amount>0),currency text not null default 'SAR' check(currency='SAR'),
 status text not null default 'pending' check(status in ('pending','paid','failed','refund_required','refunded','partially_refunded')),
 created_at timestamptz not null default now());
create unique index one_paid_payment on public.payments(booking_id) where status in ('paid','partially_refunded','refunded');
create table public.payment_events(id text primary key,payment_id uuid references public.payments,created_at timestamptz not null default now());
create table public.refunds(id uuid primary key default gen_random_uuid(),booking_id uuid not null references public.bookings,payment_id uuid not null references public.payments,
 amount int not null check(amount>0),reason text not null,status text not null default 'requested' check(status in ('requested','approved','processing','paid','rejected','failed')),
 approved_by uuid references public.profiles,provider_id text unique,created_at timestamptz not null default now());
create table public.reviews(id uuid primary key default gen_random_uuid(),booking_id uuid unique not null references public.bookings,
 customer_id uuid not null references public.profiles,unit_id uuid not null references public.units,rating int not null check(rating between 1 and 5),
 comment text not null default '',published boolean not null default false,created_at timestamptz not null default now());
create table public.favorites(customer_id uuid references public.profiles on delete cascade,unit_id uuid references public.units on delete cascade,primary key(customer_id,unit_id));
create table public.notifications(id uuid primary key default gen_random_uuid(),customer_id uuid not null references public.profiles,
 title text not null,body text not null,booking_id uuid references public.bookings,read_at timestamptz,created_at timestamptz not null default now());
create table public.device_tokens(id uuid primary key default gen_random_uuid(),customer_id uuid not null references public.profiles on delete cascade,token text unique not null,platform text not null);
create table public.notification_outbox(id uuid primary key default gen_random_uuid(),notification_id uuid unique references public.notifications,status text not null default 'pending',attempts int not null default 0,next_attempt_at timestamptz not null default now());
create table public.operations_tasks(id uuid primary key default gen_random_uuid(),unit_id uuid not null references public.units,booking_id uuid references public.bookings,
 kind text not null check(kind in ('cleaning','inspection','maintenance')),status text not null default 'pending' check(status in ('pending','assigned','in_progress','inspection','done')),
 assigned_to uuid references public.profiles,checklist jsonb not null default '{}',notes text not null default '',due_at timestamptz,
 created_at timestamptz not null default now());
create table public.maintenance_requests(id uuid primary key default gen_random_uuid(),unit_id uuid not null references public.units,description text not null,
 priority text not null check(priority in ('low','medium','high','urgent')),blocks_sale boolean not null default false,
 status text not null default 'open' check(status in ('open','in_progress','resolved')),assigned_to uuid references public.profiles,created_at timestamptz not null default now());
create table public.task_attachments(id uuid primary key default gen_random_uuid(),task_id uuid references public.operations_tasks,maintenance_id uuid references public.maintenance_requests,storage_path text not null,check(num_nonnulls(task_id,maintenance_id)=1));
create table public.access_instructions(booking_id uuid primary key references public.bookings,instructions text not null,entry_code text,
 release_at timestamptz not null,expires_at timestamptz not null,check(expires_at>release_at));
create table public.home_content(id uuid primary key default gen_random_uuid(),title_ar text not null,title_en text not null,
 kind text not null check(kind in ('banner','featured','new','popular')),image_url text,unit_ids uuid[] not null default '{}',sort_order int not null default 0,is_active boolean not null default true);
create table public.support_requests(id uuid primary key default gen_random_uuid(),customer_id uuid not null references public.profiles,booking_id uuid references public.bookings,
 kind text not null check(kind in ('support','cancellation','account_deletion')),message text not null,status text not null default 'open',created_at timestamptz not null default now());
create table public.audit_logs(id bigint generated always as identity primary key,actor_id uuid,table_name text not null,record_id text,action text not null,
 before_data jsonb,after_data jsonb,created_at timestamptz not null default now());
create function private.audit_change() returns trigger language plpgsql security definer set search_path='' as $$
begin
 insert into public.audit_logs(actor_id,table_name,record_id,action,before_data,after_data)
 values(auth.uid(),tg_table_name,coalesce(to_jsonb(new)->>'id',to_jsonb(old)->>'id'),tg_op,
 case when tg_op='INSERT' then null else to_jsonb(old)-'entry_code'-'instructions'-'address'-'phone'-'email' end,
 case when tg_op='DELETE' then null else to_jsonb(new)-'entry_code'-'instructions'-'address'-'phone'-'email' end);
 return coalesce(new,old);
end $$;
do $$ declare t text; begin
 foreach t in array array['properties','units','unit_rates','bookings','payments','refunds','coupons','user_roles','role_permissions','settings','access_instructions','operations_tasks','maintenance_requests','inventory_locks'] loop
 execute format('create trigger audit after insert or update or delete on public.%I for each row execute function private.audit_change()',t);
 end loop;
end $$;

-- Default deny every table; all authority comes from explicit policies/functions below.
do $$ declare t record; begin
 for t in select tablename from pg_tables where schemaname='public' loop
 execute format('alter table public.%I enable row level security',t.tablename);
 end loop;
end $$;
grant usage on schema public to anon,authenticated;
grant select on all tables in schema public to authenticated;
grant select on public.regions,public.cities,public.districts,public.properties,public.units,public.unit_images,public.amenities,public.unit_amenities,public.reviews,public.home_content to anon;
grant insert,update,delete on public.regions,public.cities,public.districts,public.properties,public.property_private,public.units,public.unit_images,public.amenities,public.unit_amenities,public.unit_rates,public.coupons,public.operations_tasks,public.maintenance_requests,public.access_instructions,public.home_content,public.user_roles,public.role_permissions,public.settings,public.task_attachments to authenticated;
grant insert,delete on public.favorites to authenticated;
grant insert on public.reviews,public.support_requests,public.device_tokens to authenticated;
grant delete on public.device_tokens to authenticated;
grant update(full_name,email) on public.profiles to authenticated;
grant update(read_at) on public.notifications to authenticated;

create policy profile_read on public.profiles for select to authenticated using(id=auth.uid() or public.has_permission('customer.read') or public.has_permission('booking.read'));
create policy profile_edit on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy own_roles on public.user_roles for select to authenticated using(user_id=auth.uid() or public.has_permission('roles.write'));
create policy roles_admin on public.user_roles for all to authenticated using(public.has_permission('roles.write')) with check(public.has_permission('roles.write'));
create policy role_read on public.roles for select to authenticated using(true);
create policy permissions_read on public.role_permissions for select to authenticated using(true);
create policy permissions_admin on public.role_permissions for all to authenticated using(public.has_permission('roles.write')) with check(public.has_permission('roles.write'));
create policy regions_read on public.regions for select using(true);
create policy cities_read on public.cities for select using(is_active or public.has_permission('catalog.write'));
create policy district_read on public.districts for select using(exists(select 1 from public.cities c where c.id=city_id and c.is_active) or public.has_permission('catalog.write'));
create policy property_read on public.properties for select using((is_active and exists(select 1 from public.districts d join public.cities c on c.id=d.city_id where d.id=district_id and c.is_active)) or public.has_permission('catalog.write'));
create policy unit_read on public.units for select using((status='published' and exists(select 1 from public.properties p join public.districts d on d.id=p.district_id join public.cities c on c.id=d.city_id where p.id=property_id and p.is_active and c.is_active)) or public.has_permission('catalog.write'));
create policy images_read on public.unit_images for select using(exists(select 1 from public.units u where u.id=unit_id));
create policy amenities_read on public.amenities for select using(true);
create policy unit_amenities_read on public.unit_amenities for select using(exists(select 1 from public.units u where u.id=unit_id));
create policy home_read on public.home_content for select using(is_active or public.has_permission('content.write'));
do $$ declare t text; begin
 foreach t in array array['regions','cities','districts','properties','property_private','units','unit_images','amenities','unit_amenities','unit_rates'] loop
 execute format('create policy catalog_admin on public.%I for all to authenticated using(public.has_permission(''catalog.write'')) with check(public.has_permission(''catalog.write''))',t);
 end loop;
 foreach t in array array['coupons','home_content'] loop
 execute format('create policy content_admin on public.%I for all to authenticated using(public.has_permission(''content.write'')) with check(public.has_permission(''content.write''))',t);
 end loop;
 foreach t in array array['operations_tasks','maintenance_requests','task_attachments','access_instructions'] loop
 execute format('create policy ops_admin on public.%I for all to authenticated using(public.has_permission(''operations.write'')) with check(public.has_permission(''operations.write''))',t);
 end loop;
end $$;
create policy assigned_tasks on public.operations_tasks for select to authenticated using(assigned_to=auth.uid() and public.has_permission('tasks.assigned'));
create policy bookings_read on public.bookings for select to authenticated using(customer_id=auth.uid() or public.has_permission('booking.read') or public.has_permission('finance.read'));
create policy inventory_admin on public.inventory_locks for select to authenticated using(public.has_permission('catalog.write'));
create policy guests_read on public.booking_guests for select to authenticated using(exists(select 1 from public.bookings b where b.id=booking_id and (b.customer_id=auth.uid() or public.has_permission('booking.read'))));
create policy payments_read on public.payments for select to authenticated using(public.has_permission('finance.read') or exists(select 1 from public.bookings b where b.id=booking_id and b.customer_id=auth.uid()));
create policy refunds_read on public.refunds for select to authenticated using(public.has_permission('finance.read') or exists(select 1 from public.bookings b where b.id=booking_id and b.customer_id=auth.uid()));
create policy favorites_own on public.favorites for all to authenticated using(customer_id=auth.uid()) with check(customer_id=auth.uid());
create policy reviews_read on public.reviews for select using(published or customer_id=auth.uid() or public.has_permission('content.write'));
create policy reviews_insert on public.reviews for insert to authenticated with check(customer_id=auth.uid() and not published and exists(select 1 from public.bookings b where b.id=booking_id and b.customer_id=auth.uid() and b.unit_id=unit_id and b.status='completed'));
create policy notifications_read on public.notifications for select to authenticated using(customer_id=auth.uid() or public.has_permission('content.write'));
create policy notifications_update on public.notifications for update to authenticated using(customer_id=auth.uid()) with check(customer_id=auth.uid());
create policy tokens_own on public.device_tokens for all to authenticated using(customer_id=auth.uid()) with check(customer_id=auth.uid());
create policy support_read on public.support_requests for select to authenticated using(customer_id=auth.uid() or public.has_permission('customer.read'));
create policy support_insert on public.support_requests for insert to authenticated with check(customer_id=auth.uid() and status='open' and (booking_id is null or exists(select 1 from public.bookings b where b.id=booking_id and b.customer_id=auth.uid())));
create policy settings_admin on public.settings for all to authenticated using(public.has_permission('settings.write')) with check(public.has_permission('settings.write'));
create policy audit_admin on public.audit_logs for select to authenticated using(public.has_permission('audit.read'));
commit;
