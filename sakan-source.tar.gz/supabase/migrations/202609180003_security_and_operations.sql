begin;
drop policy reviews_insert on public.reviews;
create policy reviews_insert on public.reviews for insert to authenticated with check(customer_id=auth.uid() and not published and exists(select 1 from public.bookings b where b.id=reviews.booking_id and b.customer_id=auth.uid() and b.unit_id=reviews.unit_id and b.status='completed'));
create function private.validate_settings() returns trigger language plpgsql set search_path='' as $$
begin
 if new.key='booking' and (coalesce((new.value->>'hold_minutes')::int,0) not between 1 and 30 or coalesce((new.value->>'service_fee')::int,-1)<0 or coalesce((new.value->>'tax_basis_points')::int,-1) not between 0 and 10000) then raise exception 'INVALID_SETTINGS'; end if;
 return new;
end $$;
create trigger validate_settings before insert or update on public.settings for each row execute function private.validate_settings();
create function public.approve_refund(p_payment uuid,p_amount int,p_reason text) returns uuid language plpgsql security definer set search_path='' as $$
declare p public.payments; result uuid; reserved int;
begin
 if not public.has_permission('finance.refund') then raise exception 'FORBIDDEN'; end if;
 select * into p from public.payments where id=p_payment for update;
 if p.id is null or p.status not in ('paid','partially_refunded','refund_required') or p_amount is null or p_amount<=0 or length(trim(p_reason))<2 then raise exception 'INVALID_REFUND'; end if;
 select coalesce(sum(amount),0) into reserved from public.refunds where payment_id=p.id and status in ('approved','processing','paid');
 if reserved+p_amount>p.amount then raise exception 'REFUND_EXCEEDS_PAYMENT'; end if;
 insert into public.refunds(booking_id,payment_id,amount,reason,status,approved_by) values(p.booking_id,p.id,p_amount,p_reason,'approved',auth.uid()) returning id into result;
 return result;
end $$;
create function public.record_verified_refund(p_refund uuid,p_provider_id text,p_amount int) returns void language plpgsql security definer set search_path='' as $$
declare r public.refunds; refunded int;
begin
 select * into r from public.refunds where id=p_refund for update;
 if r.id is null or r.amount<>p_amount then raise exception 'REFUND_MISMATCH'; end if;
 if r.status='paid' and r.provider_id=p_provider_id then return; end if;
 if r.status not in ('approved','processing') then raise exception 'INVALID_REFUND_STATE'; end if;
 perform 1 from public.payments where id=r.payment_id for update;
 update public.refunds set status='paid',provider_id=p_provider_id where id=r.id;
 select sum(amount)::int into refunded from public.refunds where payment_id=r.payment_id and status='paid';
 update public.payments set status=case when refunded=amount then 'refunded' else 'partially_refunded' end where id=r.payment_id;
end $$;
create function public.send_notification(p_customer uuid,p_title text,p_body text) returns uuid language plpgsql security definer set search_path='' as $$
declare result uuid;
begin
 if not public.has_permission('content.write') then raise exception 'FORBIDDEN'; end if;
 if length(trim(p_title))<1 or length(p_title)>150 or length(p_body)>2000 then raise exception 'INVALID_MESSAGE'; end if;
 insert into public.notifications(customer_id,title,body) values(p_customer,p_title,p_body) returning id into result;
 return result;
end $$;
create function public.approve_cancellation(p_booking uuid) returns void language plpgsql security definer set search_path='' as $$
declare b public.bookings; u uuid;
begin
 if not public.has_permission('booking.cancel') then raise exception 'FORBIDDEN'; end if;
 select unit_id into u from public.bookings where id=p_booking;
 perform 1 from public.units where id=u for update;
 select * into b from public.bookings where id=p_booking for update;
 if b.status<>'confirmed' then raise exception 'INVALID_TRANSITION'; end if;
 update public.bookings set status='cancelled' where id=b.id;
 delete from public.inventory_locks where booking_id=b.id;
 update public.support_requests set status='resolved' where booking_id=b.id and kind='cancellation';
 insert into public.notifications(customer_id,title,body,booking_id) values(b.customer_id,'أُلغي حجزك','تُراجع أي مبالغ مستحقة للاسترداد بصورة مستقلة.',b.id);
end $$;
revoke execute on function private.validate_settings() from public,anon,authenticated;
revoke execute on function public.approve_refund(uuid,int,text),public.record_verified_refund(uuid,text,int),public.send_notification(uuid,text,text),public.approve_cancellation(uuid) from public,anon,authenticated;
grant execute on function public.approve_refund(uuid,int,text),public.send_notification(uuid,text,text),public.approve_cancellation(uuid) to authenticated;
grant execute on function public.record_verified_refund(uuid,text,int) to service_role;
commit;
