import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { PGlite } from '@electric-sql/pglite';
import { btree_gist } from '@electric-sql/pglite/contrib/btree_gist';
const root=new URL('../',import.meta.url);
let db;
const alice='a0000000-0000-0000-0000-000000000001',bob='a0000000-0000-0000-0000-000000000002',admin='a0000000-0000-0000-0000-000000000003';
const unit='50000000-0000-0000-0000-000000000001',unit2='50000000-0000-0000-0000-000000000002';
let sequence=0;
const key=()=>`b0000000-0000-0000-0000-${String(++sequence).padStart(12,'0')}`;
const query=async(q,args=[])=> (await db.query(q,args)).rows;
const as=async(user,role='authenticated')=>{await db.exec('reset role');await query("select set_config('request.jwt.claim.sub',$1,false)",[user??'']);await db.exec(`set role ${role}`);};
const hold=async(u=unit,start=20,end=22,k=key())=>(await query(`select (public.create_booking_hold($1,current_date+$2::int,current_date+$3::int,2,$4,null)).*`,[u,start,end,k]))[0];
const rejects=async(fn,pattern)=>assert.rejects(fn,pattern);
before(async()=>{
 db=await PGlite.create({extensions:{btree_gist}});
 await db.exec(`create role anon; create role authenticated; create role service_role bypassrls; create schema auth; create table auth.users(id uuid primary key); create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$; grant usage on schema auth to anon,authenticated,service_role; grant execute on function auth.uid() to anon,authenticated,service_role;
 create schema storage;create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);create table storage.objects(id uuid primary key default gen_random_uuid(),bucket_id text,name text);alter table storage.objects enable row level security;`);
 for(const file of fs.readdirSync(new URL('migrations/',root)).filter(f=>f.endsWith('.sql')).sort())await db.exec(fs.readFileSync(new URL('migrations/'+file,root),'utf8'));
 await db.exec(fs.readFileSync(new URL('seed.sql',root),'utf8'));
 await query('insert into auth.users(id) values($1),($2),($3)',[alice,bob,admin]);
 await query("insert into public.user_roles values($1,'super_admin')",[admin]);
});
after(async()=>db.close());
test('anonymous can browse only published active-city units, never private addresses',async()=>{
 await as(null,'anon');assert.equal((await query('select * from public.units')).length,3);
 await rejects(()=>query('select * from public.property_private'),/permission denied/);
 await rejects(()=>hold(),/permission denied/);
});
test('server computes nightly overrides and validates capacity and dates',async()=>{
 await as(admin);await query('insert into public.unit_rates values($1,current_date+20,41000,1)',[unit]);
 await as(alice);const q=(await query('select public.quote_stay($1,current_date+20,current_date+22,2,null) q',[unit]))[0].q;
 assert.equal(q.subtotal,76000);assert.equal(q.total,76000);assert.equal(q.nights.length,2);
 await rejects(()=>query('select public.quote_stay($1,current_date+20,current_date+22,9,null)',[unit]),/CAPACITY_EXCEEDED/);
 await rejects(()=>query('select public.quote_stay($1,current_date+22,current_date+20,2,null)',[unit]),/INVALID_STAY/);
});
let booking;
test('hold is idempotent; overlapping inventory rejected; checkout boundary remains free',async()=>{
 await as(alice);const request=key();booking=await hold(unit,20,22,request);assert.equal(booking.total,76000);
 assert.equal((await hold(unit,20,22,request)).id,booking.id);
 await rejects(()=>hold(unit,21,23,request),/IDEMPOTENCY_CONFLICT/);
 await as(bob);await rejects(()=>hold(unit,21,23),/DATES_UNAVAILABLE/);
 const adjacent=await hold(unit,22,23);assert.ok(adjacent.id);
 await query('select public.cancel_booking($1)',[adjacent.id]);
});
test('RLS isolates bookings, blocks direct writes and privilege escalation',async()=>{
 await as(bob);assert.equal((await query('select * from public.bookings where id=$1',[booking.id])).length,0);
 await rejects(()=>query("update public.bookings set status='confirmed' where id=$1",[booking.id]),/permission denied/);
 await rejects(()=>query("insert into public.user_roles values($1,'super_admin')",[bob]),/row-level security/);
 await rejects(()=>query("update public.profiles set status='suspended' where id=$1",[alice]),/permission denied/);
 await rejects(()=>query("select public.record_verified_payment('forged',$1,'test','forged',76000,'SAR')",[booking.id]),/permission denied/);
 await rejects(()=>query('select public.approve_refund($1,100,\'test\')',[booking.id]),/FORBIDDEN/);
});
test('guest ownership, verified amount and currency, duplicate payment events',async()=>{
 await as(bob);await rejects(()=>query("select public.set_booking_guest($1,'Test Guest','+966500000001','')",[booking.id]),/BOOKING_UNAVAILABLE/);
 await as(alice);await query("select public.set_booking_guest($1,'Test Guest','+966500000001','')",[booking.id]);
 await as(null,'service_role');await rejects(()=>query("select public.record_verified_payment('bad',$1,'test','pay-bad',1,'SAR')",[booking.id]),/PAYMENT_MISMATCH/);
 const paid=await query("select public.record_verified_payment('event-1',$1,'test','pay-1',76000,'SAR') result",[booking.id]);assert.equal(paid[0].result,'confirmed');
 assert.equal((await query("select public.record_verified_payment('event-1',$1,'test','pay-1',76000,'SAR') result",[booking.id]))[0].result,'duplicate');
 assert.equal((await query('select * from public.notification_outbox')).length,1);
});
test('exact access details are time-gated and never directly selectable by customer',async()=>{
 await as(admin);await query("insert into public.property_private values('40000000-0000-0000-0000-000000000001','Private address',24.821,46.642)");
 await query("insert into public.access_instructions values($1,'Private instructions','9876',now()+interval '1 hour',now()+interval '2 hours')",[booking.id]);
 await as(alice);assert.equal((await query('select public.booking_access($1) result',[booking.id]))[0].result,null);
 assert.equal((await query('select * from public.access_instructions')).length,0);
 await as(admin);await query("update public.access_instructions set release_at=now()-interval '1 hour' where booking_id=$1",[booking.id]);
 await as(bob);assert.equal((await query('select public.booking_access($1) result',[booking.id]))[0].result,null);
 await as(alice);assert.equal((await query('select public.booking_access($1) result',[booking.id]))[0].result.entry_code,'9876');
});
test('expired hold can be replaced; late payment cannot steal inventory',async()=>{
 await as(alice);const expired=await hold(unit2,30,32);
 await as(null,'service_role');await query("update public.bookings set hold_expires_at=now()-interval '1 minute' where id=$1",[expired.id]);await query("update public.inventory_locks set expires_at=now()-interval '1 minute' where booking_id=$1",[expired.id]);
 await as(bob);const replacement=await hold(unit2,30,32);assert.ok(replacement.id);
 await as(null,'service_role');assert.equal((await query("select public.record_verified_payment('late-event',$1,'test','late-pay',$2,'SAR') result",[expired.id,expired.total]))[0].result,'refund_required');
 assert.equal((await query('select booking_id from public.inventory_locks where unit_id=$1 and stay @> (current_date+30)',[unit2]))[0].booking_id,replacement.id);
});
test('administrative blocks and reservations share exclusion constraint',async()=>{
 await as(admin);await query("select public.block_unit($1,current_date+40,current_date+43,'Maintenance')",[unit]);
 await as(alice);await rejects(()=>hold(unit,41,42),/DATES_UNAVAILABLE/);
 await as(admin);await rejects(()=>query("select public.block_unit($1,current_date+20,current_date+21,'Overlap')",[unit]),/exclusion constraint/);
});
test('reviews require completed owned booking and matching unit',async()=>{
 await as(alice);await rejects(()=>query('insert into public.reviews(booking_id,customer_id,unit_id,rating) values($1,$2,$3,5)',[booking.id,alice,unit]),/row-level security/);
 await as(null,'service_role');await query("update public.bookings set status='completed' where id=$1",[booking.id]);
 await as(alice);await rejects(()=>query('insert into public.reviews(booking_id,customer_id,unit_id,rating) values($1,$2,$3,5)',[booking.id,alice,unit2]),/row-level security/);
 await query('insert into public.reviews(booking_id,customer_id,unit_id,rating) values($1,$2,$3,5)',[booking.id,alice,unit]);
});
test('refund approvals cannot exceed captured payment; audit contains no entry code',async()=>{
 await as(admin);const p=(await query("select id from public.payments where provider_id='pay-1'"))[0].id;
 const refund=(await query("select public.approve_refund($1,50000,'Approved cancellation') id",[p]))[0].id;
 await rejects(()=>query("select public.approve_refund($1,30000,'Excess')",[p]),/REFUND_EXCEEDS_PAYMENT/);
 await as(null,'service_role');await query("select public.record_verified_refund($1,'refund-1',50000)",[refund]);
 assert.equal((await query('select status from public.payments where id=$1',[p]))[0].status,'partially_refunded');
 await as(admin);assert.equal((await query("select * from public.audit_logs where after_data ? 'entry_code'")).length,0);
});
test('coupon limits include active holds; changing settings cannot make negative totals',async()=>{
 await as(admin);await query("insert into public.coupons(code,percent,max_discount,minimum,starts_at,ends_at,max_uses,per_customer) values('ONE',20,10000,0,now()-interval '1 day',now()+interval '1 day',1,1)");
 await as(alice);const b=(await query("select (public.create_booking_hold($1,current_date+50,current_date+52,2,$2,'ONE')).*",[unit,key()]))[0];assert.equal(b.discount,10000);
 await as(bob);await rejects(()=>query("select public.create_booking_hold($1,current_date+53,current_date+55,2,$2,'ONE')",[unit,key()]),/COUPON_EXHAUSTED/);
 await as(admin);await rejects(()=>query("update public.settings set value='{\"hold_minutes\":10,\"service_fee\":-1,\"tax_basis_points\":0}' where key='booking'"),/INVALID_SETTINGS/);
});
test('image covers are unique and review moderation is administrator-only',async()=>{
 await as(admin);
 const a=(await query("insert into public.unit_images(unit_id,image_url,is_cover) values($1,'https://example.test/a.jpg',true) returning id",[unit]))[0].id;
 const b=(await query("insert into public.unit_images(unit_id,image_url) values($1,'https://example.test/b.jpg') returning id",[unit]))[0].id;
 await query('select public.set_cover_image($1)',[b]);assert.equal((await query('select id from public.unit_images where unit_id=$1 and is_cover',[unit]))[0].id,b);
 const review=(await query('select id from public.reviews where booking_id=$1',[booking.id]))[0].id;
 await as(bob);await rejects(()=>query('select public.set_cover_image($1)',[a]),/FORBIDDEN/);await rejects(()=>query('select public.moderate_review($1,true)',[review]),/FORBIDDEN/);
 await as(admin);await query('select public.moderate_review($1,true)',[review]);await as(null,'anon');assert.equal((await query('select * from public.reviews where id=$1',[review])).length,1);
});

test('admin saves private addresses without invented coordinates; permission and atomicity checks',async()=>{
 const property={id:'40000000-0000-0000-0000-000000000099',district_id:'30000000-0000-0000-0000-000000000001',code:'ADDRESS-TEST',name_ar:'اختبار عنوان',name_en:'Address test',approx_lat:null,approx_lng:null,is_active:true};
 await as(alice);await rejects(()=>query('select public.save_property_with_address($1,$2)',[property,'Private address']),/Forbidden/);
 await as(admin);await query('select public.save_property_with_address($1,$2)',[property,'3865 خريص الفرعي، الرياض']);
 const rows=await query('select p.approx_lat,p.approx_lng,a.address from public.properties p join public.property_private a on a.property_id=p.id where p.id=$1',[property.id]);
 assert.equal(rows[0].approx_lat,null);assert.equal(rows[0].approx_lng,null);assert.equal(rows[0].address,'3865 خريص الفرعي، الرياض');
 await rejects(()=>query('select public.save_property_with_address($1,$2)',[{...property,approx_lat:24},'Changed address']),/properties_location_pair/);
 assert.equal((await query('select address from public.property_private where property_id=$1',[property.id]))[0].address,'3865 خريص الفرعي، الرياض');
 await as(alice);assert.equal((await query('select * from public.property_private where property_id=$1',[property.id])).length,0);
 await as(null,'anon');await rejects(()=>query('select public.save_property_with_address($1,$2)',[property,'forged']),/permission denied/);
});
