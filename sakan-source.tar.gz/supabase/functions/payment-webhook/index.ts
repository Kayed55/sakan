import { createClient } from 'npm:@supabase/supabase-js@2';
import { json, gatewayConfig } from '../_shared/http.ts';
import { verifySignature, validatePayment } from '../_shared/security.ts';
Deno.serve(async request => {
  if (request.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);
  const body = await request.text();
  if (body.length > 65536) return json({ error: 'BODY_TOO_LARGE' }, 413);
  const verified = await verifySignature(Deno.env.get('PAYMENT_WEBHOOK_SECRET') ?? '', request.headers.get('x-sakan-timestamp'), request.headers.get('x-sakan-signature'), body);
  if (!verified) return json({ error: 'INVALID_SIGNATURE' }, 401);
  try {
    const event = JSON.parse(body);
    if (typeof event.id !== 'string' || !event.id || typeof event.payment_id !== 'string' || !event.payment_id) return json({ error: 'INVALID_EVENT' }, 400);
    if (event.type !== 'payment.paid') return json({ ignored: true });
    const cfg = gatewayConfig();
    // Re-fetch provider truth; never trust redirect parameters or client amounts.
    const response = await fetch(`${cfg.base}/payments/${encodeURIComponent(event.payment_id)}`, { headers: { Authorization: `Bearer ${cfg.secret}` }, signal: AbortSignal.timeout(15000) });
    if (!response.ok) return json({ error: 'VERIFY_RETRY_REQUIRED' }, 503);
    const payment = validatePayment(await response.json());
    if (payment.id !== event.payment_id) return json({ error: 'PAYMENT_MISMATCH' }, 400);
    const service = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
    const { data, error } = await service.rpc('record_verified_payment', { p_event: event.id, p_booking: payment.booking_id, p_provider: 'adapter-v1', p_provider_id: payment.id, p_amount: payment.amount, p_currency: payment.currency });
    if (error) return json({ error: 'RECONCILIATION_REQUIRED' }, 409);
    return json({ status: data });
  } catch { return json({ error: 'WEBHOOK_RETRY_REQUIRED' }, 503); }
});
