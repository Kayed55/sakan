import { createClient } from 'npm:@supabase/supabase-js@2';
import { cors, json, gatewayConfig } from '../_shared/http.ts';
import { validUuid } from '../_shared/security.ts';
Deno.serve(async request => {
  if (request.method === 'OPTIONS') return new Response(null, { headers: cors });
  if (request.method !== 'POST') return json({ error: 'METHOD_NOT_ALLOWED' }, 405);
  try {
    const token = request.headers.get('authorization')?.replace(/^Bearer /i, '');
    if (!token) return json({ error: 'AUTH_REQUIRED' }, 401);
    const service = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });
    const { data: { user }, error: authError } = await service.auth.getUser(token);
    if (authError || !user) return json({ error: 'AUTH_REQUIRED' }, 401);
    const payload = await request.json();
    if (!validUuid(payload.booking_id)) return json({ error: 'INVALID_BOOKING' }, 400);
    const { data: booking, error } = await service.from('bookings').select('id,customer_id,status,hold_expires_at,total,currency,booking_guests(id)').eq('id', payload.booking_id).single();
    if (error || !booking || booking.customer_id !== user.id) return json({ error: 'NOT_FOUND' }, 404);
    if (booking.status !== 'hold' || Date.parse(booking.hold_expires_at) <= Date.now() || !booking.booking_guests.length) return json({ error: 'BOOKING_NOT_PAYABLE' }, 409);
    const cfg = gatewayConfig();
    const returnUrl = Deno.env.get('PAYMENT_RETURN_URL');
    if (!returnUrl || new URL(returnUrl).protocol !== 'https:') return json({ error: 'PAYMENTS_NOT_CONFIGURED' }, 503);
    const response = await fetch(`${cfg.base}/checkout`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${cfg.secret}`, 'Idempotency-Key': booking.id },
      body: JSON.stringify({ booking_id: booking.id, amount: booking.total, currency: booking.currency, expires_at: booking.hold_expires_at, return_url: returnUrl }),
      signal: AbortSignal.timeout(15000),
    });
    if (!response.ok) return json({ error: 'GATEWAY_UNAVAILABLE' }, 502);
    const result = await response.json();
    const checkout = new URL(result.checkout_url);
    const hosts = (Deno.env.get('PAYMENT_CHECKOUT_HOSTS') ?? '').split(',').map(x => x.trim());
    if (checkout.protocol !== 'https:' || !hosts.includes(checkout.hostname)) return json({ error: 'UNTRUSTED_CHECKOUT_URL' }, 502);
    return json({ checkout_url: checkout.href });
  } catch (error) {
    return json({ error: error instanceof Error && error.message === 'PAYMENTS_NOT_CONFIGURED' ? 'PAYMENTS_NOT_CONFIGURED' : 'CHECKOUT_UNAVAILABLE' }, 503);
  }
});
