export const cors = {
  'Access-Control-Allow-Origin': Deno.env.get('APP_ORIGIN') ?? 'http://localhost:8080',
  'Access-Control-Allow-Headers': 'authorization, apikey, x-client-info, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
};
export const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { ...cors, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' } });
export function gatewayConfig() {
  if (Deno.env.get('PAYMENT_PROVIDER') !== 'adapter-v1') throw new Error('PAYMENTS_NOT_CONFIGURED');
  const base = Deno.env.get('PAYMENT_API_BASE_URL');
  const secret = Deno.env.get('PAYMENT_SECRET_KEY');
  if (!base || !secret || new URL(base).protocol !== 'https:') throw new Error('PAYMENTS_NOT_CONFIGURED');
  return { base: base.replace(/\/$/, ''), secret };
}
