export function validUuid(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}
export async function signature(secret: string, timestamp: string, body: string): Promise<string> {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return [...new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(`${timestamp}.${body}`)))].map(b => b.toString(16).padStart(2, '0')).join('');
}
export async function verifySignature(secret: string, timestamp: string | null, supplied: string | null, body: string, now = Date.now()): Promise<boolean> {
  if (!secret || !timestamp || !supplied || !/^\d{10}$/.test(timestamp) || !/^[a-f0-9]{64}$/i.test(supplied)) return false;
  if (Math.abs(now / 1000 - Number(timestamp)) > 300) return false;
  const expected = await signature(secret, timestamp, body);
  let difference = 0;
  for (let i=0; i<expected.length; i++) difference |= expected.charCodeAt(i) ^ supplied.toLowerCase().charCodeAt(i);
  return difference === 0;
}
export function validatePayment(payment: Record<string, unknown>) {
  if (!validUuid(payment.booking_id) || typeof payment.id !== 'string' || !payment.id || payment.status !== 'paid' || payment.currency !== 'SAR' || !Number.isSafeInteger(payment.amount) || Number(payment.amount) <= 0) throw new Error('Invalid verified payment');
  return payment;
}
