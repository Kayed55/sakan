import { test } from 'node:test';
import assert from 'node:assert/strict';
import { signature, verifySignature, validatePayment, validUuid } from './security.ts';
test('signed webhook accepts valid body, rejects tampering, replay and absent secret', async () => {
 const timestamp = String(Math.floor(Date.now()/1000)), body = '{"id":"event-1"}', secret = 'test-secret-only';
 const signed = await signature(secret,timestamp,body);
 assert.equal(await verifySignature(secret,timestamp,signed,body),true);
 assert.equal(await verifySignature(secret,timestamp,signed,body+' '),false);
 assert.equal(await verifySignature(secret,timestamp,signed,body,Date.now()+600000),false);
 assert.equal(await verifySignature('',timestamp,signed,body),false);
 assert.equal(await verifySignature(secret,timestamp,'x'.repeat(64),body),false);
});
test('verified payment requires SAR integer minor units and paid provider status',()=>{
 const payment={id:'p1',booking_id:'50000000-0000-0000-0000-000000000001',status:'paid',currency:'SAR',amount:35000};
 assert.ok(validatePayment(payment));
 for(const change of [{currency:'USD'},{amount:1.5},{amount:-10},{status:'pending'},{booking_id:'bad'}])assert.throws(()=>validatePayment({...payment,...change}));
 assert.equal(validUuid(null),false);
});
