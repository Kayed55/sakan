insert into public.regions(id,name_ar,name_en,code) values('10000000-0000-0000-0000-000000000001','منطقة الرياض','Riyadh Region','RIY');
insert into public.cities(id,region_id,name_ar,name_en,is_active) values('20000000-0000-0000-0000-000000000001','10000000-0000-0000-0000-000000000001','الرياض','Riyadh',true);
insert into public.districts(id,city_id,name_ar,name_en) values
 ('30000000-0000-0000-0000-000000000001','20000000-0000-0000-0000-000000000001','الياسمين','Al Yasmin'),
 ('30000000-0000-0000-0000-000000000002','20000000-0000-0000-0000-000000000001','الملقا','Al Malqa'),
 ('30000000-0000-0000-0000-000000000003','20000000-0000-0000-0000-000000000001','حطين','Hittin');
insert into public.properties(id,district_id,code,name_ar,name_en,approx_lat,approx_lng) values
 ('40000000-0000-0000-0000-000000000001','30000000-0000-0000-0000-000000000001','RYD-YAS-01','سكن الياسمين','Sakan Yasmin',24.82,46.64),
 ('40000000-0000-0000-0000-000000000002','30000000-0000-0000-0000-000000000002','RYD-MAL-01','سكن الملقا','Sakan Malqa',24.80,46.60),
 ('40000000-0000-0000-0000-000000000003','30000000-0000-0000-0000-000000000003','RYD-HIT-01','سكن حطين','Sakan Hittin',24.77,46.59);
insert into public.units(id,property_id,code,name_ar,name_en,description_ar,description_en,kind,capacity,bedrooms,beds,bathrooms,area,base_price,status) values
 ('50000000-0000-0000-0000-000000000001','40000000-0000-0000-0000-000000000001','YAS-101','استديو الياسمين الهادئ','The Yasmin Studio','مساحة دافئة وتفاصيل بسيطة لإقامة مريحة في شمال الرياض. بيانات وصور تجريبية.','A calm, thoughtfully designed studio in north Riyadh. Demo listing.','studio',2,0,1,1,45,35000,'published'),
 ('50000000-0000-0000-0000-000000000002','40000000-0000-0000-0000-000000000002','MAL-201','شقة الملقا • غرفة وصالة','Al Malqa Residence','غرفة نوم وصالة واسعة، ومطبخ مجهز لإقامة تشبه البيت. بيانات تجريبية.','A generous living room, bedroom and equipped kitchen. Demo listing.','apartment',3,1,2,1,80,48000,'published'),
 ('50000000-0000-0000-0000-000000000003','40000000-0000-0000-0000-000000000003','HIT-301','رحابة حطين • غرفتان','Hittin Family Suite','غرفتان ومساحة تجمعكم، بالقرب من وجهات الرياض. بيانات تجريبية.','Two bedrooms and room to gather near Riyadh destinations. Demo listing.','apartment',5,2,3,2,120,69000,'published');
insert into public.amenities values('wifi','واي فاي','Wi-Fi'),('parking','موقف سيارة','Parking'),('kitchen','مطبخ','Kitchen'),('self_checkin','دخول ذاتي','Self check-in'),('ac','تكييف','Air conditioning'),('elevator','مصعد','Elevator');
insert into public.unit_amenities select u.id,a.id from public.units u cross join public.amenities a;
insert into public.home_content(title_ar,title_en,kind,sort_order) values('إقامة تشبهك، في قلب الرياض','Find your place in Riyadh','banner',0),('مختارة لإقامتك','Picked for your stay','featured',1),('وصل حديثًا','Just added','new',2);
