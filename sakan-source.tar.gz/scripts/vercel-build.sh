#!/usr/bin/env bash
set -euo pipefail
: "${SUPABASE_URL:?Set SUPABASE_URL in Vercel}"
: "${SUPABASE_ANON_KEY:?Set the PUBLIC Supabase publishable or anon key in Vercel}"
SAKAN_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SAKAN_FLUTTER="${FLUTTER_BIN:-$SAKAN_ROOT/.vercel-cache/flutter/bin/flutter}"
if [ ! -x "$SAKAN_FLUTTER" ]; then
  mkdir -p "$SAKAN_ROOT/.vercel-cache"
  git clone --depth 1 --branch 3.47.4 https://github.com/flutter/flutter.git "$SAKAN_ROOT/.vercel-cache/flutter"
fi
"$SAKAN_FLUTTER" config --no-analytics
cd "$SAKAN_ROOT/app"
"$SAKAN_FLUTTER" pub get
mkdir -p "$SAKAN_ROOT/dist/customer" "$SAKAN_ROOT/dist/admin"
for target in customer admin; do
  entry=lib/main.dart
  [ "$target" != admin ] || entry=lib/admin_main.dart
  "$SAKAN_FLUTTER" build web --release -t "$entry" --base-href "/$target/" \
    --dart-define=APP_MODE=live \
    --dart-define="SUPABASE_URL=$SUPABASE_URL" \
    --dart-define="SUPABASE_ANON_KEY=$SUPABASE_ANON_KEY"
  cp -R build/web/. "$SAKAN_ROOT/dist/$target/"
done
