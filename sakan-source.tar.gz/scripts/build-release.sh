#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 2 ]]; then
  echo 'Usage: scripts/build-release.sh [appbundle|ipa|web-admin] /absolute/path/live-config.json' >&2
  exit 1
fi
TARGET="$1"
CONFIG="$2"
python3 - "$CONFIG" <<'PY'
import json, sys
c=json.load(open(sys.argv[1]))
assert c.get('APP_MODE')=='live', 'Release requires APP_MODE=live'
assert c.get('SUPABASE_URL','').startswith('https://'), 'Missing Supabase URL'
assert c.get('SUPABASE_ANON_KEY') and 'YOUR_' not in c['SUPABASE_ANON_KEY'], 'Missing public key'
assert not any('SECRET' in k or 'SERVICE_ROLE' in k for k in c), 'Never embed server secrets'
PY
cd "$(dirname "$0")/../app"
case "$TARGET" in
 appbundle) flutter build appbundle --release --dart-define-from-file="$CONFIG" ;;
 ipa) flutter build ipa --release --dart-define-from-file="$CONFIG" ;;
 web-admin) flutter build web --release -t lib/admin_main.dart --dart-define-from-file="$CONFIG" ;;
 *) echo 'Unknown target' >&2; exit 1 ;;
esac
