from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
root = Path(__file__).resolve().parents[1] / 'preview'
print('Sakan preview: http://127.0.0.1:8080', flush=True)
ThreadingHTTPServer(('127.0.0.1',8080),partial(SimpleHTTPRequestHandler,directory=str(root))).serve_forever()
