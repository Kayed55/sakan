#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm ci
npm run test:db
npm run test:payments
cd app
flutter pub get
flutter analyze
flutter test
flutter build web --release --base-href /customer/ --output ../preview/customer --dart-define=APP_MODE=demo
flutter build web --release -t lib/admin_main.dart --base-href /admin/ --output ../preview/admin --dart-define=APP_MODE=demo
