# سكن — Sakan

مشروع فعلي لتطبيق إقامة يومية في الرياض، مع قابلية توسع جغرافية لكل المملكة. يتضمن Flutter للعميل (iOS / Android / Web)، ومدخل Flutter Web منفصل للإدارة، وSupabase/PostgreSQL.

**الحالة: MVP تجريبي قابل للتشغيل، وليس إصدار إنتاج أو تطبيقًا منشورًا في المتاجر.**

## جرّب الآن

المعاينة المبنية موجودة في `preview/`. من جذر المشروع:

```sh
python3 scripts/preview.py
```

افتح [معاينة سكن](http://127.0.0.1:8080/)، ومنها [العميل](http://127.0.0.1:8080/customer/) و[الإدارة](http://127.0.0.1:8080/admin/).

- البيانات محلية وتجريبية. الجوال: أي رقم تجريبي بصيغة `+9665XXXXXXXX`، والرمز `123456`.
- يمكنك التصفح دون حساب، اختيار الإقامة، مراجعة السعر، تسجيل الدخول التجريبي، إدخال بيانات الضيف ومحاكاة الدفع.
- الحجز التجريبي يظهر في «حجوزاتي» ويُحفظ في تخزين المتصفح. لا توجد رسائل SMS أو خصومات مالية فعلية.
- لوحة الإدارة في وضع demo مفتوحة للتجربة فقط. في وضع live تتطلب مصادقة وصلاحية خادمية.
- الصور في بيانات demo أمثلة من Unsplash؛ ليست صور عقارات فعلية. الخريطة تعرض مواقع تقريبية.
- إذا كانت المعاينتان مفتوحتين معًا، أعد تحميل الصفحة لقراءة أحدث بيانات التخزين المحلي المشتركة على نفس العنوان.

## البنية

```text
app/
  lib/core/         النماذج، إعداد التطبيق ومستودع البيانات
  lib/customer/     واجهات العميل والحجز والمصادقة
  lib/admin/        لوحة الإدارة، النماذج والتقويم
  lib/main.dart     مدخل العميل
  lib/admin_main.dart مدخل الإدارة
  android/ ios/ web/ مشاريع المنصات الفعلية
  test/            اختبارات الواجهات ورحلة الحجز
supabase/
  migrations/      الجداول، RLS، RBAC، RPC، Storage
  functions/       إنشاء الدفع ومعالجة webhook الموقّع
  tests/           اختبارات PostgreSQL وصلاحياته
  seed.sql         بيانات الرياض التجريبية فقط
scripts/           الفحص والبناء والمعاينة
preview/           نسختا Web مبنيتان للتجربة
```

## تشغيل المصدر

اختُبر على Flutter 3.47.4 / Dart 3.13.3. ثبّت Flutter على PATH ثم:

```sh
cd app
flutter pub get
flutter run -d chrome --dart-define=APP_MODE=demo
# لوحة الإدارة
flutter run -d chrome -t lib/admin_main.dart --dart-define=APP_MODE=demo
# جهاز iOS/Android متصل أو محاكي
flutter run --dart-define=APP_MODE=demo
```

العربية هي اللغة الافتراضية وRTL مفعّل. إعداد اللغات واتجاه الإنجليزية جاهزان وتوجد ترجمة لواجهة التصفح الأساسية؛ ترجمة جميع النماذج الإدارية والنصوص التفصيلية إلى الإنجليزية ليست مكتملة.

## ربط Supabase

1. أنشئ مشروع Supabase أو استخدم CLI محليًا مع Docker.
2. طبّق migrations بالترتيب. استخدم `supabase db reset` محليًا لتطبيق seed التجريبي. **لا تستخدم seed لعقارات إنتاج حقيقية.**
3. فعّل Phone Auth واختر مزود SMS واضبط حدود الإرسال والحماية المناسبة. التطبيق يستدعي `signInWithOtp` و`verifyOTP` فعليًا في live.
4. أنشئ أول حساب إداري بالمصادقة، ثم امنحه `super_admin` من SQL Editor الموثوق فقط:

```sql
insert into public.user_roles(user_id, role_id)
values ('REPLACE_WITH_AUTH_USER_UUID', 'super_admin');
```

5. انسخ `config.example.json` إلى ملف محلي غير مرفوع، واستبدل URL والمفتاح العام فقط. شغّل:

```sh
flutter run --dart-define-from-file=/absolute/path/live-config.json
```

6. انشر Functions باستخدام Supabase CLI، واضبط الأسرار في الخادم. `payment-webhook` يتحقق من توقيع مستقل بدل JWT. تفاصيل التكامل في [عقد الدفع](docs/payment-adapter.md).

لا توجد مفاتيح حقيقية في المشروع. لا تضع service role أو أسرار الدفع داخل Flutter؛ محتوى `--dart-define` قابل للاستخراج من التطبيق.

## سلامة الحجز

- التسلسل Region → City → District → Property → Unit، وتفعيل المدن من البيانات.
- الأموال أعداد صحيحة بالهللات، والسعر يُحسب خادميًا مع أسعار كل ليلة ورسوم/خصم/ضريبة.
- افتراضي التجربة: رسوم وضريبة صفر، وليسا إعدادًا ماليًا معتمدًا.
- حجز مؤقت 10 دقائق قابل للضبط، مع قفل على الوحدة وقيد PostgreSQL GiST يمنع تداخل `[check_in, check_out)` عبر الحجوزات والحجوزات المؤقتة والحجب الإداري.
- انتهاء الحجز المؤقت يُنظَّف عند محاولة حجز الوحدة ويُستبعد مباشرة من البحث. لا يحتاج التوافر إلى نجاح مهمة cron.
- تأكيد الدفع خادمي فقط، مع التحقق من المبلغ والعملة ومنع تكرار الحدث والدفعة. الدفع المتأخر يتحول إلى طلب مراجعة استرداد.
- العناوين الدقيقة وتعليمات الدخول في جداول منفصلة. RPC يعرضها لصاحب الحجز المدفوع خلال نافذة الاستحقاق فقط ويسجل عملية القراءة.
- لا يستطيع العميل تعديل حالة حجزه أو المبالغ أو دوره. الصلاحيات عبر RLS وRPC، وليس إخفاء الأزرار فقط.

## الفحص

```sh
npm ci
npm run test:db
npm run test:payments
cd app
flutter analyze
flutter test
flutter build web --release
flutter build web --release -t lib/admin_main.dart
```

قاعدة الاختبار هي PostgreSQL مضمّن عبر PGlite، وليست محاكاة للـ SQL. تُنشأ جداول Auth/Storage البسيطة في الاختبار لعزل سياسات البيانات. لا تستبدل هذه الاختبارات اختبار Supabase الكامل أو اختبار تزامن اتصالات متعددة على خادم إنتاج.

## المتاجر والإطلاق

ملفات iOS وAndroid موجودة. يتطلب بناء الأجهزة Android SDK وJDK وXcode الكامل حسب المنصة. التوقيع التجاري وحسابات المتاجر غير موفرة. إعداد Android release يستقبل:
`SAKAN_KEYSTORE_PATH`, `SAKAN_KEYSTORE_PASSWORD`, `SAKAN_KEY_ALIAS`, `SAKAN_KEY_PASSWORD` ولا يستخدم مفتاح debug.

استخدم `bash scripts/build-release.sh appbundle /absolute/path/live-config.json` أو `ipa` بعد تجهيز التوقيع. راجع معرف التطبيق `sa.sakan.sakan` قبل أول نشر.

راجع [حالة التنفيذ وحدوده](docs/implementation-status.md) و[نتائج التحقق](docs/verification.md). يلزم قبل استقبال حجوزات حقيقية: بيانات عقارات فعلية، مشروع Supabase مفعّل، مزود OTP، مزود دفع وتكامل معتمد، مزود Push، السياسات والرسوم المعتمدة، اختبارات بيئة staging، وتوقيع المتاجر.
