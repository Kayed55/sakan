# نشر سكن — 18 سبتمبر 2026

- GitHub: https://github.com/Kayed55/sakan
- Supabase: project `oodutmdvpcbnfbgenuoq`.
- Applied the five database migrations as one transaction using the SQL Editor; confirmed 34 public tables, all with RLS enabled.
- Seeded Riyadh, Al Yasmin, Al Malqa, Hittin, and six amenities. Production has zero property units; demo listings were not published.
- Source uploaded as `sakan-source.tar.gz` (124 files), together with database bootstrap and Vercel config. Extract the archive for development. GitHub Actions inside the archive are not active until extracted into the repository.
- Vercel project: `kayedalharthi1-4473s-projects/sakan`.
- Set Production environment `SUPABASE_URL` and public `SUPABASE_ANON_KEY`. Privileged keys were not copied.
- Vercel production deployment B8oFb7rtDqaYSiaLhZVcRgHKTPXn succeeded in 3m 6s.
- Live customer app: https://sakan-jade-delta.vercel.app/customer/
- Live admin: https://sakan-jade-delta.vercel.app/admin/
- Browser verified onboarding, home, empty search results and employee login gate. No customer-console errors observed.
- Supabase Site URL updated to the live customer URL.
- User confirmed SMS and payment provider accounts are not ready; activation deferred.

## Remaining activation

- Phone auth is currently disabled in Supabase; an SMS provider is required.
- No application administrator user has been onboarded.
- Actual payment/refund adapter and server functions require provider configuration; source alone does not activate them.
- Push delivery and native app store distribution remain unconfigured.
- Migrations were applied manually; reconcile migration history before using Supabase CLI deployment. Do not rerun the bootstrap on this database.
