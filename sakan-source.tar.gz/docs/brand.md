# Sakan brand adoption

Owner-supplied logo extracted from the supplied PDF as transparent, high-resolution artwork. Original lettering, symbol, spacing and proportions are preserved. Dark and cream variants match the supplied brand palette. The source PDF is not distributed.

- Green: #234C3C
- Sand: #C2A173
- Cream: #F6F4ED
- Secondary green: #4A6D5C

Customer headers, onboarding, splash and administration share the same BrandMark component. Native iOS/Android and web icons use the supplied doorway symbol on green with safe margins. Images are not mirrored in RTL.
