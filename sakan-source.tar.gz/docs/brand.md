# SAKN brand identity — 21 September 2026

Source: owner-provided سكن copy 2.pdf, seven pages. Adopted the new Arabic/Latin lockup, rounded symbol and geometric pattern directly from the PDF vector artwork. The source PDF and its mockups are not distributed in the app.

## Approved colors
- Blue #4A769D (primary identity)
- Olive #929C5D (secondary identity)
- Cream #F2E8D0 (brand backgrounds)
- Orange #E58C58 (primary action surfaces and accents)
- Supporting ink #213B51 and light surface #FCFAF5 maintain text contrast.

The PDF does not specify a body font; existing Arabic/English typography is retained. The logo lettering is preserved, not recreated with a font.

## Implementation
- One shared BrandMark with correct 280:106 aspect ratio, original transparent blue and white exports.
- Logo-only launch screen, cream background. No tagline, as requested.
- Blue header identity, orange action buttons, blue/cream footer with subtle supplied pattern.
- Shared admin/forms/dialog/calendar/chat palette; semantic error and warning colors remain distinct.
- Website favicon, PWA icons, Android launcher/launch artwork and iOS icons/launch artwork updated.
- App icon retains safe margins around the supplied symbol; it is never mirrored in RTL.
- No database, API, authentication, roles or booking behavior changes.

## Contrast
- Ink on orange: 4.55:1.
- White on primary blue: 4.81:1.
- Main text uses dark ink or slate on light surfaces.

Native icons are source assets. This update does not itself publish signed apps to Apple or Google stores.
