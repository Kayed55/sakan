# Sakan responsive design system

The application uses Flutter, not a CSS/TypeScript frontend. Layout uses logical pixels, LayoutBuilder, Expanded/Flexible, Wrap and bounded content rather than page scaling. The existing owner-supplied logo and green/cream/gold identity remain unchanged.

- Primary #234c3c; canvas #f6f4ed; accent #c2a173; readable secondary text #5d685f; error #963f3f; pending #805719. Status always has a text label.
- Compact <600; records switch from cards to a table at available content width 900; administration sidebar appears at viewport width1100 and can collapse. Customer desktop navigation at1000.
- Content maximum1240; forms720; narrow reading routes use720–960. Mobile gutters16, larger gutters28. Gaps8/12/16/24; card radius18–22. Shadows kept subtle and limited to the existing search component.
- Buttons and icon actions have a48 logical pixel minimum hit area; main buttons54. Inputs use18 vertical padding and a visible focus border. Flutter's keyboard traversal, semantics and standard material focus behavior remain enabled.
- SafeArea wraps both application navigators, including routes, dialogs, sheets and bottom bars. No global zoom, clipping hack or text-scale clamp.
- Shared components: ContentFrame, PageList, FormSection, StatusPill, MetricCard and ResponsiveRecords in app/lib/ui. Original shared widgets and branding components continue to be used.
- Records: search, status filter when applicable, column ordering,12-row pages, mobile cards, fixed desktop table header and scrolling confined to the table. These controls apply to records returned by the existing repository (its existing500-row limit is unchanged).
- Dialog content scrolls independently of actions. Existing validation rules are retained; required fields are marked according to those rules.
- Navigation and shortcuts use existing permission checks. Booking transition and refund buttons also mirror their existing server permission checks; roles and server permissions are not modified.

Development-only browser audit: app/test/responsive_browser_audit.dart. It uses existing demo fixtures in isolated in-memory preferences, renders58 page/form/state cases at each of8 widths, and records Flutter assertion/layout errors. It is not referenced by the customer or admin entrypoints and is not deployed as a route.
