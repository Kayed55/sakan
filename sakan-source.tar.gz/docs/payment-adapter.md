# Payment integration contract — not a configured gateway

The app never collects card numbers. `create-checkout` authenticates the caller, verifies booking ownership, unexpired hold and primary guest, and obtains the immutable SAR amount from PostgreSQL. It returns an HTTPS hosted checkout URL restricted to an explicit hostname allowlist.

No gateway has been selected or enabled. Production calls fail closed with `PAYMENTS_NOT_CONFIGURED`. `adapter-v1` refers to a server adapter you must implement for the selected provider; it is **not** a claim of direct compatibility with Moyasar, HyperPay, Tap, or another provider. Provider account onboarding, Mada/Apple Pay merchant setup, sandbox certification, actual refunds and reconciliation remain integration work.

Adapter HTTP contract (server only):
- `POST /checkout` accepts booking_id, integer amount in halalas, SAR currency, expires_at, return_url; `Idempotency-Key` is the booking UUID. Returns `{ "checkout_url": "https://allowed-host/..." }`. The adapter must enforce one checkout session per booking and expire it with the hold.
- `GET /payments/:id` returns `{id, booking_id, amount, currency, status:"paid"}` only after provider verification.
- Webhook body `{id, type:"payment.paid", payment_id}` signed as HMAC-SHA256 of `timestamp + "." + exactRawBody`. Headers `x-sakan-timestamp` (Unix seconds), `x-sakan-signature` (hex). A five-minute replay window applies; the database permanently deduplicates event and payment IDs.
- Verify the provider's own signature in the adapter before forwarding. The generic signature here is not a replacement for provider authentication.
- The return URL is cosmetic navigation. Only the authenticated webhook plus a provider-side re-fetch may confirm a booking.
- Late capture after a hold expires produces `refund_required`; it never displaces another booking.
- Approved refunds are reservations against the captured amount. A worker must call the selected provider with a refund UUID idempotency key, then call service-only `record_verified_refund`. This worker is not yet connected.

Secrets must be installed with Supabase secret management, never `--dart-define`. Client bundles may contain only the public Supabase URL/publishable key. Configure `APP_ORIGIN`, `PAYMENT_PROVIDER`, `PAYMENT_API_BASE_URL`, `PAYMENT_SECRET_KEY`, `PAYMENT_WEBHOOK_SECRET`, `PAYMENT_RETURN_URL`, `PAYMENT_CHECKOUT_HOSTS`.
