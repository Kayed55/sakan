# Unit address and Google Maps

Choose a property in Add/Edit Unit, paste its complete street address and city, open the address in Google Maps, and save it with the dedicated Save Property Address button. The address belongs to the property and is shared by its units. Address saving is independent from saving/cancelling the unit record, as described in the form.

Exact addresses remain in property_private under existing catalog.write RLS. No new public address fields, API keys or automatic coordinate lookup. Existing coordinates are not modified. Google determines the search result; incomplete/ambiguous addresses can produce several results.

Verification: Flutter analysis clean; release admin build passed; pure Dart URL checks passed (Arabic, plus code, special characters, host isolation, empty and oversized query rejection). Browser demo verified saving, reopening and Google Maps search. No test addresses written to production.

Property creation also supports entering the private address and saving atomically with the property through a security-invoker RPC. Approximate coordinates are optional and pair/range-validated. Search-map markers omit properties with no valid coordinates. Migration 006 applied to production. All 13 database regression tests passed, including non-admin denial, private-address isolation, and rollback on invalid coordinate pairs.
