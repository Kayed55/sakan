# Design update — 18 September 2026

- Editorial split hero with a decorative photograph clearly labelled illustrative.
- Reusable Sakan wordmark and doorway motif, forest/ivory/sand palette.
- Responsive desktop navigation and mobile bottom navigation.
- Redesigned destination/date/guest search controls with clear labels.
- Redesigned onboarding, benefit strip and empty state treatment.
- Shared button, chip, navigation and form styling across customer and admin.
- Redesigned employee sign-in screen, dashboard greeting and responsive metric cards.
- Existing live authentication, permissions and booking calls retained.

Validation: Flutter analysis passed; customer and admin release web builds succeeded. Browser inspected desktop and 390px mobile layouts. Existing Flutter widget tests could not start because local test socket binding is denied in this environment; no test pass is claimed for this revision.

Deployment verified: GitHub commit `cfeafe7c2d1e98bb61dd955603727437ea2cb31f`, Vercel `GKpMRhWa6kzAwwFr3Q4GSVTFGxqw`, Ready in 3m 3s. Verified the redesigned customer home and employee sign-in on the public production domain, with no customer console errors observed.
