# روابط صفحات سكن

## الموقع
- `/` الرئيسية
- `/search` البحث، مع التواريخ والضيوف والفلاتر في query string
- `/map` الخريطة
- `/favorites` المفضلة
- `/units/:id` تفاصيل وحدة منشورة، مستقلة عن توفرها للتواريخ المختارة
- `/checkout/:id` الحجز، مع `stage` للمرحلة و`booking` لاستعادة الحجز المؤقت بعد التحديث
- `/login` تسجيل الجوال والتحقق
- `/bookings` حجوزاتي
- `/bookings/:id` تفاصيل الحجز
- `/bookings/:id/chat` محادثة الحجز
- `/notifications` الإشعارات
- `/account` الحساب
- `/account/details` بيانات الحساب وخياراته
- `/account/profile` تحرير بياناتي
- `/account/payments` طرق الدفع
- `/account/notifications` تفضيلات الإشعارات
- `/account/invoices` الفواتير

## الإدارة
كل قسم يستخدم `/admin/<section>`، وتحولت الشرطة السفلية في مفاتيح النظام إلى شرطة عادية في URL:
`dashboard`, `bookings`, `booking-chats`, `properties`, `units`, `calendar`, `operations-tasks`, `access-instructions`, `maintenance-requests`, `profiles`, `payments`, `refunds`, `coupons`, `home-content`, `reviews`, `notifications`, `reports`, `user-roles`, `settings`, `alerts`, `support-requests`, `assigned-tasks`, `audit-logs`.

روابط إضافية: `/admin/login`، `/admin/unit-images`، `/admin/property-addresses`، `/admin/settings/regions`، `/admin/settings/cities`، `/admin/settings/districts`، `/admin/chats/:id`.

النوافذ المؤقتة، مثل الفلاتر والتواريخ وتحرير السجلات، تبقى نوافذ داخل صفحاتها.

## الحماية والتوافق
- المسارات مبنية على Flutter Router عبر go_router، مع PathUrlStrategy.
- رابط الحجز الخاص لا يحمل اسم الضيف أو رقم هاتفه أو بيانات الدفع. الوصول يعتمد على الجلسة الحالية وRLS.
- الصفحة لا تصبح متاحة إداريًا لمجرد معرفة رابطها؛ يتم فحص صلاحية القسم.
- حالة نجاح الدفع لا تعتمد على `stage=success` في URL، بل على حالة الحجز المعتمدة من الخادم.
- إعادة تحميل الحجز المؤقت تستعيد سجله، ولا تُنشئ حجزًا أو دفعة تلقائيًا.
- الروابط القديمة `/customer/` تُحوّل إلى الجذر.
- Vercel يخدم ملف العميل من الجذر وملف الإدارة من `/admin/` مع fallback لكل مسار، مع بقاء ملفات الأصول ثابتة.
- البيانات الفعلية تُقرأ من جداول Supabase القائمة بسياسات RLS نفسها. لا تغيير في قاعدة البيانات أو صلاحياتها.
