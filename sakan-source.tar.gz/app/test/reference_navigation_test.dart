import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/customer/app.dart';

void main() {
  for (final width in [320, 375, 390, 430, 768, 1024, 1366, 1440]) {
    testWidgets('Reference search and account navigation at $width', (
      tester,
    ) async {
      tester.view.physicalSize = Size(width.toDouble(), 1000);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({'demo_signed_in': true});
      final repo = SakanRepository(
        demo: true,
        prefs: await SharedPreferences.getInstance(),
      );
      await tester.pumpWidget(SakanApp(repo: repo));
      await tester.pump(const Duration(seconds: 1));
      await tester.pumpAndSettle();
      await tester.scrollUntilVisible(
        find.text('ابحث عن إقامة'),
        250,
        scrollable: find.byType(Scrollable).first,
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('ابحث عن إقامة'));
      await tester.pumpAndSettle();
      expect(tester.takeException(), isNull);
      if (width >= 1000) {
        expect(find.text('خصّص إقامتك'), findsOneWidget);
        await tester.tap(
          find.descendant(
            of: find.byType(AppBar),
            matching: find.text('حسابي'),
          ),
        );
      } else {
        await tester.tap(
          find.descendant(
            of: find.byType(NavigationBar),
            matching: find.text('حسابي'),
          ),
        );
      }
      await tester.pumpAndSettle();
      expect(find.text('بياناتك وتفضيلاتك، في مكان واحد.'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.tap(find.widgetWithText(ListTile, 'طرق الدفع'));
      await tester.pumpAndSettle();
      expect(find.text('لا توجد بطاقات محفوظة'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
