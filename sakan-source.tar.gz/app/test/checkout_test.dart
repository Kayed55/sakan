import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/bootstrap.dart';
import 'package:sakan/core/models.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/customer/booking.dart';

void main() {
  testWidgets('customer completes review, guest details and demo payment', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(800, 1200);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({
      'demo_signed_in': true,
      'demo_phone': '+966500000001',
    });
    final repo = SakanRepository(
      demo: true,
      prefs: await SharedPreferences.getInstance(),
    );
    final start = dayOnly(DateTime.now()).add(const Duration(days: 1));
    final stay = Stay(start, start.add(const Duration(days: 2)));
    final unit = (await repo.units(stay)).first;
    await tester.pumpWidget(
      MaterialApp(
        theme: sakanTheme(),
        locale: const Locale('ar'),
        supportedLocales: locales,
        localizationsDelegates: delegates,
        home: CheckoutPage(repo: repo, unit: unit, stay: stay),
      ),
    );
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('متابعة'));
    await tester.tap(find.text('متابعة'));
    await tester.pumpAndSettle();
    await tester.enterText(
      find.widgetWithText(TextField, 'اسم الضيف الرئيسي'),
      'ضيف الاختبار',
    );
    await tester.tap(find.text('متابعة للدفع'));
    await tester.pumpAndSettle();
    expect(find.text('محاكاة نجاح الدفع'), findsOneWidget);
    await tester.tap(find.text('محاكاة نجاح الدفع'));
    await tester.pumpAndSettle();
    expect(find.text('مكانك ينتظرك'), findsOneWidget);
    expect((await repo.bookings()).single.status, 'confirmed');
    expect(repo.local['payments']!.length, 1);
    await tester.pumpWidget(const SizedBox.shrink());
  });
}
