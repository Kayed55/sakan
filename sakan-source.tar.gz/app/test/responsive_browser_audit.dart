// Development-only browser layout audit. Never included by either app entrypoint.
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/bootstrap.dart';
import 'package:sakan/core/models.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/customer/app.dart';
import 'package:sakan/customer/auth.dart';
import 'package:sakan/customer/booking.dart';
import 'package:sakan/customer/design.dart';
import 'package:sakan/customer/widgets.dart';
import 'package:sakan/admin/app.dart';
import 'package:sakan/admin/editor.dart';
import 'package:sakan/admin/actions.dart';
import 'package:sakan/admin/calendar.dart';
import 'package:sakan/admin/images.dart';
import 'package:sakan/admin/login.dart';
import 'package:sakan/chat/chat.dart';
import 'package:sakan/ui/system.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SemanticsBinding.instance.ensureSemantics();
  SharedPreferences.setMockInitialValues({
    'onboarded': true,
    'demo_signed_in': true,
  });
  final repo = SakanRepository(
    demo: true,
    prefs: await SharedPreferences.getInstance(),
  );
  final stay = Stay(
    DateTime.now().add(const Duration(days: 1)),
    DateTime.now().add(const Duration(days: 3)),
  );
  final unit = (await repo.units(stay)).first;
  // Reuse the existing demo checkout API in isolated in-memory test preferences.
  final booking = await repo.hold(unit, stay, 'responsive-audit');
  runApp(Audit(repo, stay, unit, booking));
}

class Audit extends StatefulWidget {
  final SakanRepository repo;
  final Stay stay;
  final Unit unit;
  final Booking booking;
  const Audit(this.repo, this.stay, this.unit, this.booking, {super.key});
  @override
  State<Audit> createState() => _AuditState();
}

class _AuditState extends State<Audit> {
  final widths = [320, 375, 390, 430, 768, 1024, 1366, 1440];
  final failures = <String>[];
  final results = <String>[];
  String current = 'Ready';
  Widget? preview;
  double width = 320;
  bool running = false, done = false;
  late final cases = <String, Widget Function()>{
    'admin-shell': () => AdminShell(widget.repo),
    'dashboard': () => Dashboard(widget.repo, kind: 'dashboard'),
    'reports': () => Dashboard(widget.repo, kind: 'reports'),
    'alerts': () => Dashboard(widget.repo, kind: 'alerts'),
    for (final p in pages.where(
      (p) => ![
        'dashboard',
        'reports',
        'alerts',
        'booking_chats',
        'assigned_tasks',
        'calendar',
        'settings',
      ].contains(p.$1),
    ))
      'records-${p.$1}': () => Scaffold(
        body: RecordsPanel(widget.repo, table: p.$1, title: p.$2),
      ),
    for (final table in definitions.keys)
      'form-$table': () => Scaffold(
        body: Center(child: RecordEditor(widget.repo, table: table)),
      ),
    'settings': () => Scaffold(body: SettingsPanel(widget.repo)),
    'booking-settings': () => Scaffold(
      body: Center(
        child: BookingSettings(
          widget.repo,
          widget.repo.local['settings']!.first,
        ),
      ),
    ),
    'calendar': () => Scaffold(body: AdminCalendar(widget.repo)),
    'images': () => ImagesPanel(widget.repo),
    'staff-tasks': () => Scaffold(body: StaffTasks(widget.repo)),
    'notify-form': () =>
        Scaffold(body: Center(child: NotificationComposer(widget.repo))),
    'refund-form': () => Scaffold(
      body: Center(child: RefundComposer(widget.repo, {'amount': 10000})),
    ),
    'inbox': () => Scaffold(body: ChatInbox(widget.repo)),
    'chat': () => BookingChat(
      repo: widget.repo,
      bookingId: widget.booking.id,
      bookingNumber: widget.booking.number,
    ),
    'home-ar': () =>
        HomeShell(repo: widget.repo, english: false, onLanguage: () {}),
    'home-en': () =>
        HomeShell(repo: widget.repo, english: true, onLanguage: () {}),
    'onboarding': () => Scaffold(
      body: PageList(
        children: [
          EditorialHero(welcome: true, onStart: () {}),
          const SakanDetails(),
        ],
      ),
    ),
    'stay-journey': () => Scaffold(
      body: SingleChildScrollView(
        child: StayJourney(english: false, onExplore: () {}),
      ),
    ),
    'stay-journey-en': () => Scaffold(
      body: SingleChildScrollView(
        child: StayJourney(english: true, onExplore: () {}),
      ),
    ),
    'unit-detail': () => UnitPage(
      repo: widget.repo,
      unit: widget.unit,
      stay: widget.stay,
      english: false,
    ),
    'checkout': () =>
        CheckoutPage(repo: widget.repo, unit: widget.unit, stay: widget.stay),
    'bookings': () =>
        Scaffold(body: BookingsPage(widget.repo, onLogin: () async => true)),
    'booking-detail': () => BookingDetail(widget.repo, widget.booking),
    'customer-login': () => LoginPage(widget.repo),
    'staff-login': () => AdminLoginPage(widget.repo),
    'staff-welcome': () => AdminWelcome(onLogin: () {}),
    'notifications': () => NotificationsPage(widget.repo),
    'profile': () => ProfilePage(widget.repo),
    'large-text-home': () => MediaQuery(
      data: MediaQueryData(
        size: Size(width, 800),
        textScaler: TextScaler.linear(1.4),
      ),
      child: HomeShell(repo: widget.repo, english: false, onLanguage: () {}),
    ),
    'long-unit': () => UnitPage(
      repo: widget.repo,
      unit: Unit({
        ...widget.unit.data,
        'name_ar':
            'اسم إقامة عربي طويل لاختبار التفاف العناوين دون خروج النص من حدود الشاشة',
        'description_ar': 'وصف طويل للإقامة ومرافقها وخدماتها. ' * 20,
      }),
      stay: widget.stay,
      english: false,
    ),
    'large-price': () => Scaffold(
      body: PageList(
        maxWidth: 720,
        children: [
          PriceBreakdown({
            'nights': [
              {'day': '2026-09-19', 'price': 999999999999},
            ],
            'total': 999999999999,
            'subtotal': 999999999999,
          }),
        ],
      ),
    ),
    'long-empty-error': () => Scaffold(
      body: PageList(
        children: [
          EmptyState(
            'عنوان طويل لحالة عدم وجود بيانات أو حدوث خطأ في تحميل الصفحة',
            'يرجى التحقق من الاتصال وإعادة المحاولة. ' * 8,
          ),
          const CircularProgressIndicator(),
          const Tag('قيد المراجعة ويحتاج إلى إجراء من الفريق المسؤول'),
        ],
      ),
    ),
  };
  @override
  void initState() {
    super.initState();
    FlutterError.onError = (e) {
      final text = e.exceptionAsString();
      if (!text.contains('HTTP request failed') &&
          !text.contains('NetworkImage')) {
        failures.add('$current: $text');
        debugPrint('AUDIT_FAILURE $current: $text');
      }
    };
  }

  Future<void> run() async {
    if (running) return;
    setState(() => running = true);
    for (final w in widths) {
      for (final entry in cases.entries) {
        final before = failures.length;
        setState(() {
          width = w.toDouble();
          current = '${entry.key} @ $w';
          preview = entry.value();
        });
        await WidgetsBinding.instance.endOfFrame;
        await Future<void>.delayed(const Duration(milliseconds: 180));
        await WidgetsBinding.instance.endOfFrame;
        results.add('$current: ${failures.length == before ? 'PASS' : 'FAIL'}');
      }
      debugPrint('AUDIT_PROGRESS $w completed; failures ${failures.length}');
    }
    setState(() {
      running = false;
      done = true;
      preview = null;
    });
    debugPrint(
      'AUDIT_REPORT ${jsonEncode({'checks': results.length, 'widths': widths, 'cases': cases.keys.toList(), 'failures': failures})}',
    );
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: Row(
              children: [
                FilledButton(
                  onPressed: running ? null : run,
                  child: const Text('Run responsive audit'),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    '$current | ${results.length} checks | ${failures.length} failures',
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: preview == null
                ? SingleChildScrollView(
                    child: SelectableText(
                      done
                          ? 'AUDIT COMPLETE\n${results.length} checks\n${failures.join('\n')}'
                          : 'In-memory fixtures only. No production access.',
                    ),
                  )
                : Align(
                    alignment: Alignment.topCenter,
                    child: SizedBox(
                      width: width,
                      height: 800,
                      child: MaterialApp(
                        key: ValueKey(current),
                        theme: sakanTheme(),
                        locale: Locale(
                          current.contains('home-en') ? 'en' : 'ar',
                        ),
                        supportedLocales: locales,
                        localizationsDelegates: delegates,
                        builder: (c, child) => MediaQuery(
                          data: MediaQuery.of(
                            c,
                          ).copyWith(size: Size(width, 800)),
                          child: sakanViewport(c, child),
                        ),
                        home: preview,
                      ),
                    ),
                  ),
          ),
        ],
      ),
    ),
  );
}
