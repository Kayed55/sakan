import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/customer/app.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() async {
    final fonts = FontLoader('IBMPlexSansArabic');
    for (final weight in ['Regular', 'Medium', 'Bold']) {
      fonts.addFont(
        rootBundle.load('assets/fonts/IBMPlexSansArabic-$weight.ttf'),
      );
    }
    await fonts.load();
  });
  for (final size in [const Size(320, 740), const Size(390, 844)]) {
    testWidgets('Search is reachable on first mobile viewport ${size.width}', (
      tester,
    ) async {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({});
      final repo = SakanRepository(
        demo: true,
        prefs: await SharedPreferences.getInstance(),
      );
      await tester.pumpWidget(SakanApp(repo: repo));
      await tester.pump(const Duration(seconds: 1));
      await tester.pumpAndSettle();
      final search = find.widgetWithText(FilledButton, 'ابحث عن إقامة');
      expect(
        tester.getRect(search).bottom,
        lessThanOrEqualTo(tester.getRect(find.byType(NavigationBar)).top),
      );
      expect(find.byType(FloatingActionButton), findsNothing);
      await tester.tap(find.byTooltip('القائمة'));
      await tester.pumpAndSettle();
      expect(find.text('المساعدة'), findsOneWidget);
      expect(tester.takeException(), isNull);
    });
  }
}
