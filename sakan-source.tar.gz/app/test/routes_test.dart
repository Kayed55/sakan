import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/bootstrap.dart';
import 'package:sakan/core/models.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/core/routes.dart';
import 'package:sakan/customer/router.dart';
import 'package:sakan/customer/auth.dart';
import 'package:sakan/admin/router.dart';

class BookingOnlyRepository extends SakanRepository {
  BookingOnlyRepository(SharedPreferences superPrefs)
    : super(demo: true, prefs: superPrefs);
  @override
  Future<bool> allowed(String p) async => p == 'booking.read';
}

Future<SakanRepository> repository({bool signedIn = true}) async {
  SharedPreferences.setMockInitialValues({
    'demo_signed_in': signedIn,
    'demo_phone': '+966500000001',
  });
  return SakanRepository(
    demo: true,
    prefs: await SharedPreferences.getInstance(),
  );
}

Widget app(GoRouter r) => MaterialApp.router(
  theme: sakanTheme(),
  locale: const Locale('ar'),
  supportedLocales: locales,
  localizationsDelegates: delegates,
  routerConfig: r,
);
void main() {
  test('URL stay validates dates and guest bounds', () {
    final d = dayOnly(DateTime.now()).add(const Duration(days: 1));
    final s = Stay(d, d.add(const Duration(days: 2)), adults: 3, children: 1);
    final uri = Uri.parse(stayLocation('/search', s));
    expect(stayFromUri(uri).guests, 4);
    expect(
      () => stayFromUri(Uri.parse('/search?adults=999')),
      throwsStateError,
    );
    expect(
      () => stayFromUri(Uri.parse('/search?checkIn=2020-01-01')),
      throwsStateError,
    );
  });
  testWidgets(
    'Account deep link opens its section and browser route updates on tab selection',
    (t) async {
      final repo = await repository();
      final r = customerRouter(
        repo,
        () => false,
        () {},
        initialLocation: '/account/payments',
      );
      addTearDown(r.dispose);
      await t.pumpWidget(app(r));
      await t.pumpAndSettle();
      expect(find.text('لا توجد بطاقات محفوظة'), findsOneWidget);
      await t.tap(
        find.descendant(
          of: find.byType(NavigationBar),
          matching: find.text('استكشف'),
        ),
      );
      await t.pumpAndSettle();
      expect(r.routeInformationProvider.value.uri.path, '/search');
      expect(
        r.routeInformationProvider.value.uri.queryParameters['checkIn'],
        isNotNull,
      );
    },
  );
  testWidgets('Published unit deep link works even when it has a booking', (
    t,
  ) async {
    final repo = await repository();
    final d = dayOnly(DateTime.now()).add(const Duration(days: 1));
    final stay = Stay(d, d.add(const Duration(days: 2)));
    final unit = (await repo.units(stay)).first;
    await repo.hold(unit, stay, 'route-test');
    expect((await repo.units(stay)).any((u) => u.id == unit.id), false);
    final r = customerRouter(
      repo,
      () => false,
      () {},
      initialLocation: stayLocation('/units/${unit.id}', stay),
    );
    addTearDown(r.dispose);
    await t.pumpWidget(app(r));
    await t.pumpAndSettle();
    expect(find.text(unit.name), findsWidgets);
    expect(find.text('تعذر فتح الصفحة'), findsNothing);
  });
  testWidgets(
    'Private booking URL requests login without exposing booking data',
    (t) async {
      final repo = await repository(signedIn: false);
      final r = customerRouter(
        repo,
        () => false,
        () {},
        initialLocation: '/bookings/private-id',
      );
      addTearDown(r.dispose);
      await t.pumpWidget(app(r));
      await t.pumpAndSettle();
      expect(find.byType(LoginPage), findsOneWidget);
      expect(r.routeInformationProvider.value.uri.path, '/bookings/private-id');
    },
  );
  testWidgets('Unknown and unauthorized routes fail closed', (t) async {
    final repo = await repository();
    final r = customerRouter(
      repo,
      () => false,
      () {},
      initialLocation: '/missing-page',
    );
    addTearDown(r.dispose);
    await t.pumpWidget(app(r));
    await t.pumpAndSettle();
    expect(find.text('تعذر فتح الصفحة'), findsOneWidget);
    final limited = BookingOnlyRepository(repo.prefs);
    final admin = adminRouter(limited, initialLocation: '/user-roles');
    addTearDown(admin.dispose);
    await t.pumpWidget(app(admin));
    await t.pumpAndSettle();
    expect(
      find.text('لا يملك حسابك صلاحية الوصول إلى هذه الصفحة.'),
      findsOneWidget,
    );
  });
  testWidgets(
    'Payment URL restores the existing hold without creating a duplicate',
    (t) async {
      final repo = await repository();
      final d = dayOnly(DateTime.now()).add(const Duration(days: 1));
      final stay = Stay(d, d.add(const Duration(days: 2)));
      final unit = (await repo.units(stay)).first;
      final b = await repo.hold(unit, stay, 'hold-url');
      await repo.guest(b, 'ضيف اختبار', '+966500000001', '');
      final r = customerRouter(
        repo,
        () => false,
        () {},
        initialLocation: stayLocation(
          '/checkout/${unit.id}',
          stay,
          extra: {'booking': b.id, 'stage': 'payment'},
        ),
      );
      addTearDown(r.dispose);
      await t.pumpWidget(app(r));
      await t.pump(const Duration(milliseconds: 500));
      await t.pump(const Duration(milliseconds: 500));
      expect(find.text('إتمام الدفع'), findsOneWidget);
      expect((await repo.bookings()).length, 1);
      await t.pumpWidget(const SizedBox.shrink());
    },
  );
}
