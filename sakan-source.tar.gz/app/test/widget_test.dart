import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sakan/core/models.dart';
import 'package:sakan/core/repository.dart';
import 'package:sakan/customer/app.dart';
import 'package:sakan/admin/app.dart';

void main() {
  testWidgets('Arabic home is RTL, anonymous browsing and navigation render', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({'onboarded': true});
    final repo = SakanRepository(
      demo: true,
      prefs: await SharedPreferences.getInstance(),
    );
    await tester.pumpWidget(SakanApp(repo: repo));
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();
    expect(find.text('وين تبي تسكن؟'), findsOneWidget);
    expect(
      Directionality.of(tester.element(find.text('وين تبي تسكن؟'))),
      TextDirection.rtl,
    );
    expect(find.text('بحث عن سكن'), findsOneWidget);
    expect(repo.signedIn, false);
    await tester.tap(find.text('حجوزاتي'));
    await tester.pumpAndSettle();
    expect(find.text('ننتظر رحلتك الأولى'), findsOneWidget);
  });
  testWidgets('admin dashboard renders responsive navigation', (tester) async {
    tester.view.physicalSize = const Size(1440, 1000);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    SharedPreferences.setMockInitialValues({});
    final repo = SakanRepository(
      demo: true,
      prefs: await SharedPreferences.getInstance(),
    );
    await tester.pumpWidget(AdminApp(repo: repo));
    await tester.pumpAndSettle();
    expect(find.text('أهلًا، يوم جديد في سكن'), findsOneWidget);
    expect(find.text('إجمالي المدفوعات'), findsOneWidget);
    await tester.tap(find.text('الوحدات'));
    await tester.pumpAndSettle();
    expect(find.text('إضافة جديد'), findsOneWidget);
  });
  test('stay rejects invalid range and capacity', () {
    final day = DateTime(2030, 1, 1);
    expect(() => Stay(day, day).validate(today: day), throwsStateError);
    expect(
      () => Stay(
        day,
        day.add(const Duration(days: 2)),
        adults: 4,
      ).validate(capacity: 2, today: day),
      throwsStateError,
    );
  });
  test(
    'demo booking persists, prevents overlap, charges once, and releases cancelled hold',
    () async {
      SharedPreferences.setMockInitialValues({});
      final prefs = await SharedPreferences.getInstance();
      final r = SakanRepository(demo: true, prefs: prefs);
      await r.sendOtp('+966500000001');
      await r.verifyOtp('+966500000001', '123456');
      final today = dayOnly(DateTime.now()).add(const Duration(days: 1)),
          stay = Stay(
            dayOnly(DateTime.now()).add(const Duration(days: 1)),
            dayOnly(DateTime.now()).add(const Duration(days: 3)),
          );
      final u = (await r.units(stay)).first;
      final b = await r.hold(u, stay, 'test-1');
      expect((await r.hold(u, stay, 'test-1')).id, b.id);
      await expectLater(r.hold(u, stay, 'test-2'), throwsStateError);
      await r.guest(b, 'Test Guest', '+966500000001', '');
      await r.demoPay(b);
      await r.demoPay(b);
      expect(r.local['payments']!.length, 1);
      final restored = SakanRepository(demo: true, prefs: prefs);
      expect((await restored.bookings()).first.status, 'confirmed');
      final next = Stay(
        today.add(const Duration(days: 2)),
        today.add(const Duration(days: 3)),
      );
      final h = await restored.hold(u, next, 'next');
      await restored.cancel(h);
      expect((await restored.units(next)).any((v) => v.id == u.id), true);
    },
  );
}
