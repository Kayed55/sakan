// Pure Dart regression checks; no network or Flutter test host required.
import 'package:sakan/core/map_address.dart';

void main() {
  final addresses = [
    '3865 خريص الفرعي، حي النسيم الغربي، الرياض 14223',
    'PRQ2+CQ النسيم الغربي، الرياض',
    'Building A & B #12, Riyadh',
    'https://example.org/?q=test&other=value',
  ];
  for (final address in addresses) {
    final uri = googleMapsAddress('  $address  ');
    if (uri.scheme != 'https' ||
        uri.host != 'www.google.com' ||
        uri.path != '/maps/search/' ||
        uri.queryParameters['api'] != '1' ||
        uri.queryParameters['query'] != address ||
        uri.queryParameters.length != 2) {
      throw StateError('Unsafe or incorrectly encoded search URL');
    }
  }
  for (final invalid in ['', '   ', List.filled(600, 'ع').join()]) {
    var rejected = false;
    try {
      googleMapsAddress(invalid);
    } on FormatException {
      rejected = true;
    }
    if (!rejected) throw StateError('Invalid address was accepted');
  }
  // ignore: avoid_print
  print(
    'Passed: Arabic, plus codes, special characters, host isolation, empty and oversized queries.',
  );
}
