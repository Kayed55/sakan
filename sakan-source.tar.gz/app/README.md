# تطبيق سكن

راجع دليل المشروع في `../README.md`.

مدخل العميل: `lib/main.dart`، ومدخل الإدارة: `lib/admin_main.dart`.
العربية وRTL افتراضيان. `APP_MODE=demo` للتجربة و`APP_MODE=live` للربط الفعلي.
