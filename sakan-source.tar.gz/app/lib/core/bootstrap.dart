import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';
import 'repository.dart';

Future<SakanRepository> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();
  const mode = String.fromEnvironment('APP_MODE', defaultValue: 'demo');
  if (mode != 'demo' && mode != 'live') {
    throw StateError('APP_MODE must be demo or live');
  }
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (mode == 'live') {
    if (url.isEmpty || key.isEmpty) {
      throw StateError('إعدادات Supabase مطلوبة للوضع الحي');
    }
    await Supabase.initialize(url: url, publishableKey: key);
  }
  return SakanRepository(
    demo: mode == 'demo',
    prefs: await SharedPreferences.getInstance(),
    client: mode == 'live' ? Supabase.instance.client : null,
  );
}

ThemeData sakanTheme() => ThemeData(
  useMaterial3: true,
  scaffoldBackgroundColor: canvas,
  colorScheme: ColorScheme.fromSeed(
    seedColor: brand,
    primary: brand,
    surface: canvas,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: canvas,
    foregroundColor: brand,
    centerTitle: false,
  ),
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: Colors.white,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide.none,
    ),
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: FilledButton.styleFrom(
      minimumSize: const Size(100, 52),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
    ),
  ),
  cardTheme: CardThemeData(
    color: Colors.white,
    elevation: 0,
    margin: EdgeInsets.zero,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
  ),
  textTheme: const TextTheme(
    headlineLarge: TextStyle(
      fontSize: 34,
      fontWeight: FontWeight.w700,
      height: 1.35,
    ),
    headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
    titleLarge: TextStyle(fontSize: 21, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16, height: 1.6),
    bodyMedium: TextStyle(fontSize: 14, height: 1.5),
  ),
);
const locales = [Locale('ar'), Locale('en')];
const delegates = GlobalMaterialLocalizations.delegates;

class FailureApp extends StatelessWidget {
  final Object error;
  const FailureApp(this.error, {super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(
      body: Center(
        child: Text('تعذر بدء سكن\n$error', textDirection: TextDirection.rtl),
      ),
    ),
  );
}
