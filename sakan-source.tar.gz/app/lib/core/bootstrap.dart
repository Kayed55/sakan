import '../ui/system.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';
import 'repository.dart';

Future<SakanRepository> bootstrap() async {
  WidgetsFlutterBinding.ensureInitialized();
  const mode = String.fromEnvironment('APP_MODE', defaultValue: 'demo');
  if (mode != 'demo' && mode != 'live') {
    throw StateError('APP_MODE must be demo or live');
  }
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (mode == 'live') {
    if (url.isEmpty || key.isEmpty) {
      throw StateError('إعدادات Supabase مطلوبة للوضع الحي');
    }
    await Supabase.initialize(url: url, publishableKey: key);
  }
  return SakanRepository(
    demo: mode == 'demo',
    prefs: await SharedPreferences.getInstance(),
    client: mode == 'live' ? Supabase.instance.client : null,
  );
}

ThemeData sakanTheme() => ThemeData(
  useMaterial3: true,
  fontFamily: 'IBMPlexSansArabic',
  visualDensity: VisualDensity.standard,
  materialTapTargetSize: MaterialTapTargetSize.padded,
  focusColor: brand.withValues(alpha: .16),
  iconButtonTheme: IconButtonThemeData(
    style: IconButton.styleFrom(minimumSize: const Size(48, 48)),
  ),
  textButtonTheme: TextButtonThemeData(
    style: TextButton.styleFrom(
      foregroundColor: brandInk,
      minimumSize: const Size(48, 48),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
    ),
  ),
  dialogTheme: DialogThemeData(
    backgroundColor: surface,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(SakanLayout.radius),
    ),
    insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
  ),
  bottomSheetTheme: const BottomSheetThemeData(
    backgroundColor: surface,
    showDragHandle: true,
    constraints: BoxConstraints(maxWidth: 720),
  ),

  dividerTheme: const DividerThemeData(color: Color(0xffe9dfc9), thickness: 1),
  navigationBarTheme: NavigationBarThemeData(
    backgroundColor: surface,
    elevation: 0,
    height: 76,
    indicatorColor: const Color(0xffe4ecf3),
    labelTextStyle: const WidgetStatePropertyAll(
      TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
    ),
  ),
  outlinedButtonTheme: OutlinedButtonThemeData(
    style: OutlinedButton.styleFrom(
      foregroundColor: brandInk,
      minimumSize: const Size(48, 48),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      side: const BorderSide(color: Color(0xffd8cbae)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  ),
  chipTheme: ChipThemeData(
    side: const BorderSide(color: Color(0xffd8cbae)),
    backgroundColor: surface,
    selectedColor: const Color(0xffe4ecf3),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),

  scaffoldBackgroundColor: canvas,
  colorScheme: ColorScheme.fromSeed(
    seedColor: brand,
    primary: brand,
    onPrimary: Colors.white,
    secondary: brandOlive,
    onSecondary: brandInk,
    tertiary: brandOrange,
    onTertiary: brandInk,
    surface: canvas,
    onSurface: brandInk,
  ),
  appBarTheme: const AppBarTheme(
    backgroundColor: canvas,
    foregroundColor: brandInk,
    shape: Border(bottom: BorderSide(color: outline)),
    toolbarHeight: 68,
    titleTextStyle: TextStyle(
      fontFamily: "IBMPlexSansArabic",
      fontSize: 18,
      fontWeight: FontWeight.w600,
      color: brandInk,
    ),
    centerTitle: false,
    scrolledUnderElevation: 0,
    surfaceTintColor: Colors.transparent,
  ),
  inputDecorationTheme: InputDecorationTheme(
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
    errorMaxLines: 4,
    helperMaxLines: 4,
    floatingLabelStyle: const TextStyle(color: brand),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: brand, width: 2),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xff963f3f)),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xff963f3f), width: 2),
    ),
    filled: true,
    fillColor: Colors.white,
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xffd8cbae)),
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: Color(0xffd8cbae)),
    ),
  ),
  filledButtonTheme: FilledButtonThemeData(
    style: FilledButton.styleFrom(
      backgroundColor: brand,
      foregroundColor: Colors.white,
      minimumSize: const Size(100, 54),
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
      textStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
  ),
  cardTheme: CardThemeData(
    color: surface,
    elevation: 0,
    margin: EdgeInsets.zero,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16),
      side: const BorderSide(color: outline),
    ),
  ),
  textTheme: const TextTheme(
    headlineLarge: TextStyle(
      fontSize: 34,
      fontWeight: FontWeight.w300,
      height: 1.3,
    ),
    headlineSmall: TextStyle(fontSize: 28, fontWeight: FontWeight.w400),
    titleLarge: TextStyle(fontSize: 19, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16, height: 1.6),
    bodyMedium: TextStyle(fontSize: 14, height: 1.5),
  ),
);
const locales = [Locale('ar'), Locale('en')];
const delegates = GlobalMaterialLocalizations.delegates;

class FailureApp extends StatelessWidget {
  final Object error;
  const FailureApp(this.error, {super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    home: Scaffold(
      body: Center(
        child: Text('تعذر بدء سكن\n$error', textDirection: TextDirection.rtl),
      ),
    ),
  );
}
