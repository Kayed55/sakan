import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'models.dart';

export 'package:go_router/go_router.dart';

/// URL state never contains guest identity, authentication tokens or payment data.
Stay stayFromUri(Uri uri) {
  final q = uri.queryParameters;
  final today = dayOnly(DateTime.now());
  final start =
      DateTime.tryParse(q['checkIn'] ?? '') ??
      today.add(const Duration(days: 1));
  final end =
      DateTime.tryParse(q['checkOut'] ?? '') ??
      start.add(const Duration(days: 2));
  final stay = Stay(
    start,
    end,
    adults: int.tryParse(q['adults'] ?? '') ?? 2,
    children: int.tryParse(q['children'] ?? '') ?? 0,
  );
  stay.validate();
  if (stay.adults > 30 || stay.children > 30) {
    throw StateError('عدد الضيوف غير صالح');
  }
  return stay;
}

String stayLocation(
  String path,
  Stay stay, {
  Map<String, String> extra = const {},
}) => Uri(
  path: path,
  queryParameters: {
    'checkIn': dateKey(stay.start),
    'checkOut': dateKey(stay.end),
    'adults': '${stay.adults}',
    'children': '${stay.children}',
    ...extra,
  },
).toString();

Future<T?> openPage<T>(
  BuildContext context,
  String location,
  WidgetBuilder fallback, {
  Object? extra,
}) {
  final router = GoRouter.maybeOf(context);
  if (router != null) return router.push<T>(location, extra: extra);
  return Navigator.push<T>(context, MaterialPageRoute(builder: fallback));
}

void finishPage(BuildContext context, [Object? result]) {
  if (Navigator.of(context).canPop()) {
    Navigator.pop(context, result);
  } else {
    GoRouter.maybeOf(context)?.go('/');
  }
}

class RouteFailure extends StatelessWidget {
  final String message;
  const RouteFailure([
    this.message = 'الصفحة غير موجودة أو لم يعد الرابط صالحًا.',
    Key? key,
  ]) : super(key: key);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('تعذر فتح الصفحة')),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.link_off, size: 44, color: brand),
            const SizedBox(height: 20),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => GoRouter.maybeOf(context)?.go('/'),
              child: const Text('العودة للرئيسية'),
            ),
          ],
        ),
      ),
    ),
  );
}

/// Keeps a single lookup alive across rebuilds; errors do not leak private rows.
class ResolvedRoute<T> extends StatefulWidget {
  final Future<T?> Function() load;
  final Widget Function(T) builder;
  const ResolvedRoute({required this.load, required this.builder, super.key});
  @override
  State<ResolvedRoute<T>> createState() => _ResolvedRouteState<T>();
}

class _ResolvedRouteState<T> extends State<ResolvedRoute<T>> {
  late final Future<T?> result = widget.load();
  @override
  Widget build(BuildContext context) => FutureBuilder<T?>(
    future: result,
    builder: (context, s) {
      if (s.connectionState != ConnectionState.done) {
        return const Scaffold(body: Center(child: CircularProgressIndicator()));
      }
      if (s.hasError || s.data == null) {
        return const RouteFailure(
          'العنصر غير متاح أو لا تملك صلاحية الوصول إليه.',
        );
      }
      return widget.builder(s.data as T);
    },
  );
}

void replacePage(
  BuildContext context,
  String location,
  WidgetBuilder fallback,
) {
  final router = GoRouter.maybeOf(context);
  if (router != null) {
    router.go(location);
  } else {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: fallback));
  }
}
