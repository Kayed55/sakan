import 'package:flutter/material.dart';

typedef Json = Map<String, dynamic>;
String dateKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
DateTime dayOnly(DateTime d) => DateTime(d.year, d.month, d.day);
String money(num halalas) =>
    '${(halalas / 100).toStringAsFixed(halalas % 100 == 0 ? 0 : 2)} ر.س';
String statusLabel(String s) =>
    const {
      'hold': 'بانتظار الدفع',
      'confirmed': 'مؤكد',
      'checked_in': 'إقامة حالية',
      'completed': 'مكتمل',
      'cancelled': 'ملغي',
      'expired': 'انتهت المهلة',
      'pending': 'بانتظار التنفيذ',
      'assigned': 'مسندة',
      'in_progress': 'قيد التنفيذ',
      'inspection': 'بانتظار الفحص',
      'done': 'جاهزة',
      'published': 'منشورة',
      'draft': 'مسودة',
      'hidden': 'مخفية',
      'maintenance': 'صيانة',
      'paid': 'مدفوع',
      'requested': 'طلب جديد',
      'approved': 'معتمد',
      'refund_required': 'يحتاج استرداد',
      'open': 'مفتوح',
      'resolved': 'تم الحل',
    }[s] ??
    s;

class Stay {
  final DateTime start, end;
  final int adults, children;
  Stay(this.start, this.end, {this.adults = 2, this.children = 0});
  int get guests => adults + children;
  int get nights => dayOnly(end).difference(dayOnly(start)).inDays;
  void validate({int? capacity, DateTime? today}) {
    if (dayOnly(start).isBefore(dayOnly(today ?? DateTime.now())) ||
        nights < 1 ||
        nights > 60 ||
        adults < 1 ||
        children < 0) {
      throw StateError('اختر تواريخ صحيحة، بحد أقصى 60 ليلة');
    }
    if (capacity != null && guests > capacity) {
      throw StateError('عدد الضيوف يتجاوز سعة الوحدة');
    }
  }

  Json get rpc => {
    'p_check_in': dateKey(start),
    'p_check_out': dateKey(end),
    'p_guests': guests,
  };
}

class Unit {
  final Json data;
  Unit(this.data);
  String get id => data['id'];
  String get name => data['name_ar'];
  String nameFor(bool en) => data[en ? 'name_en' : 'name_ar'] ?? name;
  int get price => (data['base_price'] as num).toInt();
  int get capacity => data['capacity'];
  int get bedrooms => data['bedrooms'] ?? 0;
  String get kind => data['kind'];
  String get district => data['district'] ?? 'الرياض';
  bool get hasMapLocation =>
      data['approx_lat'] is num &&
      data['approx_lng'] is num &&
      (data['approx_lat'] as num).abs() <= 90 &&
      (data['approx_lng'] as num).abs() <= 180;
  double get lat => (data['approx_lat'] as num? ?? 24.8).toDouble();
  double get lng => (data['approx_lng'] as num? ?? 46.62).toDouble();
  List<String> get images => List<String>.from(data['images'] ?? []);
  List<String> get amenities => List<String>.from(data['amenities'] ?? []);
}

class Booking {
  final Json data;
  Booking(this.data);
  String get id => data['id'];
  String get number => data['booking_number'];
  String get unitId => data['unit_id'];
  String get status => data['status'];
  int get total => data['total'];
  bool get expired =>
      status == 'expired' ||
      (status == 'hold' &&
          DateTime.parse(data['hold_expires_at']).isBefore(DateTime.now()));
}

const brand = Color(0xff234c3c);
const canvas = Color(0xfff6f4ed);
const gold = Color(0xffc2a173);
const photos = [
  'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=1200&q=85',
  'https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=1200&q=85',
  'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=85',
];
List<Json> demoUnits() => List.generate(
  3,
  (i) => {
    'id': '50000000-0000-0000-0000-00000000000${i + 1}',
    'property_id': '40000000-0000-0000-0000-00000000000${i + 1}',
    'code': ['YAS-101', 'MAL-201', 'HIT-301'][i],
    'name_ar': [
      'استديو الياسمين الهادئ',
      'شقة الملقا • غرفة وصالة',
      'رحابة حطين • غرفتان',
    ][i],
    'name_en': [
      'The Yasmin Studio',
      'Al Malqa Residence',
      'Hittin Family Suite',
    ][i],
    'description_ar':
        'مساحة هادئة بتفاصيل مدروسة، ومطبخ مجهز وكل ما تحتاجه لإقامة مريحة في شمال الرياض.',
    'description_en':
        'A calm, thoughtfully designed space with an equipped kitchen in north Riyadh.',
    'district': ['الياسمين', 'الملقا', 'حطين'][i],
    'kind': i == 0 ? 'studio' : 'apartment',
    'capacity': [2, 3, 5][i],
    'bedrooms': i,
    'beds': i + 1,
    'bathrooms': i == 2 ? 2 : 1,
    'area': [45, 80, 120][i],
    'base_price': [35000, 48000, 69000][i],
    'status': 'published',
    'min_nights': 1,
    'approx_lat': [24.82, 24.80, 24.77][i],
    'approx_lng': [46.64, 46.60, 46.59][i],
    'images': [photos[i], photos[(i + 1) % 3]],
    'amenities': ['واي فاي', 'مطبخ', 'موقف سيارة', 'دخول ذاتي', 'تكييف'],
  },
);
