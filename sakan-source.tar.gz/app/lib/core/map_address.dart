/// Google Maps universal search URL. This opens a search, not verified coordinates.
Uri googleMapsAddress(String address) {
  final query = address.trim();
  if (query.isEmpty) throw const FormatException('أدخل العنوان أولًا');
  if (query.length > 1000) throw const FormatException('العنوان طويل جدًا');
  final uri = Uri.https('www.google.com', '/maps/search/', {
    'api': '1',
    'query': query,
  });
  if (uri.toString().length > 2048) {
    throw const FormatException('اختصر العنوان مع إبقاء الشارع والحي والمدينة');
  }
  return uri;
}
