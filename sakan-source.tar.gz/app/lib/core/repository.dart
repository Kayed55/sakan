import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import 'models.dart';

class SakanRepository extends ChangeNotifier {
  final bool demo;
  final SharedPreferences prefs;
  final SupabaseClient? client;
  late Map<String, List<Json>> local;
  SakanRepository({required this.demo, required this.prefs, this.client}) {
    final saved = prefs.getString('sakan_demo_v1');
    local = saved == null
        ? _initial()
        : (jsonDecode(saved) as Map<String, dynamic>).map(
            (k, v) => MapEntry(
              k,
              (v as List).map((e) => Map<String, dynamic>.from(e)).toList(),
            ),
          );
  }
  Map<String, List<Json>> _initial() => {
    'units': demoUnits(),
    'bookings': [],
    'payments': [],
    'refunds': [],
    'favorites': [],
    'reviews': [],
    'notifications': [],
    'booking_guests': [],
    'unit_rates': [],
    'inventory_locks': [],
    'profiles': [
      {'id': 'demo-user', 'full_name': 'ضيف سكن', 'email': ''},
    ],
    'properties': List.generate(
      3,
      (i) => {
        'id': '40000000-0000-0000-0000-00000000000${i + 1}',
        'code': ['RYD-YAS-01', 'RYD-MAL-01', 'RYD-HIT-01'][i],
        'name_ar': ['سكن الياسمين', 'سكن الملقا', 'سكن حطين'][i],
        'name_en': 'Sakan Residence',
        'district_id': '30000000-0000-0000-0000-00000000000${i + 1}',
        'approx_lat': 24.8,
        'approx_lng': 46.6,
        'is_active': true,
      },
    ),
    'districts': List.generate(
      3,
      (i) => {
        'id': '30000000-0000-0000-0000-00000000000${i + 1}',
        'name_ar': ['الياسمين', 'الملقا', 'حطين'][i],
      },
    ),
    'cities': [
      {
        'id': '20000000-0000-0000-0000-000000000001',
        'name_ar': 'الرياض',
        'name_en': 'Riyadh',
        'is_active': true,
      },
    ],
    'regions': [
      {
        'id': '10000000-0000-0000-0000-000000000001',
        'name_ar': 'منطقة الرياض',
        'name_en': 'Riyadh Region',
      },
    ],
    'operations_tasks': [
      {
        'id': 'demo-task',
        'unit_id': demoUnits()[1]['id'],
        'kind': 'cleaning',
        'status': 'pending',
        'notes': 'تغيير المفارش وفحص المكيف',
        'checklist': {},
      },
    ],
    'maintenance_requests': [],
    'coupons': [],
    'home_content': [
      {
        'id': 'demo-banner',
        'title_ar': 'إقامة تشبهك، في قلب الرياض',
        'title_en': 'Find your place in Riyadh',
        'kind': 'banner',
        'is_active': true,
        'sort_order': 0,
      },
    ],
    'user_roles': [
      {'user_id': 'demo-user', 'role_id': 'super_admin'},
    ],
    'settings': [
      {
        'key': 'booking',
        'value': {'hold_minutes': 10, 'service_fee': 0, 'tax_basis_points': 0},
      },
    ],
    'audit_logs': [],
    'support_requests': [],
    'access_instructions': [],
  };
  bool get signedIn => demo
      ? prefs.getBool('demo_signed_in') ?? false
      : client!.auth.currentUser != null;
  String? get userId =>
      demo ? (signedIn ? 'demo-user' : null) : client!.auth.currentUser?.id;
  String get phone => demo
      ? prefs.getString('demo_phone') ?? ''
      : '+${client!.auth.currentUser?.phone ?? ''}'.replaceFirst('++', '+');
  Future<void> save() async {
    await prefs.setString('sakan_demo_v1', jsonEncode(local));
    notifyListeners();
  }

  Future<void> sendOtp(String phone) async {
    if (!RegExp(r'^\+9665[0-9]{8}$').hasMatch(phone)) {
      throw StateError('أدخل جوالًا سعوديًا صحيحًا');
    }
    if (demo) {
      await prefs.setString('demo_phone', phone);
    } else {
      await client!.auth.signInWithOtp(phone: phone);
    }
  }

  Future<void> verifyOtp(String phone, String code) async {
    if (demo) {
      if (code != '123456') {
        throw StateError('رمز التجربة: 123456');
      }
      await prefs.setBool('demo_signed_in', true);
    } else {
      await client!.auth.verifyOTP(
        phone: phone,
        token: code,
        type: OtpType.sms,
      );
    }
    notifyListeners();
  }

  // Authentication never grants a staff role. PostgreSQL RBAC remains authoritative.
  Future<void> signInStaff(String email, String password) async {
    if (demo) throw StateError('Staff authentication requires live mode');
    await client!.auth.signInWithPassword(email: email, password: password);
    notifyListeners();
  }

  Future<void> signOut() async {
    if (demo) {
      await prefs.setBool('demo_signed_in', false);
    } else {
      await client!.auth.signOut();
    }
    notifyListeners();
  }

  Future<bool> allowed(String permission) async =>
      demo ||
      await client!.rpc(
            'has_permission',
            params: {'p_permission': permission},
          ) ==
          true;
  Future<List<Json>> table(String table) async {
    if (demo) {
      return (local[table] ?? [])
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    return List<Json>.from(await client!.from(table).select().limit(500));
  }

  Future<Json?> propertyLocation(String propertyId) async {
    if (demo) {
      for (final row in local['property_private'] ?? <Json>[]) {
        if (row['property_id'] == propertyId) return {...row};
      }
      return null;
    }
    return await client!
        .from('property_private')
        .select()
        .eq('property_id', propertyId)
        .maybeSingle();
  }

  Future<void> savePropertyAddress(String propertyId, String address) async {
    if (address.trim().isEmpty || address.trim().length > 1000) {
      throw StateError('أدخل عنوانًا صحيحًا');
    }
    // Upsert only the address, preserving existing exact coordinates.
    if (demo) {
      final rows = local.putIfAbsent('property_private', () => <Json>[]);
      final index = rows.indexWhere((r) => r['property_id'] == propertyId);
      if (index < 0) {
        rows.add({'property_id': propertyId, 'address': address.trim()});
      } else {
        rows[index] = {...rows[index], 'address': address.trim()};
      }
      await save();
    } else {
      await client!.from('property_private').upsert({
        'property_id': propertyId,
        'address': address.trim(),
      }, onConflict: 'property_id');
    }
  }

  Future<void> upsert(String table, Json record) async {
    if (demo) {
      final list = local.putIfAbsent(table, () => []);
      final key = table == 'settings' ? 'key' : 'id';
      final row = Map<String, dynamic>.from(record);
      row[key] ??= const Uuid().v4();
      final index = list.indexWhere((e) => e[key] == row[key]);
      if (index < 0) {
        list.add(row);
      } else {
        list[index] = {...list[index], ...row};
      }
      local['audit_logs']!.insert(0, {
        'id': const Uuid().v4(),
        'table_name': table,
        'action': index < 0 ? 'INSERT' : 'UPDATE',
        'created_at': DateTime.now().toIso8601String(),
      });
      if (table == 'maintenance_requests' &&
          row['blocks_sale'] == true &&
          row['status'] != 'resolved') {
        for (final u in local['units']!) {
          if (u['id'] == row['unit_id']) u['status'] = 'maintenance';
        }
      }
      await save();
    } else {
      if (['support_requests', 'reviews', 'device_tokens'].contains(table)) {
        await client!.from(table).insert(record);
      } else {
        await client!.from(table).upsert(record);
      }
      notifyListeners();
    }
  }

  Future<List<Unit>> units(Stay stay) async {
    stay.validate();
    if (demo) {
      _expire();
      return local['units']!
          .where(
            (u) =>
                u['status'] == 'published' &&
                u['capacity'] >= stay.guests &&
                !local['bookings']!.any(
                  (b) =>
                      b['unit_id'] == u['id'] &&
                      [
                        'hold',
                        'confirmed',
                        'checked_in',
                      ].contains(b['status']) &&
                      DateTime.parse(b['check_in']).isBefore(stay.end) &&
                      DateTime.parse(b['check_out']).isAfter(stay.start),
                ) &&
                !local['inventory_locks']!.any(
                  (l) =>
                      l['unit_id'] == u['id'] &&
                      DateTime.parse(l['start']).isBefore(stay.end) &&
                      DateTime.parse(l['end']).isAfter(stay.start),
                ),
          )
          .map((u) {
            final pictures =
                (local['unit_images'] ?? <Json>[])
                    .where((i) => i['unit_id'] == u['id'])
                    .toList()
                  ..sort((a, b) {
                    if (a['is_cover'] == true) return -1;
                    if (b['is_cover'] == true) return 1;
                    return (a['sort_order'] as int).compareTo(
                      b['sort_order'] as int,
                    );
                  });
            return Unit({
              ...u,
              if (pictures.isNotEmpty)
                'images': pictures.map((i) => i['image_url']).toList(),
            });
          })
          .toList();
    }
    final rows = List<Json>.from(
      await client!.rpc('search_units', params: stay.rpc),
    );
    final properties = await client!
        .from('properties')
        .select('*,districts(name_ar)');
    final images = await table('unit_images');
    final amen = await client!
        .from('unit_amenities')
        .select('unit_id,amenities(name_ar)');
    return rows.map((r) {
      final p = properties
          .where((p) => p['id'] == r['property_id'])
          .firstOrNull;
      return Unit({
        ...r,
        'district': p?['districts']?['name_ar'],
        'approx_lat': p?['approx_lat'],
        'approx_lng': p?['approx_lng'],
        'images':
            (images.where((i) => i['unit_id'] == r['id']).toList()..sort(
                  (a, b) => (a['sort_order'] as int).compareTo(b['sort_order']),
                ))
                .map((i) => i['image_url'])
                .toList(),
        'amenities': amen
            .where((a) => a['unit_id'] == r['id'])
            .map((a) => a['amenities']['name_ar'])
            .toList(),
      });
    }).toList();
  }

  void _expire() {
    for (final b in local['bookings']!) {
      if (b['status'] == 'hold' &&
          DateTime.parse(b['hold_expires_at']).isBefore(DateTime.now())) {
        b['status'] = 'expired';
      }
    }
  }

  Future<Json> quote(Unit unit, Stay stay, {String coupon = ''}) async {
    stay.validate(capacity: unit.capacity);
    if (!demo) {
      return Map<String, dynamic>.from(
        await client!.rpc(
          'quote_stay',
          params: {...stay.rpc, 'p_unit': unit.id, 'p_coupon': coupon},
        ),
      );
    }
    final nights = List.generate(stay.nights, (i) {
      final d = dateKey(stay.start.add(Duration(days: i)));
      final rate = local['unit_rates']!
          .where((r) => r['unit_id'] == unit.id && r['day'] == d)
          .firstOrNull;
      return {'day': d, 'price': rate?['price'] ?? unit.price};
    });
    final subtotal = nights.fold<int>(0, (v, n) => v + (n['price'] as int));
    final cfg = local['settings']!.first['value'];
    final fee = cfg['service_fee'] as int;
    int discount = 0;
    if (coupon.isNotEmpty) {
      final c = local['coupons']!
          .where(
            (c) => c['code'] == coupon.toUpperCase() && c['is_active'] == true,
          )
          .firstOrNull;
      if (c == null) throw StateError('الكوبون غير متاح');
      discount = (subtotal * (c['percent'] as int) / 100).round().clamp(
        0,
        c['max_discount'] as int,
      );
    }
    final tax =
        ((subtotal + fee - discount) * (cfg['tax_basis_points'] as int) / 10000)
            .round();
    return {
      'subtotal': subtotal,
      'service_fee': fee,
      'discount': discount,
      'tax': tax,
      'total': subtotal + fee - discount + tax,
      'nights': nights,
      'currency': 'SAR',
    };
  }

  Future<Booking> hold(
    Unit unit,
    Stay stay,
    String requestKey, {
    String coupon = '',
  }) async {
    if (!signedIn) throw StateError('سجّل الدخول أولًا');
    if (!demo) {
      return Booking(
        Map<String, dynamic>.from(
          await client!.rpc(
            'create_booking_hold',
            params: {
              ...stay.rpc,
              'p_unit': unit.id,
              'p_request_key': requestKey,
              'p_coupon': coupon,
            },
          ),
        ),
      );
    }
    final existing = local['bookings']!
        .where((b) => b['request_key'] == requestKey)
        .firstOrNull;
    if (existing != null) return Booking(existing);
    if (!(await units(stay)).any((u) => u.id == unit.id)) {
      throw StateError('التواريخ غير متاحة');
    }
    final q = await quote(unit, stay, coupon: coupon);
    final b = {
      'id': const Uuid().v4(),
      'booking_number': 'DEMO-${100001 + local['bookings']!.length}',
      'unit_id': unit.id,
      'unit_name': unit.name,
      'customer_id': 'demo-user',
      'check_in': dateKey(stay.start),
      'check_out': dateKey(stay.end),
      'guests_count': stay.guests,
      'status': 'hold',
      'hold_expires_at': DateTime.now()
          .add(const Duration(minutes: 10))
          .toIso8601String(),
      ...q,
      'price_snapshot': q,
      'request_key': requestKey,
      'created_at': DateTime.now().toIso8601String(),
    };
    local['bookings']!.add(b);
    await save();
    return Booking(b);
  }

  Future<void> guest(Booking b, String name, String phone, String email) async {
    if (name.trim().length < 2 ||
        !RegExp(r'^\+9665[0-9]{8}$').hasMatch(phone)) {
      throw StateError('تحقق من اسم الضيف ورقم الجوال');
    }
    if (demo) {
      await upsert('booking_guests', {
        'id': b.id,
        'booking_id': b.id,
        'full_name': name,
        'phone': phone,
        'email': email,
        'is_primary': true,
      });
    } else {
      await client!.rpc(
        'set_booking_guest',
        params: {
          'p_booking': b.id,
          'p_name': name,
          'p_phone': phone,
          'p_email': email,
        },
      );
    }
  }

  Future<Booking> demoPay(Booking b) async {
    if (!demo) throw StateError('محاكاة الدفع غير متاحة في الوضع الحي');
    _expire();
    final row = local['bookings']!.firstWhere((r) => r['id'] == b.id);
    if (row['status'] == 'confirmed') return Booking(row);
    if (row['status'] != 'hold') {
      throw StateError('انتهت مهلة الدفع؛ أعد اختيار التواريخ');
    }
    row['status'] = 'confirmed';
    await upsert('payments', {
      'booking_id': b.id,
      'amount': b.total,
      'status': 'paid',
      'provider': 'demo',
      'created_at': DateTime.now().toIso8601String(),
    });
    await upsert('notifications', {
      'title': 'تم تأكيد الحجز التجريبي',
      'body': b.number,
      'booking_id': b.id,
      'created_at': DateTime.now().toIso8601String(),
    });
    await save();
    return Booking(row);
  }

  Future<String> checkout(Booking b) async {
    final response = await client!.functions.invoke(
      'create-checkout',
      body: {'booking_id': b.id},
    );
    if (response.status != 200 || response.data['checkout_url'] == null) {
      throw StateError('بوابة الدفع غير مفعلة بعد. لم يتم خصم أي مبلغ.');
    }
    return response.data['checkout_url'];
  }

  Future<List<Booking>> bookings() async {
    if (!signedIn) return [];
    if (demo) _expire();
    return (await table(
      'bookings',
    )).map(Booking.new).toList().reversed.toList();
  }

  Future<void> cancel(Booking b) async {
    if (!demo) {
      await client!.rpc('cancel_booking', params: {'p_booking': b.id});
      return;
    }
    if (b.status == 'hold') {
      local['bookings']!.firstWhere((r) => r['id'] == b.id)['status'] =
          'cancelled';
      await save();
    } else {
      await upsert('support_requests', {
        'customer_id': userId,
        'booking_id': b.id,
        'kind': 'cancellation',
        'message': 'طلب إلغاء',
        'status': 'open',
      });
    }
  }

  Future<Json?> access(Booking b) async => demo
      ? null
      : await client!.rpc('booking_access', params: {'p_booking': b.id});
  Future<Set<String>> favorites() async => signedIn
      ? (await table('favorites')).map((f) => f['unit_id'] as String).toSet()
      : {};
  Future<void> favorite(String unit, bool selected) async {
    if (!signedIn) throw StateError('سجّل الدخول لحفظ المفضلة');
    if (demo) {
      local['favorites']!.removeWhere((f) => f['unit_id'] == unit);
      if (selected) {
        local['favorites']!.add({'customer_id': userId, 'unit_id': unit});
      }
      await save();
    } else if (selected) {
      await client!.from('favorites').insert({
        'customer_id': userId,
        'unit_id': unit,
      });
    } else {
      await client!
          .from('favorites')
          .delete()
          .eq('customer_id', userId!)
          .eq('unit_id', unit);
    }
  }

  Future<void> block(String unit, Stay stay, String reason) async {
    if (!demo) {
      await client!.rpc(
        'block_unit',
        params: {
          'p_unit': unit,
          'p_from': dateKey(stay.start),
          'p_to': dateKey(stay.end),
          'p_reason': reason,
        },
      );
      return;
    }
    if (!(await units(stay)).any((u) => u.id == unit)) {
      throw StateError('الفترة محجوزة أو محجوبة');
    }
    await upsert('inventory_locks', {
      'unit_id': unit,
      'start': dateKey(stay.start),
      'end': dateKey(stay.end),
      'reason': reason,
    });
  }
}
