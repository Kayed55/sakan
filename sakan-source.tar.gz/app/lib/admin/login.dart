import '../ui/system.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/repository.dart';
import '../customer/design.dart';

class AdminLoginPage extends StatefulWidget {
  final SakanRepository repo;
  const AdminLoginPage(this.repo, {super.key});
  @override
  State<AdminLoginPage> createState() => _AdminLoginPageState();
}

class _AdminLoginPageState extends State<AdminLoginPage> {
  final form = GlobalKey<FormState>();
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false, hidden = true;
  String? error;
  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  Future<void> login() async {
    if (busy || !form.currentState!.validate()) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      await widget.repo.signInStaff(email.text.trim(), password.text);
      if (!mounted) return;
      password.clear();
      Navigator.pop(context, true);
    } on AuthException {
      if (mounted) {
        setState(
          () => error =
              'تعذّر تسجيل الدخول. تحقق من البريد وكلمة المرور وحالة حسابك.',
        );
      }
    } catch (_) {
      if (mounted) setState(() => error = 'تعذّر الاتصال. حاول مرة أخرى.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('دخول الموظفين')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 460),
        child: Form(
          key: form,
          child: AutofillGroup(
            child: ListView(
              shrinkWrap: true,
              padding: SakanLayout.padding(context),
              children: [
                const Align(
                  alignment: Alignment.centerRight,
                  child: BrandMark(width: 156),
                ),
                const SizedBox(height: 36),
                Text(
                  'أهلاً بك في مساحة الإدارة',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 10),
                const Text('سجّل الدخول بحساب الموظف المخصّص لك.'),
                const SizedBox(height: 28),
                TextFormField(
                  controller: email,
                  enabled: !busy,
                  keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                  textInputAction: TextInputAction.next,
                  autofillHints: const [AutofillHints.username],
                  autocorrect: false,
                  decoration: const InputDecoration(
                    labelText: 'البريد الإلكتروني',
                  ),
                  validator: (v) =>
                      RegExp(
                        r'^[^\s@]+@[^\s@]+\.[^\s@]+$',
                      ).hasMatch((v ?? '').trim())
                      ? null
                      : 'أدخل بريدًا إلكترونيًا صحيحًا',
                ),
                const SizedBox(height: 18),
                TextFormField(
                  controller: password,
                  enabled: !busy,
                  obscureText: hidden,
                  enableSuggestions: false,
                  autocorrect: false,
                  textDirection: TextDirection.ltr,
                  autofillHints: const [AutofillHints.password],
                  onFieldSubmitted: (_) => login(),
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    suffixIcon: IconButton(
                      tooltip: hidden
                          ? 'إظهار كلمة المرور'
                          : 'إخفاء كلمة المرور',
                      onPressed: () => setState(() => hidden = !hidden),
                      icon: Icon(
                        hidden
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                      ),
                    ),
                  ),
                  validator: (v) =>
                      v == null || v.isEmpty ? 'أدخل كلمة المرور' : null,
                ),
                if (error != null) ...[
                  const SizedBox(height: 18),
                  Semantics(
                    liveRegion: true,
                    child: Text(
                      error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                  ),
                ],
                const SizedBox(height: 24),
                FilledButton(
                  onPressed: busy ? null : login,
                  child: Text(busy ? 'جارٍ تسجيل الدخول…' : 'تسجيل الدخول'),
                ),
                const SizedBox(height: 18),
                const Text(
                  'تحتاج حسابًا أو مساعدة في كلمة المرور؟ تواصل مع مسؤول النظام.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
