import '../ui/records.dart';
import '../ui/system.dart';
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import '../core/map_address.dart';
import 'actions.dart';
import 'images.dart';
import 'property_location.dart';
import 'package:flutter/material.dart';
import '../core/models.dart';
import '../core/repository.dart';
import '../customer/widgets.dart';

class FieldSpec {
  final String key, label;
  final String type;
  final List<String>? options;
  final String? source;
  const FieldSpec(
    this.key,
    this.label, {
    this.type = 'text',
    this.options,
    this.source,
  });
}

const definitions = <String, List<FieldSpec>>{
  'access_instructions': [
    FieldSpec('booking_id', 'الحجز', source: 'bookings'),
    FieldSpec('instructions', 'تعليمات الوصول'),
    FieldSpec('entry_code', 'رمز الدخول'),
    FieldSpec('release_at', 'موعد الإتاحة ISO 8601'),
    FieldSpec('expires_at', 'موعد الانتهاء ISO 8601'),
  ],
  'property_private': [
    FieldSpec('property_id', 'العقار', source: 'properties'),
    FieldSpec('address', 'العنوان الدقيق'),
    FieldSpec('latitude', 'خط العرض', type: 'decimal'),
    FieldSpec('longitude', 'خط الطول', type: 'decimal'),
  ],
  'properties': [
    FieldSpec('name_ar', 'اسم العقار'),
    FieldSpec('name_en', 'الاسم بالإنجليزية'),
    FieldSpec('code', 'الكود الداخلي'),
    FieldSpec('district_id', 'الحي', source: 'districts'),
    FieldSpec('maps_address', 'العنوان الكامل من Google Maps', type: 'address'),
    FieldSpec('approx_lat', 'خط العرض التقريبي (اختياري)', type: 'decimal'),
    FieldSpec('approx_lng', 'خط الطول التقريبي (اختياري)', type: 'decimal'),
    FieldSpec('is_active', 'نشط', type: 'bool'),
  ],
  'units': [
    FieldSpec('name_ar', 'اسم الوحدة'),
    FieldSpec('name_en', 'الاسم بالإنجليزية'),
    FieldSpec('code', 'كود الوحدة'),
    FieldSpec('property_id', 'العقار', source: 'properties'),
    FieldSpec('kind', 'النوع', options: ['studio', 'apartment']),
    FieldSpec('capacity', 'عدد الضيوف', type: 'int'),
    FieldSpec('bedrooms', 'غرف النوم', type: 'int'),
    FieldSpec('beds', 'الأسرّة', type: 'int'),
    FieldSpec('bathrooms', 'دورات المياه', type: 'int'),
    FieldSpec('area', 'المساحة م²', type: 'int'),
    FieldSpec('base_price', 'سعر الليلة بالريال', type: 'money'),
    FieldSpec('description_ar', 'الوصف العربي'),
    FieldSpec('description_en', 'الوصف الإنجليزي'),
    FieldSpec(
      'status',
      'حالة النشر',
      options: ['draft', 'published', 'hidden', 'maintenance'],
    ),
  ],
  'operations_tasks': [
    FieldSpec('unit_id', 'الوحدة', source: 'units'),
    FieldSpec(
      'kind',
      'نوع المهمة',
      options: ['cleaning', 'inspection', 'maintenance'],
    ),
    FieldSpec(
      'status',
      'الحالة',
      options: ['pending', 'assigned', 'in_progress', 'inspection', 'done'],
    ),
    FieldSpec('assigned_to', 'الموظف المسؤول', source: 'profiles'),
    FieldSpec('notes', 'ملاحظات'),
    FieldSpec('checklist', 'قائمة الفحص', type: 'checklist'),
  ],
  'maintenance_requests': [
    FieldSpec('unit_id', 'الوحدة', source: 'units'),
    FieldSpec('description', 'وصف المشكلة'),
    FieldSpec(
      'priority',
      'الأولوية',
      options: ['low', 'medium', 'high', 'urgent'],
    ),
    FieldSpec('status', 'الحالة', options: ['open', 'in_progress', 'resolved']),
    FieldSpec('blocks_sale', 'تمنع بيع الوحدة', type: 'bool'),
  ],
  'coupons': [
    FieldSpec('code', 'رمز الكوبون'),
    FieldSpec('percent', 'نسبة الخصم', type: 'int'),
    FieldSpec('max_discount', 'الحد الأعلى بالريال', type: 'money'),
    FieldSpec('minimum', 'الحد الأدنى بالريال', type: 'money'),
    FieldSpec('max_uses', 'عدد الاستخدامات', type: 'int'),
    FieldSpec('per_customer', 'لكل عميل', type: 'int'),
    FieldSpec('starts_at', 'البداية', type: 'date'),
    FieldSpec('ends_at', 'النهاية', type: 'date'),
    FieldSpec('is_active', 'نشط', type: 'bool'),
  ],
  'home_content': [
    FieldSpec('title_ar', 'العنوان العربي'),
    FieldSpec('title_en', 'العنوان الإنجليزي'),
    FieldSpec(
      'kind',
      'نوع القسم',
      options: ['banner', 'featured', 'new', 'popular'],
    ),
    FieldSpec('image_url', 'رابط الصورة'),
    FieldSpec('sort_order', 'الترتيب', type: 'int'),
    FieldSpec('is_active', 'نشط', type: 'bool'),
  ],
  'user_roles': [
    FieldSpec('user_id', 'المستخدم', source: 'profiles'),
    FieldSpec(
      'role_id',
      'الدور',
      options: [
        'super_admin',
        'operations',
        'customer_service',
        'accountant',
        'staff',
      ],
    ),
  ],
  'cities': [
    FieldSpec('name_ar', 'اسم المدينة'),
    FieldSpec('name_en', 'الاسم الإنجليزي'),
    FieldSpec('region_id', 'المنطقة', source: 'regions'),
    FieldSpec('is_active', 'تفعيل المدينة', type: 'bool'),
  ],
  'regions': [
    FieldSpec('name_ar', 'اسم المنطقة'),
    FieldSpec('name_en', 'الاسم الإنجليزي'),
    FieldSpec('code', 'الكود'),
  ],
  'districts': [
    FieldSpec('name_ar', 'اسم الحي'),
    FieldSpec('name_en', 'الاسم الإنجليزي'),
    FieldSpec('city_id', 'المدينة', source: 'cities'),
  ],
  'unit_images': [
    FieldSpec('unit_id', 'الوحدة', source: 'units'),
    FieldSpec('image_url', 'رابط الصورة المنشورة'),
    FieldSpec('sort_order', 'الترتيب', type: 'int'),
    FieldSpec('is_cover', 'صورة الغلاف', type: 'bool'),
  ],
};
const labels = {
  'booking_number': 'رقم الحجز',
  'full_name': 'الاسم',
  'name_ar': 'الاسم',
  'code': 'الكود',
  'status': 'الحالة',
  'check_in': 'الدخول',
  'check_out': 'الخروج',
  'total': 'الإجمالي',
  'amount': 'المبلغ',
  'title': 'العنوان',
  'body': 'المحتوى',
  'title_ar': 'العنوان',
  'kind': 'النوع',
  'role_id': 'الدور',
  'user_id': 'المستخدم',
  'table_name': 'الجدول',
  'action': 'العملية',
  'created_at': 'التاريخ',
  'priority': 'الأولوية',
  'description': 'الوصف',
  'message': 'الرسالة',
  'notes': 'الملاحظات',
  'base_price': 'سعر الليلة',
  'email': 'البريد',
  'percent': 'الخصم %',
  'is_active': 'نشط',
};
const columns = <String, List<String>>{
  'access_instructions': ['instructions', 'release_at', 'expires_at'],
  'property_private': ['address'],
  'bookings': ['booking_number', 'check_in', 'check_out', 'status', 'total'],
  'properties': ['name_ar', 'code', 'is_active'],
  'units': ['name_ar', 'code', 'base_price', 'status'],
  'reviews': ['rating', 'comment', 'published'],
  'profiles': ['full_name', 'email', 'created_at'],
  'payments': ['amount', 'status', 'created_at'],
  'refunds': ['amount', 'status', 'reason'],
  'operations_tasks': ['kind', 'status', 'notes'],
  'maintenance_requests': ['description', 'priority', 'status'],
  'coupons': ['code', 'percent', 'is_active'],
  'home_content': ['title_ar', 'kind', 'is_active'],
  'notifications': ['title', 'body', 'created_at'],
  'user_roles': ['user_id', 'role_id'],
  'audit_logs': ['table_name', 'action', 'created_at'],
  'support_requests': ['kind', 'message', 'status'],
};

class RecordsPanel extends StatefulWidget {
  final SakanRepository repo;
  final String table, title;
  const RecordsPanel(
    this.repo, {
    required this.table,
    required this.title,
    super.key,
  });
  @override
  State<RecordsPanel> createState() => _RecordsPanelState();
}

class _RecordsPanelState extends State<RecordsPanel> {
  late Future<List<Json>> future;
  String search = '';
  String statusFilter = '';
  String? sortKey;
  bool ascending = true;
  int page = 0;
  static const pageSize = 12;
  @override
  void initState() {
    super.initState();
    reload();
  }

  void reload() {
    future = widget.repo.table(widget.table);
  }

  Future<void> edit([Json? row]) async {
    await showDialog(
      context: context,
      builder: (c) => RecordEditor(widget.repo, table: widget.table, row: row),
    );
    if (mounted) setState(reload);
  }

  @override
  Widget build(BuildContext context) => Padding(
    padding: SakanLayout.padding(context),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, box) => Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              SizedBox(
                width: box.maxWidth < 600 ? box.maxWidth : 320,
                child: TextField(
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search),
                    labelText: 'بحث في السجلات',
                    hintText: 'الاسم، الرقم أو أي بيانات ظاهرة',
                  ),
                  onChanged: (v) => setState(() {
                    search = v;
                    page = 0;
                  }),
                ),
              ),
              if (widget.table == 'notifications')
                FilledButton.icon(
                  onPressed: () async {
                    await showDialog(
                      context: context,
                      builder: (_) => NotificationComposer(widget.repo),
                    );
                    if (mounted) setState(reload);
                  },
                  icon: const Icon(Icons.send_outlined),
                  label: const Text('إشعار جديد'),
                ),
              if (definitions.containsKey(widget.table))
                FilledButton.icon(
                  onPressed: () => edit(),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة جديد'),
                ),
              if (widget.table == 'properties')
                OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => Scaffold(
                        appBar: AppBar(title: const Text('العناوين الدقيقة')),
                        body: ContentFrame(
                          child: RecordsPanel(
                            widget.repo,
                            table: 'property_private',
                            title: 'العناوين الدقيقة',
                          ),
                        ),
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.location_on_outlined),
                  label: const Text('العناوين الدقيقة'),
                ),
              if (widget.table == 'units')
                OutlinedButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => ImagesPanel(widget.repo)),
                  ),
                  icon: const Icon(Icons.photo_library_outlined),
                  label: const Text('إدارة الصور'),
                ),
            ],
          ),
        ),
        const Space(16),
        Expanded(
          child: FutureBuilder<List<Json>>(
            future: future,
            builder: (context, s) {
              if (s.hasError) {
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      const EmptyState(
                        'تعذر عرض السجلات',
                        'تحقق من اتصالك ثم أعد المحاولة.',
                      ),
                      TextButton.icon(
                        onPressed: () => setState(reload),
                        icon: const Icon(Icons.refresh),
                        label: const Text('إعادة المحاولة'),
                      ),
                    ],
                  ),
                );
              }
              if (!s.hasData) {
                return const Center(
                  child: CircularProgressIndicator(
                    semanticsLabel: 'تحميل السجلات',
                  ),
                );
              }
              final cols = columns[widget.table] ?? ['name_ar'];
              final statuses =
                  s.data!
                      .map((r) => r['status']?.toString())
                      .whereType<String>()
                      .toSet()
                      .toList()
                    ..sort();
              if (statusFilter.isNotEmpty && !statuses.contains(statusFilter)) {
                statuses.add(statusFilter);
              }
              final rows = s.data!
                  .where(
                    (r) =>
                        (statusFilter.isEmpty || r['status'] == statusFilter) &&
                        r.values
                            .join(' ')
                            .toLowerCase()
                            .contains(search.toLowerCase()),
                  )
                  .toList();
              if (sortKey != null) {
                rows.sort((a, b) {
                  final x = a[sortKey], y = b[sortKey];
                  final result = x is num && y is num
                      ? x.compareTo(y)
                      : '$x'.compareTo('$y');
                  return ascending ? result : -result;
                });
              }
              final pages = (rows.length / pageSize).ceil().clamp(1, 99999);
              final current = page.clamp(0, pages - 1);
              void sortBy(String key) => setState(() {
                ascending = sortKey == key ? !ascending : true;
                sortKey = key;
                page = 0;
              });
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      if (statuses.isNotEmpty)
                        SizedBox(
                          width: 220,
                          child: DropdownButtonFormField<String>(
                            isExpanded: true,
                            initialValue: statusFilter,
                            decoration: const InputDecoration(
                              labelText: 'الحالة',
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('كل الحالات'),
                              ),
                              for (final status in statuses)
                                DropdownMenuItem(
                                  value: status,
                                  child: Text(
                                    statusLabel(status),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                            ],
                            onChanged: (v) => setState(() {
                              statusFilter = v ?? '';
                              page = 0;
                            }),
                          ),
                        ),
                      SizedBox(
                        width: 220,
                        child: DropdownButtonFormField<String>(
                          isExpanded: true,
                          initialValue: sortKey,
                          decoration: const InputDecoration(
                            labelText: 'ترتيب حسب',
                          ),
                          items: [
                            for (final k in cols)
                              DropdownMenuItem(
                                value: k,
                                child: Text(
                                  labels[k] ?? k,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                          ],
                          onChanged: (v) {
                            if (v != null) sortBy(v);
                          },
                        ),
                      ),
                      IconButton(
                        tooltip: ascending ? 'ترتيب تنازلي' : 'ترتيب تصاعدي',
                        onPressed: () => setState(() {
                          sortKey ??= cols.first;
                          ascending = !ascending;
                        }),
                        icon: Icon(
                          ascending ? Icons.arrow_upward : Icons.arrow_downward,
                        ),
                      ),
                      Text(
                        '${rows.length} سجل',
                        style: const TextStyle(color: Color(0xff5d685f)),
                      ),
                    ],
                  ),
                  const Space(12),
                  Expanded(
                    child: rows.isEmpty
                        ? SingleChildScrollView(
                            child: EmptyState(
                              search.isNotEmpty || statusFilter.isNotEmpty
                                  ? 'لا توجد نتائج مطابقة'
                                  : 'لا توجد سجلات بعد',
                              search.isNotEmpty || statusFilter.isNotEmpty
                                  ? 'غيّر البحث أو الحالة لعرض نتائج أخرى.'
                                  : definitions.containsKey(widget.table)
                                  ? 'أضف أول سجل من الزر أعلاه.'
                                  : 'ستظهر السجلات عند تنفيذ العمليات المرتبطة بها.',
                            ),
                          )
                        : ResponsiveRecords(
                            rows: rows
                                .skip(current * pageSize)
                                .take(pageSize)
                                .toList(),
                            columns: cols,
                            label: (k) => labels[k] ?? k,
                            cell: (k, r) => k == 'status'
                                ? StatusPill(statusLabel('${r[k]}'))
                                : Text(format(k, r[k]), softWrap: true),
                            open: (r) => definitions.containsKey(widget.table)
                                ? edit(r)
                                : details(r),
                            sort: sortBy,
                            sorted: sortKey,
                            ascending: ascending,
                          ),
                  ),
                  Wrap(
                    alignment: WrapAlignment.center,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 8,
                    children: [
                      IconButton(
                        tooltip: 'الصفحة السابقة',
                        onPressed: current > 0
                            ? () => setState(() => page = current - 1)
                            : null,
                        icon: const Icon(Icons.chevron_right),
                      ),
                      Text('صفحة ${current + 1} من $pages'),
                      IconButton(
                        tooltip: 'الصفحة التالية',
                        onPressed: current + 1 < pages
                            ? () => setState(() => page = current + 1)
                            : null,
                        icon: const Icon(Icons.chevron_left),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ),
      ],
    ),
  );

  String format(String k, dynamic value) {
    if (value == null) return '—';
    if (['total', 'amount', 'base_price'].contains(k)) return money(value);
    if (value is bool) return value ? 'نعم' : 'لا';
    final s = '$value';
    return s;
  }

  Future<void> details(Json row) async {
    await showDialog(
      context: context,
      builder: (c) => AlertDialog(
        scrollable: true,
        title: Text(row['booking_number'] ?? widget.title),
        content: SizedBox(
          width: 600,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                for (final k in (columns[widget.table] ?? row.keys))
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('${labels[k] ?? k}: ${format(k, row[k])}'),
                  ),
                if (widget.table == 'bookings') ...[
                  const Divider(),
                  Text('معرف الوحدة: ${row['unit_id']}'),
                  Text('الضيوف: ${row['guests_count']}'),
                  Text(
                    'الإقامة: ${money(row['subtotal'])} • الرسوم: ${money(row['service_fee'])}\nالخصم: ${money(row['discount'])} • الضريبة: ${money(row['tax'])}',
                  ),
                  if (['confirmed', 'checked_in'].contains(row['status']))
                    PermissionView(
                      check: () => widget.repo.allowed('operations.write'),
                      child: AsyncAction(
                        label: row['status'] == 'confirmed'
                            ? 'تسجيل الدخول'
                            : 'تسجيل الخروج وإنشاء مهمة تنظيف',
                        action: () async {
                          final target = row['status'] == 'confirmed'
                              ? 'checked_in'
                              : 'completed';
                          if (widget.repo.demo) {
                            await widget.repo.upsert('bookings', {
                              'id': row['id'],
                              'status': target,
                            });
                            if (target == 'completed') {
                              await widget.repo.upsert('operations_tasks', {
                                'unit_id': row['unit_id'],
                                'booking_id': row['id'],
                                'kind': 'cleaning',
                                'status': 'pending',
                                'notes': 'تنظيف بعد المغادرة',
                              });
                            }
                          } else {
                            await widget.repo.client!.rpc(
                              'transition_booking',
                              params: {
                                'p_booking': row['id'],
                                'p_status': target,
                              },
                            );
                          }
                          if (c.mounted) Navigator.pop(c);
                        },
                      ),
                    ),
                ],
                if (widget.table == 'payments' &&
                    [
                      'paid',
                      'partially_refunded',
                      'refund_required',
                    ].contains(row['status']))
                  PermissionView(
                    check: () => widget.repo.allowed('finance.refund'),
                    child: AsyncAction(
                      label: 'اعتماد استرداد',
                      action: () async {
                        if (!await widget.repo.allowed('finance.refund')) {
                          throw StateError('ليست لديك صلاحية الاسترداد');
                        }
                        if (c.mounted) {
                          await showDialog(
                            context: c,
                            builder: (_) => RefundComposer(widget.repo, row),
                          );
                        }
                      },
                    ),
                  ),
                if (widget.table == 'refunds')
                  const Text(
                    'الاسترداد الفعلي يحتاج مزود دفع مفعّلًا. لا يُعد الطلب تنفيذًا ماليًا.',
                  ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
    if (mounted) setState(reload);
  }
}

class RecordEditor extends StatefulWidget {
  final SakanRepository repo;
  final String table;
  final Json? row;
  const RecordEditor(this.repo, {required this.table, this.row, super.key});
  @override
  State<RecordEditor> createState() => _RecordEditorState();
}

class _RecordEditorState extends State<RecordEditor> {
  final controllers = <String, TextEditingController>{};
  late Json values;
  final sources = <String, List<Json>>{};
  final form = GlobalKey<FormState>();
  bool loading = true;
  String? loadError;
  @override
  void initState() {
    super.initState();
    values = {...?widget.row};
    for (final f in definitions[widget.table]!) {
      final value = values[f.key];
      controllers[f.key] = TextEditingController(
        text: value == null
            ? ''
            : f.type == 'money'
            ? '${(value as num) / 100}'
            : '$value',
      );
      if (f.type == 'bool') values[f.key] ??= true;
      if (f.type == 'checklist') values[f.key] ??= {};
    }
    load();
  }

  Future<void> load() async {
    if (mounted) {
      setState(() {
        loading = true;
        loadError = null;
      });
    }
    try {
      for (final f in definitions[widget.table]!) {
        if (f.source != null) {
          sources[f.key] = await widget.repo.table(f.source!);
        }
      }
      if (widget.table == 'properties' && widget.row?['id'] != null) {
        final location = await widget.repo.propertyLocation(widget.row!['id']);
        if (!mounted) return;
        controllers['maps_address']!.text = location?['address'] ?? '';
      }
    } catch (_) {
      if (mounted) {
        loadError = "تعذر تحميل بيانات النموذج. أعد المحاولة قبل التعديل.";
      }
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  void dispose() {
    for (final c in controllers.values) {
      c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    scrollable: true,
    title: Text(widget.row == null ? 'إضافة سجل جديد' : 'تعديل بيانات السجل'),
    content: SizedBox(
      width: 600,
      child: loading
          ? const SizedBox(
              height: 100,
              child: Center(child: CircularProgressIndicator()),
            )
          : loadError != null
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(loadError!),
                TextButton(
                  onPressed: load,
                  child: const Text("إعادة المحاولة"),
                ),
              ],
            )
          : Form(
              key: form,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    const FormSection(
                      'بيانات السجل',
                      note:
                          'الحقول المعلّمة بـ * مطلوبة. راجع البيانات ثم اضغط حفظ.',
                    ),
                    for (final f in definitions[widget.table]!) ...[
                      if ([
                        'description_ar',
                        'base_price',
                        'maps_address',
                        'checklist',
                        'instructions',
                      ].contains(f.key))
                        FormSection(
                          f.key == 'base_price'
                              ? 'الأسعار والحالة'
                              : f.key == 'maps_address'
                              ? 'العنوان والموقع'
                              : f.key == 'checklist'
                              ? 'قائمة الفحص'
                              : f.key == 'instructions'
                              ? 'تعليمات الإقامة'
                              : 'وصف الوحدة',
                        ),
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: field(f),
                      ),
                      if (widget.table == 'units' && f.key == 'property_id')
                        if (values['property_id'] != null)
                          PropertyLocation(
                            widget.repo,
                            key: ValueKey(values['property_id']),
                            propertyId: values['property_id'] as String,
                          )
                        else
                          const Padding(
                            padding: EdgeInsets.only(bottom: 16),
                            child: Text(
                              'اختر العقار لإضافة عنوان الوحدة وتحديده في Google Maps.',
                            ),
                          ),
                    ],
                  ],
                ),
              ),
            ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      if (!loading && loadError == null)
        AsyncAction(label: 'حفظ', action: save),
    ],
  );
  Widget field(FieldSpec f) {
    if (f.type == 'address') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: controllers[f.key],
            minLines: 2,
            maxLines: 3,
            decoration: InputDecoration(
              labelText:
                  [
                    'assigned_to',
                    'image_url',
                    'notes',
                    'approx_lat',
                    'approx_lng',
                  ].contains(f.key)
                  ? f.label
                  : '${f.label} *',
              hintText: 'رقم المبنى، الشارع، الحي، المدينة، الرمز البريدي',
            ),
            validator: (v) {
              try {
                googleMapsAddress(v ?? '');
                return null;
              } on FormatException catch (e) {
                return e.message;
              }
            },
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            icon: const Icon(Icons.map_outlined),
            label: const Text('فتح العنوان في Google Maps'),
            onPressed: () async {
              try {
                final uri = googleMapsAddress(controllers[f.key]!.text);
                if (!await launchUrl(
                  uri,
                  mode: LaunchMode.externalApplication,
                  webOnlyWindowName: '_blank',
                )) {
                  throw StateError('تعذر فتح الخريطة');
                }
              } catch (e) {
                if (mounted) showError(context, e);
              }
            },
          ),
          const Text(
            'يُحفظ العنوان مع العقار. الإحداثيات أدناه اختيارية لإظهاره على خريطة البحث داخل سكن.',
          ),
        ],
      );
    }
    if (f.type == 'bool') {
      return SwitchListTile(
        title: Text(f.label),
        value: values[f.key] ?? false,
        onChanged: (v) => setState(() => values[f.key] = v),
      );
    }
    if (f.type == 'checklist') {
      return Column(
        children: [
          for (final task in [
            'المفارش',
            'الحمام',
            'المطبخ',
            'الأرضيات',
            'المناشف',
            'المستلزمات',
            'التلفزيون',
            'الإنترنت',
            'المكيف',
          ])
            CheckboxListTile(
              title: Text(task),
              value: values[f.key][task] ?? false,
              onChanged: (v) => setState(() => values[f.key][task] = v),
            ),
        ],
      );
    }
    if (f.source != null || f.options != null) {
      final options =
          f.options?.map((s) => (s, statusLabel(s))).toList() ??
          (sources[f.key] ?? [])
              .map(
                (r) => (
                  r['id'] as String,
                  (r['name_ar'] ??
                          r['full_name'] ??
                          r['booking_number'] ??
                          r['id'])
                      as String,
                ),
              )
              .toList();
      return DropdownButtonFormField<String>(
        isExpanded: true,
        initialValue: options.any((o) => o.$1 == values[f.key])
            ? values[f.key]
            : null,
        decoration: InputDecoration(
          labelText:
              [
                'assigned_to',
                'image_url',
                'notes',
                'approx_lat',
                'approx_lng',
              ].contains(f.key)
              ? f.label
              : '${f.label} *',
        ),
        items: options
            .map(
              (o) => DropdownMenuItem(
                value: o.$1,
                child: Text(o.$2, overflow: TextOverflow.ellipsis),
              ),
            )
            .toList(),
        onChanged: (v) => setState(() => values[f.key] = v),
        validator: (v) =>
            v == null && f.key != 'assigned_to' ? 'اختر ${f.label}' : null,
      );
    }
    if (f.type == 'date') {
      return TextFormField(
        controller: controllers[f.key],
        readOnly: true,
        decoration: InputDecoration(
          labelText:
              [
                'assigned_to',
                'image_url',
                'notes',
                'approx_lat',
                'approx_lng',
              ].contains(f.key)
              ? f.label
              : '${f.label} *',
          suffixIcon: const Icon(Icons.calendar_month),
        ),
        onTap: () async {
          final day = await showDatePicker(
            context: context,
            firstDate: DateTime(2025),
            lastDate: DateTime(2035),
            initialDate: DateTime.now(),
          );
          if (day != null) {
            controllers[f.key]!.text = day.toUtc().toIso8601String();
          }
        },
        validator: (v) => v == null || v.isEmpty ? 'مطلوب' : null,
      );
    }
    return TextFormField(
      controller: controllers[f.key],
      decoration: InputDecoration(
        labelText:
            [
              'assigned_to',
              'image_url',
              'notes',
              'approx_lat',
              'approx_lng',
            ].contains(f.key)
            ? f.label
            : '${f.label} *',
      ),
      maxLines: f.key.contains('description') ? 3 : 1,
      keyboardType: ['int', 'money', 'decimal'].contains(f.type)
          ? const TextInputType.numberWithOptions(decimal: true)
          : TextInputType.text,
      validator: (v) {
        if (['approx_lat', 'approx_lng'].contains(f.key)) {
          final a = controllers['approx_lat']!.text.trim();
          final b = controllers['approx_lng']!.text.trim();
          if (a.isEmpty && b.isEmpty) return null;
          final n = double.tryParse((v ?? '').trim());
          final max = f.key == 'approx_lat' ? 90 : 180;
          if (n == null || !n.isFinite || n.abs() > max) {
            return 'أدخل الإحداثيين معًا بقيم صحيحة أو اتركهما فارغين';
          }
          return null;
        }
        if ((v ?? '').isEmpty && !['image_url', 'notes'].contains(f.key)) {
          return 'مطلوب';
        }
        if (['int', 'money', 'decimal'].contains(f.type) &&
            num.tryParse(v ?? '') == null) {
          return 'أدخل رقمًا صحيحًا';
        }
        return null;
      },
    );
  }

  Future<void> save() async {
    if (!form.currentState!.validate()) return;
    final row = <String, dynamic>{
      if (widget.row?['id'] != null) 'id': widget.row!['id'],
    };
    for (final f in definitions[widget.table]!) {
      if (f.type == 'address') continue;
      final text = controllers[f.key]!.text.trim();
      row[f.key] =
          f.source != null ||
              f.options != null ||
              ['bool', 'checklist'].contains(f.type)
          ? values[f.key]
          : f.type == 'int'
          ? int.parse(text)
          : f.type == 'money'
          ? (double.parse(text) * 100).round()
          : f.type == 'decimal'
          ? (text.isEmpty ? null : double.parse(text))
          : text;
    }
    if (widget.table == 'coupons') {
      row['code'] = (row['code'] as String).toUpperCase();
    }
    if (widget.table == 'properties') {
      await widget.repo.savePropertyWithAddress(
        row,
        controllers['maps_address']!.text.trim(),
      );
    } else {
      await widget.repo.upsert(widget.table, row);
    }
    if (mounted) Navigator.pop(context);
  }
}

class SettingsPanel extends StatelessWidget {
  final SakanRepository repo;
  const SettingsPanel(this.repo, {super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: SakanLayout.padding(context),
    children: [
      const SectionTitle('إعدادات الحجز'),
      FutureBuilder<List<Json>>(
        future: repo.table('settings'),
        builder: (c, s) {
          if (!s.hasData) return const CircularProgressIndicator();
          return Column(
            children: s.data!
                .map(
                  (row) => Card(
                    child: ListTile(
                      title: Text(row['key']),
                      subtitle: Text(jsonEncode(row['value'])),
                      trailing: IconButton(
                        tooltip: 'تعديل إعدادات الحجز',
                        icon: const Icon(Icons.edit),
                        onPressed: () => showDialog(
                          context: context,
                          builder: (c) => BookingSettings(repo, row),
                        ),
                      ),
                    ),
                  ),
                )
                .toList(),
          );
        },
      ),
      const SectionTitle('التوسع الجغرافي'),
      for (final entry in [
        ('regions', 'المناطق'),
        ('cities', 'المدن'),
        ('districts', 'الأحياء'),
      ])
        Card(
          child: ListTile(
            title: Text(entry.$2),
            trailing: const Icon(Icons.chevron_left),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => Scaffold(
                  appBar: AppBar(title: Text(entry.$2)),
                  body: RecordsPanel(repo, table: entry.$1, title: entry.$2),
                ),
              ),
            ),
          ),
        ),
      const SectionTitle('التكاملات'),
      const Text(
        'OTP: إعداد مزود SMS في Supabase Auth.\nالدفع: يحتاج اختيار المزود وربط أسراره على الخادم.\nالإشعارات: صندوق إرسال جاهز، ومزود Push غير مفعّل.\nالرسوم والضريبة الافتراضية صفر للتجربة وليست إعدادًا ماليًا معتمدًا.',
      ),
    ],
  );
}

class BookingSettings extends StatefulWidget {
  final SakanRepository repo;
  final Json row;
  const BookingSettings(this.repo, this.row, {super.key});
  @override
  State<BookingSettings> createState() => _BookingSettingsState();
}

class _BookingSettingsState extends State<BookingSettings> {
  late final minutes = TextEditingController(
    text: '${widget.row['value']['hold_minutes']}',
  );
  late final fee = TextEditingController(
    text: '${widget.row['value']['service_fee'] / 100}',
  );
  late final tax = TextEditingController(
    text: '${widget.row['value']['tax_basis_points'] / 100}',
  );
  @override
  void dispose() {
    minutes.dispose();
    fee.dispose();
    tax.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    scrollable: true,
    title: const Text('إعدادات الحجز'),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        TextField(
          controller: minutes,
          decoration: const InputDecoration(
            labelText: 'مهلة الدفع بالدقائق (1–30)',
          ),
        ),
        const Space(),
        TextField(
          controller: fee,
          decoration: const InputDecoration(labelText: 'رسوم الخدمة بالريال'),
        ),
        const Space(),
        TextField(
          controller: tax,
          decoration: const InputDecoration(labelText: 'نسبة الضريبة %'),
        ),
      ],
    ),
    actions: [
      AsyncAction(
        label: 'حفظ',
        action: () async {
          final m = int.tryParse(minutes.text),
              f = double.tryParse(fee.text),
              t = double.tryParse(tax.text);
          if (m == null ||
              m < 1 ||
              m > 30 ||
              f == null ||
              f < 0 ||
              t == null ||
              t < 0 ||
              t > 100) {
            throw StateError('تحقق من القيم');
          }
          await widget.repo.upsert('settings', {
            'key': 'booking',
            'value': {
              ...widget.row['value'],
              'hold_minutes': m,
              'service_fee': (f * 100).round(),
              'tax_basis_points': (t * 100).round(),
            },
          });
          if (context.mounted) Navigator.pop(context);
        },
      ),
    ],
  );
}
