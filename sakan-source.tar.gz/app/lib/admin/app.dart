import '../ui/system.dart';
import '../chat/chat.dart';
import 'package:flutter/material.dart';
import '../core/bootstrap.dart';
import '../core/models.dart';
import '../core/repository.dart';
import 'login.dart';
import '../customer/widgets.dart';
import '../customer/design.dart';
import 'editor.dart';
import 'actions.dart';
import 'calendar.dart';

class AdminApp extends StatelessWidget {
  final SakanRepository repo;
  const AdminApp({required this.repo, super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'سكن | لوحة الإدارة',
    theme: sakanTheme(),
    builder: sakanViewport,
    locale: const Locale('ar'),
    supportedLocales: locales,
    localizationsDelegates: delegates,
    home: AdminShell(repo),
  );
}

const pages = [
  ('dashboard', 'نظرة عامة', Icons.space_dashboard_outlined, 'reports.read'),
  ('bookings', 'الحجوزات', Icons.event_note, 'booking.read'),
  ('booking_chats', 'المحادثات', Icons.chat_bubble_outline, 'customer.read'),
  ('properties', 'العقارات', Icons.apartment, 'catalog.write'),
  ('units', 'الوحدات', Icons.door_front_door_outlined, 'catalog.write'),
  ('calendar', 'التقويم والأسعار', Icons.calendar_month, 'catalog.write'),
  (
    'operations_tasks',
    'التشغيل والتنظيف',
    Icons.cleaning_services_outlined,
    'operations.write',
  ),
  (
    'access_instructions',
    'تعليمات الدخول',
    Icons.key_outlined,
    'operations.write',
  ),
  ('maintenance_requests', 'الصيانة', Icons.build_outlined, 'operations.write'),
  ('profiles', 'العملاء', Icons.people_outline, 'customer.read'),
  ('payments', 'المدفوعات', Icons.payments_outlined, 'finance.read'),
  ('refunds', 'الاستردادات', Icons.undo, 'finance.read'),
  ('coupons', 'الكوبونات', Icons.local_offer_outlined, 'content.write'),
  ('home_content', 'محتوى الرئيسية', Icons.web, 'content.write'),
  ('reviews', 'التقييمات', Icons.star_outline, 'content.write'),
  ('notifications', 'الإشعارات', Icons.notifications_none, 'content.write'),
  ('reports', 'التقارير', Icons.bar_chart, 'reports.read'),
  (
    'user_roles',
    'المستخدمون والصلاحيات',
    Icons.admin_panel_settings_outlined,
    'roles.write',
  ),
  ('settings', 'الإعدادات والمدن', Icons.settings_outlined, 'settings.write'),
  ('alerts', 'تنبيهات التشغيل', Icons.warning_amber, 'operations.write'),
  ('support_requests', 'طلبات العملاء', Icons.support_agent, 'customer.read'),
  ('assigned_tasks', 'مهامي', Icons.checklist, 'tasks.assigned'),
  ('audit_logs', 'سجل العمليات', Icons.history, 'audit.read'),
];

class AdminShell extends StatefulWidget {
  final SakanRepository repo;
  const AdminShell(this.repo, {super.key});
  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int page = 0;
  Set<String> permissions = {};
  bool loading = true;
  int refresh = 0;
  bool collapsed = false;
  String? permissionError;
  @override
  void initState() {
    super.initState();
    loadPermissions();
  }

  Future<void> loadPermissions() async {
    try {
      final result = <String>{};
      if (widget.repo.demo || widget.repo.signedIn) {
        for (final permission in {
          ...pages.map((p) => p.$4),
          'finance.refund',
          'operations.write',
        }) {
          if (await widget.repo.allowed(permission)) result.add(permission);
        }
      }
      if (mounted) {
        setState(() {
          permissions = result;
          loading = false;
          permissionError = null;
          final first = pages.indexWhere((p) => permissions.contains(p.$4));
          if (first >= 0 && !permissions.contains(pages[page].$4)) page = first;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          permissionError = 'تعذر التحقق من صلاحياتك. أعد المحاولة.';
        });
      }
    }
  }

  String section(String key) {
    if ([
      'dashboard',
      'bookings',
      'booking_chats',
      'support_requests',
    ].contains(key)) {
      return 'الإقامات وخدمة العملاء';
    }
    if ([
      'properties',
      'units',
      'calendar',
      'operations_tasks',
      'access_instructions',
      'maintenance_requests',
      'assigned_tasks',
    ].contains(key)) {
      return 'العقارات والتشغيل';
    }
    if (['payments', 'refunds', 'coupons', 'reports'].contains(key)) {
      return 'المالية والتقارير';
    }
    if ([
      'profiles',
      'home_content',
      'reviews',
      'notifications',
    ].contains(key)) {
      return 'العملاء والمحتوى';
    }
    return 'إدارة النظام';
  }

  void selectPage(int index) {
    if (permissions.contains(pages[index].$4)) setState(() => page = index);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!widget.repo.demo && !widget.repo.signedIn) {
      return AdminWelcome(
        onLogin: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => AdminLoginPage(widget.repo)),
          );
          await loadPermissions();
        },
      );
    }
    if (permissionError != null) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              EmptyState('تعذر فتح مساحة العمل', permissionError!),
              TextButton(
                onPressed: loadPermissions,
                child: const Text('إعادة المحاولة'),
              ),
            ],
          ),
        ),
      );
    }
    if (permissions.isEmpty) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const EmptyState(
                'لا توجد صلاحيات إدارية',
                'يحتاج حسابك إلى دور يمنحه مدير النظام.',
              ),
              TextButton(
                onPressed: () async {
                  await widget.repo.signOut();
                  await loadPermissions();
                },
                child: const Text('تسجيل الخروج'),
              ),
            ],
          ),
        ),
      );
    }
    final wide = MediaQuery.sizeOf(context).width >= SakanLayout.desktop;
    Widget entry(int i, BuildContext menuContext) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      child: Tooltip(
        message: pages[i].$2,
        child: ListTile(
          minTileHeight: 48,
          contentPadding: EdgeInsets.symmetric(
            horizontal: wide && collapsed ? 12 : 16,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          selected: i == page,
          selectedTileColor: Colors.white.withValues(alpha: .16),
          selectedColor: Colors.white,
          textColor: Colors.white70,
          iconColor: Colors.white70,
          leading: Icon(pages[i].$3, size: 22),
          title: wide && collapsed
              ? null
              : Text(pages[i].$2, style: const TextStyle(fontSize: 13)),
          onTap: () {
            selectPage(i);
            if (!wide) Navigator.pop(menuContext);
          },
        ),
      ),
    );
    Widget menu(BuildContext menuContext) => SizedBox(
      width: wide && collapsed ? 80 : 272,
      child: Material(
        color: brand,
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(wide && collapsed ? 12 : 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  BrandMark(light: true, width: wide && collapsed ? 52 : 148),
                  if (!wide || !collapsed) ...[
                    const Space(12),
                    const Text(
                      'مساحة الإدارة والتشغيل',
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                  ],
                ],
              ),
            ),
            const Divider(color: Colors.white24, height: 1),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: [
                  if (wide && collapsed) ...[
                    for (int i = 0; i < pages.length; i++)
                      if (permissions.contains(pages[i].$4))
                        entry(i, menuContext),
                  ] else ...[
                    for (final group in [
                      'الإقامات وخدمة العملاء',
                      'العقارات والتشغيل',
                      'المالية والتقارير',
                      'العملاء والمحتوى',
                      'إدارة النظام',
                    ])
                      if (pages.any(
                        (p) =>
                            section(p.$1) == group &&
                            permissions.contains(p.$4),
                      ))
                        Theme(
                          data: Theme.of(
                            context,
                          ).copyWith(dividerColor: Colors.transparent),
                          child: ExpansionTile(
                            key: PageStorageKey(group),
                            initiallyExpanded: true,
                            collapsedIconColor: Colors.white70,
                            iconColor: Colors.white,
                            title: Text(
                              group,
                              style: const TextStyle(
                                color: Color(0xffe0d1b9),
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            children: [
                              for (int i = 0; i < pages.length; i++)
                                if (section(pages[i].$1) == group &&
                                    permissions.contains(pages[i].$4))
                                  entry(i, menuContext),
                            ],
                          ),
                        ),
                  ],
                ],
              ),
            ),
            if (wide)
              Padding(
                padding: const EdgeInsets.all(12),
                child: IconButton(
                  tooltip: collapsed ? 'توسيع القائمة' : 'تصغير القائمة',
                  onPressed: () => setState(() => collapsed = !collapsed),
                  icon: Icon(
                    collapsed ? Icons.menu_open : Icons.unfold_less,
                    color: Colors.white,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
    return Scaffold(
      drawer: wide ? null : Drawer(width: 272, child: Builder(builder: menu)),
      body: Row(
        children: [
          if (wide) Builder(builder: menu),
          Expanded(
            child: Column(
              children: [
                Material(
                  color: Colors.white,
                  child: Padding(
                    padding: EdgeInsets.symmetric(
                      horizontal: wide ? 24 : 8,
                      vertical: 12,
                    ),
                    child: Row(
                      children: [
                        if (!wide)
                          Builder(
                            builder: (c) => IconButton(
                              tooltip: 'فتح قائمة الإدارة',
                              onPressed: () => Scaffold.of(c).openDrawer(),
                              icon: const Icon(Icons.menu),
                            ),
                          ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'سكن / ${section(pages[page].$1)}',
                                style: const TextStyle(
                                  fontSize: 11,
                                  color: Color(0xff5d685f),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                pages[page].$2,
                                style: TextStyle(
                                  fontSize: wide ? 24 : 18,
                                  fontWeight: FontWeight.w700,
                                  color: brand,
                                ),
                              ),
                            ],
                          ),
                        ),
                        if (widget.repo.demo && wide) const Tag('بيئة تجريبية'),
                        IconButton(
                          tooltip: 'تحديث الصفحة',
                          onPressed: () => setState(() => refresh++),
                          icon: const Icon(Icons.refresh),
                        ),
                        IconButton(
                          tooltip: 'تسجيل الخروج',
                          onPressed: () async {
                            await widget.repo.signOut();
                            await loadPermissions();
                          },
                          icon: const Icon(Icons.logout),
                        ),
                      ],
                    ),
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ContentFrame(
                    child: KeyedSubtree(
                      key: ValueKey('$page-$refresh'),
                      child: body(),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget body() {
    final key = pages[page].$1;
    if (key == 'dashboard' || key == 'reports' || key == 'alerts') {
      return Dashboard(
        widget.repo,
        kind: key,
        permissions: permissions,
        onNavigate: (key) {
          final i = pages.indexWhere((p) => p.$1 == key);
          if (i >= 0) selectPage(i);
        },
      );
    }
    if (key == 'booking_chats') return ChatInbox(widget.repo);
    if (key == 'assigned_tasks') return StaffTasks(widget.repo);
    if (key == 'calendar') return AdminCalendar(widget.repo);
    if (key == 'settings') return SettingsPanel(widget.repo);
    return RecordsPanel(widget.repo, table: key, title: pages[page].$2);
  }
}

class Dashboard extends StatelessWidget {
  final SakanRepository repo;
  final String kind;
  final Set<String> permissions;
  final void Function(String)? onNavigate;
  const Dashboard(
    this.repo, {
    required this.kind,
    this.permissions = const {},
    this.onNavigate,
    super.key,
  });
  Future<Map<String, List<Json>>> data() async {
    final names = [
      'bookings',
      'units',
      'payments',
      'refunds',
      'operations_tasks',
      'maintenance_requests',
    ];
    final results = await Future.wait(names.map(repo.table));
    return Map.fromIterables(names, results);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, List<Json>>>(
    future: data(),
    builder: (c, s) {
      if (s.hasError) return EmptyState('تعذر تحميل البيانات', '${s.error}');
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final d = s.data!;
      final bookings = d['bookings']!;
      final paid = d['payments']!
          .where(
            (p) => [
              'paid',
              'partially_refunded',
              'refunded',
            ].contains(p['status']),
          )
          .fold<int>(0, (v, p) => v + (p['amount'] as int));
      final refunded = d['refunds']!
          .where((r) => r['status'] == 'paid')
          .fold<int>(0, (v, r) => v + (r['amount'] as int));
      final today = dateKey(DateTime.now());
      final arrivals = bookings
          .where((b) => b['check_in'] == today && b['status'] == 'confirmed')
          .length;
      final active = bookings.where((b) => b['status'] == 'checked_in').length;
      final clean = d['operations_tasks']!
          .where((t) => t['kind'] == 'cleaning' && t['status'] != 'done')
          .length;
      final alerts = <String>[
        for (final r in d['refunds']!.where(
          (r) => ['requested', 'failed'].contains(r['status']),
        ))
          'طلب استرداد يحتاج مراجعة: ${money(r['amount'])}',
        for (final b in bookings.where(
          (b) => b['check_in'] == today && b['status'] == 'confirmed',
        ))
          if (d['operations_tasks']!.any(
            (t) => t['unit_id'] == b['unit_id'] && t['status'] != 'done',
          ))
            'دخول اليوم ${b['booking_number']} والوحدة تحتاج تجهيزًا',
        for (final p in d['payments']!.where(
          (p) => p['status'] == 'refund_required',
        ))
          'دفعة تحتاج معالجة مالية: ${money(p['amount'])}',
      ];
      return ListView(
        padding: SakanLayout.padding(context),
        children: [
          if (kind == 'dashboard') ...[
            Container(
              margin: const EdgeInsets.only(bottom: 24),
              padding: SakanLayout.padding(context),
              decoration: BoxDecoration(
                color: const Color(0xffe8ece3),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'مساحة العمل / اليوم',
                          style: TextStyle(
                            color: Color(0xff71816d),
                            fontSize: 12,
                          ),
                        ),
                        Space(10),
                        Text(
                          'أهلًا، يوم جديد في سكن',
                          style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w600,
                            color: brand,
                          ),
                        ),
                        Space(8),
                        Text(
                          'نظرة على الإقامات وما يحتاج انتباه فريقك.',
                          style: TextStyle(color: Color(0xff71816d)),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(width: 12),
                  Icon(Icons.wb_sunny_outlined, color: gold, size: 42),
                ],
              ),
            ),
            LayoutBuilder(
              builder: (context, constraints) => Wrap(
                spacing: 16,
                runSpacing: 16,
                children: [
                  for (final m in [
                    ('دخول اليوم', '$arrivals', Icons.login),
                    ('إقامات حالية', '$active', Icons.home_outlined),
                    ('تحتاج تنظيف', '$clean', Icons.cleaning_services),
                    ('إجمالي المدفوعات', money(paid), Icons.payments_outlined),
                  ])
                    SizedBox(
                      width: constraints.maxWidth > 900
                          ? (constraints.maxWidth - 48) / 4
                          : constraints.maxWidth > 540
                          ? (constraints.maxWidth - 16) / 2
                          : constraints.maxWidth,
                      child: MetricCard(
                        label: m.$1,
                        value: m.$2,
                        icon: m.$3,
                        compact: constraints.maxWidth <= 540,
                      ),
                    ),
                ],
              ),
            ),
            const Space(28),
          ],
          if (kind == 'dashboard') ...[
            const SectionTitle('اختصارات العمل'),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                for (final shortcut in [
                  ('bookings', 'الحجوزات', Icons.event_note, 'booking.read'),
                  (
                    'booking_chats',
                    'المحادثات',
                    Icons.chat_bubble_outline,
                    'customer.read',
                  ),
                  (
                    'units',
                    'إدارة الوحدات',
                    Icons.door_front_door_outlined,
                    'catalog.write',
                  ),
                  (
                    'operations_tasks',
                    'متابعة التشغيل',
                    Icons.checklist,
                    'operations.write',
                  ),
                ])
                  if (permissions.contains(shortcut.$4))
                    OutlinedButton.icon(
                      onPressed: () => onNavigate?.call(shortcut.$1),
                      icon: Icon(shortcut.$3, size: 20),
                      label: Text(shortcut.$2),
                    ),
              ],
            ),
            const SectionTitle('آخر الحجوزات'),
            if (bookings.isEmpty)
              const EmptyState(
                'لا توجد حجوزات بعد',
                'ستظهر أحدث الحجوزات هنا عند تسجيلها.',
              ),
            for (final b
                in (bookings.toList()..sort(
                      (a, b) => (b['created_at'] ?? '').toString().compareTo(
                        (a['created_at'] ?? '').toString(),
                      ),
                    ))
                    .take(5))
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Card(
                  child: ListTile(
                    title: Text('${b['booking_number']}'),
                    subtitle: Text(
                      '${b['check_in']} ← ${b['check_out']}\n${statusLabel(b['status'])}',
                    ),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: permissions.contains('booking.read')
                        ? () => onNavigate?.call('bookings')
                        : null,
                  ),
                ),
              ),
          ],
          if (kind != 'alerts') ...[
            const SectionTitle('الحجوزات خلال آخر 7 أيام'),
            Card(
              child: Padding(
                padding: SakanLayout.padding(context),
                child: Column(
                  children: List.generate(7, (i) {
                    final day = dateKey(
                      DateTime.now().subtract(Duration(days: 6 - i)),
                    );
                    final count = bookings
                        .where(
                          (b) => (b['created_at'] ?? '').toString().startsWith(
                            day,
                          ),
                        )
                        .length;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          SizedBox(width: 95, child: Text(day)),
                          Expanded(
                            child: LinearProgressIndicator(
                              value: bookings.isEmpty
                                  ? 0
                                  : count / bookings.length,
                              minHeight: 14,
                              borderRadius: BorderRadius.circular(8),
                              backgroundColor: canvas,
                            ),
                          ),
                          const SizedBox(width: 18),
                          Text('$count'),
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ),
            const Space(24),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                Tag('${bookings.length} حجز'),
                Tag('${d['units']!.length} وحدة'),
                Tag('الاستردادات المنفذة ${money(refunded)}'),
                Tag('صافي المقبوضات ${money(paid - refunded)}'),
              ],
            ),
          ],
          const SectionTitle('يحتاج انتباهك'),
          if (alerts.isEmpty)
            const EmptyState(
              'التشغيل واضح اليوم',
              'لا توجد تنبيهات في البيانات الحالية.',
              icon: Icons.check_circle_outline,
            ),
          for (final a in alerts)
            Card(
              child: ListTile(
                leading: const Icon(Icons.warning_amber, color: gold),
                title: Text(a),
              ),
            ),
          if (repo.demo)
            const Text(
              'المؤشرات من بيانات التجربة المحلية. جميع القيم المالية بالريال السعودي.',
              style: TextStyle(color: Color(0xff5d685f)),
            ),
        ],
      );
    },
  );
}
