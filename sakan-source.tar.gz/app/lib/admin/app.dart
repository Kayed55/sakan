import 'package:flutter/material.dart';
import '../core/bootstrap.dart';
import '../core/models.dart';
import '../core/repository.dart';
import '../customer/auth.dart';
import '../customer/widgets.dart';
import 'editor.dart';
import 'actions.dart';
import 'calendar.dart';

class AdminApp extends StatelessWidget {
  final SakanRepository repo;
  const AdminApp({required this.repo, super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'سكن | لوحة الإدارة',
    theme: sakanTheme(),
    locale: const Locale('ar'),
    supportedLocales: locales,
    localizationsDelegates: delegates,
    home: AdminShell(repo),
  );
}

const pages = [
  ('dashboard', 'نظرة عامة', Icons.space_dashboard_outlined, 'reports.read'),
  ('bookings', 'الحجوزات', Icons.event_note, 'booking.read'),
  ('properties', 'العقارات', Icons.apartment, 'catalog.write'),
  ('units', 'الوحدات', Icons.door_front_door_outlined, 'catalog.write'),
  ('calendar', 'التقويم والأسعار', Icons.calendar_month, 'catalog.write'),
  (
    'operations_tasks',
    'التشغيل والتنظيف',
    Icons.cleaning_services_outlined,
    'operations.write',
  ),
  (
    'access_instructions',
    'تعليمات الدخول',
    Icons.key_outlined,
    'operations.write',
  ),
  ('maintenance_requests', 'الصيانة', Icons.build_outlined, 'operations.write'),
  ('profiles', 'العملاء', Icons.people_outline, 'customer.read'),
  ('payments', 'المدفوعات', Icons.payments_outlined, 'finance.read'),
  ('refunds', 'الاستردادات', Icons.undo, 'finance.read'),
  ('coupons', 'الكوبونات', Icons.local_offer_outlined, 'content.write'),
  ('home_content', 'محتوى الرئيسية', Icons.web, 'content.write'),
  ('reviews', 'التقييمات', Icons.star_outline, 'content.write'),
  ('notifications', 'الإشعارات', Icons.notifications_none, 'content.write'),
  ('reports', 'التقارير', Icons.bar_chart, 'reports.read'),
  (
    'user_roles',
    'المستخدمون والصلاحيات',
    Icons.admin_panel_settings_outlined,
    'roles.write',
  ),
  ('settings', 'الإعدادات والمدن', Icons.settings_outlined, 'settings.write'),
  ('alerts', 'تنبيهات التشغيل', Icons.warning_amber, 'operations.write'),
  ('support_requests', 'طلبات العملاء', Icons.support_agent, 'customer.read'),
  ('assigned_tasks', 'مهامي', Icons.checklist, 'tasks.assigned'),
  ('audit_logs', 'سجل العمليات', Icons.history, 'audit.read'),
];

class AdminShell extends StatefulWidget {
  final SakanRepository repo;
  const AdminShell(this.repo, {super.key});
  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int page = 0;
  Set<String> permissions = {};
  bool loading = true;
  int refresh = 0;
  @override
  void initState() {
    super.initState();
    loadPermissions();
  }

  Future<void> loadPermissions() async {
    final result = <String>{};
    if (widget.repo.demo || widget.repo.signedIn) {
      for (final p in pages) {
        if (await widget.repo.allowed(p.$4)) result.add(p.$4);
      }
    }
    if (mounted) {
      setState(() {
        permissions = result;
        loading = false;
        final first = pages.indexWhere((p) => permissions.contains(p.$4));
        if (first >= 0 && !permissions.contains(pages[page].$4)) page = first;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (!widget.repo.demo && !widget.repo.signedIn) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SectionTitle('إدارة سكن'),
              FilledButton(
                onPressed: () async {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => LoginPage(widget.repo)),
                  );
                  await loadPermissions();
                },
                child: const Text('تسجيل الدخول للموظفين'),
              ),
            ],
          ),
        ),
      );
    }
    if (permissions.isEmpty) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const EmptyState(
                'لا توجد صلاحيات إدارية',
                'يحتاج حسابك إلى دور يمنحه مدير النظام.',
              ),
              TextButton(
                onPressed: () async {
                  await widget.repo.signOut();
                  await loadPermissions();
                },
                child: const Text('تسجيل الخروج'),
              ),
            ],
          ),
        ),
      );
    }
    final wide = MediaQuery.sizeOf(context).width > 950;
    final menu = SizedBox(
      width: 245,
      child: Material(
        color: brand,
        child: SafeArea(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Padding(
                padding: EdgeInsets.all(26),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'سكن',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 40,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      'مساحة الإدارة والتشغيل',
                      style: TextStyle(color: Colors.white60),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  children: [
                    for (int i = 0; i < pages.length; i++)
                      if (permissions.contains(pages[i].$4))
                        Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 2,
                          ),
                          child: ListTile(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            selected: i == page,
                            selectedTileColor: Colors.white.withValues(
                              alpha: .13,
                            ),
                            selectedColor: Colors.white,
                            textColor: Colors.white70,
                            iconColor: Colors.white60,
                            leading: Icon(pages[i].$3, size: 20),
                            title: Text(
                              pages[i].$2,
                              style: const TextStyle(fontSize: 13),
                            ),
                            onTap: () {
                              setState(() => page = i);
                              if (!wide) Navigator.pop(context);
                            },
                          ),
                        ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'الرياض أولًا. والمملكة وجهتنا.',
                  style: TextStyle(color: Colors.white54, fontSize: 11),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    return Scaffold(
      drawer: wide ? null : Drawer(child: menu),
      appBar: wide ? null : AppBar(title: Text(pages[page].$2)),
      body: Row(
        children: [
          if (wide) menu,
          Expanded(
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 28,
                    vertical: 20,
                  ),
                  color: Colors.white,
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              pages[page].$2,
                              style: Theme.of(context).textTheme.headlineSmall,
                            ),
                            Text(
                              'الرياض  /  ${dateKey(DateTime.now())}',
                              style: const TextStyle(color: Colors.black45),
                            ),
                          ],
                        ),
                      ),
                      if (widget.repo.demo) const Tag('بيئة تجريبية'),
                      IconButton(
                        onPressed: () => setState(() => refresh++),
                        icon: const Icon(Icons.refresh),
                      ),
                      IconButton(
                        onPressed: () async {
                          await widget.repo.signOut();
                          await loadPermissions();
                        },
                        icon: const Icon(Icons.logout),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: KeyedSubtree(
                    key: ValueKey('$page-$refresh'),
                    child: body(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget body() {
    final key = pages[page].$1;
    if (key == 'dashboard' || key == 'reports' || key == 'alerts') {
      return Dashboard(widget.repo, kind: key);
    }
    if (key == 'assigned_tasks') return StaffTasks(widget.repo);
    if (key == 'calendar') return AdminCalendar(widget.repo);
    if (key == 'settings') return SettingsPanel(widget.repo);
    return RecordsPanel(widget.repo, table: key, title: pages[page].$2);
  }
}

class Dashboard extends StatelessWidget {
  final SakanRepository repo;
  final String kind;
  const Dashboard(this.repo, {required this.kind, super.key});
  Future<Map<String, List<Json>>> data() async {
    final names = [
      'bookings',
      'units',
      'payments',
      'refunds',
      'operations_tasks',
      'maintenance_requests',
    ];
    final results = await Future.wait(names.map(repo.table));
    return Map.fromIterables(names, results);
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, List<Json>>>(
    future: data(),
    builder: (c, s) {
      if (s.hasError) return EmptyState('تعذر تحميل البيانات', '${s.error}');
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      final d = s.data!;
      final bookings = d['bookings']!;
      final paid = d['payments']!
          .where(
            (p) => [
              'paid',
              'partially_refunded',
              'refunded',
            ].contains(p['status']),
          )
          .fold<int>(0, (v, p) => v + (p['amount'] as int));
      final refunded = d['refunds']!
          .where((r) => r['status'] == 'paid')
          .fold<int>(0, (v, r) => v + (r['amount'] as int));
      final today = dateKey(DateTime.now());
      final arrivals = bookings
          .where((b) => b['check_in'] == today && b['status'] == 'confirmed')
          .length;
      final active = bookings.where((b) => b['status'] == 'checked_in').length;
      final clean = d['operations_tasks']!
          .where((t) => t['kind'] == 'cleaning' && t['status'] != 'done')
          .length;
      final alerts = <String>[
        for (final r in d['refunds']!.where(
          (r) => ['requested', 'failed'].contains(r['status']),
        ))
          'طلب استرداد يحتاج مراجعة: ${money(r['amount'])}',
        for (final b in bookings.where(
          (b) => b['check_in'] == today && b['status'] == 'confirmed',
        ))
          if (d['operations_tasks']!.any(
            (t) => t['unit_id'] == b['unit_id'] && t['status'] != 'done',
          ))
            'دخول اليوم ${b['booking_number']} والوحدة تحتاج تجهيزًا',
        for (final p in d['payments']!.where(
          (p) => p['status'] == 'refund_required',
        ))
          'دفعة تحتاج معالجة مالية: ${money(p['amount'])}',
      ];
      return ListView(
        padding: const EdgeInsets.all(28),
        children: [
          if (kind == 'dashboard') ...[
            const SectionTitle(
              'أهلًا، يوم جديد في سكن',
              subtitle: 'نظرة على الإقامات وما يحتاج انتباه فريقك.',
            ),
            Wrap(
              spacing: 16,
              runSpacing: 16,
              children: [
                for (final m in [
                  ('دخول اليوم', '$arrivals', Icons.login),
                  ('إقامات حالية', '$active', Icons.home_outlined),
                  ('تحتاج تنظيف', '$clean', Icons.cleaning_services),
                  ('إجمالي المدفوعات', money(paid), Icons.payments_outlined),
                ])
                  SizedBox(
                    width: 220,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(22),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(m.$3, color: gold),
                            const Space(20),
                            Text(
                              m.$2,
                              style: const TextStyle(
                                fontSize: 28,
                                fontWeight: FontWeight.w700,
                                color: brand,
                              ),
                            ),
                            Text(
                              m.$1,
                              style: const TextStyle(color: Colors.black54),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const Space(28),
          ],
          if (kind != 'alerts') ...[
            const SectionTitle('الحجوزات خلال آخر 7 أيام'),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: List.generate(7, (i) {
                    final day = dateKey(
                      DateTime.now().subtract(Duration(days: 6 - i)),
                    );
                    final count = bookings
                        .where(
                          (b) => (b['created_at'] ?? '').toString().startsWith(
                            day,
                          ),
                        )
                        .length;
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(
                        children: [
                          SizedBox(width: 95, child: Text(day)),
                          Expanded(
                            child: LinearProgressIndicator(
                              value: bookings.isEmpty
                                  ? 0
                                  : count / bookings.length,
                              minHeight: 14,
                              borderRadius: BorderRadius.circular(8),
                              backgroundColor: canvas,
                            ),
                          ),
                          const SizedBox(width: 18),
                          Text('$count'),
                        ],
                      ),
                    );
                  }),
                ),
              ),
            ),
            const Space(24),
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                Tag('${bookings.length} حجز'),
                Tag('${d['units']!.length} وحدة'),
                Tag('الاستردادات المنفذة ${money(refunded)}'),
                Tag('صافي المقبوضات ${money(paid - refunded)}'),
              ],
            ),
          ],
          const SectionTitle('يحتاج انتباهك'),
          if (alerts.isEmpty)
            const EmptyState(
              'التشغيل واضح اليوم',
              'لا توجد تنبيهات في البيانات الحالية.',
              icon: Icons.check_circle_outline,
            ),
          for (final a in alerts)
            Card(
              child: ListTile(
                leading: const Icon(Icons.warning_amber, color: gold),
                title: Text(a),
              ),
            ),
          if (repo.demo)
            const Text(
              'المؤشرات من بيانات التجربة المحلية. جميع القيم المالية بالريال السعودي.',
              style: TextStyle(color: Colors.black45),
            ),
        ],
      );
    },
  );
}
