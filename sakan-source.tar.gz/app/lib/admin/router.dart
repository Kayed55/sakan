import 'package:flutter/material.dart';
import '../core/routes.dart';
import '../core/repository.dart';
import '../core/models.dart';
import '../chat/chat.dart';
import 'app.dart';
import 'images.dart';
import 'editor.dart';
import 'login.dart';
import '../customer/design.dart';

GoRouter adminRouter(SakanRepository repo, {String? initialLocation}) {
  GoRouter.optionURLReflectsImperativeAPIs = true;
  return GoRouter(
    initialLocation: initialLocation,
    errorBuilder: (_, s) => const RouteFailure(),
    routes: [
      GoRoute(path: '/login', builder: (_, s) => AdminLoginPage(repo)),
      for (final item in [
        ('regions', 'المناطق'),
        ('cities', 'المدن'),
        ('districts', 'الأحياء'),
      ])
        GoRoute(
          path: '/settings/${item.$1}',
          builder: (_, s) => AdminProtected(
            repo: repo,
            permission: 'settings.write',
            child: Scaffold(
              appBar: AppBar(title: Text(item.$2)),
              body: RecordsPanel(repo, table: item.$1, title: item.$2),
            ),
          ),
        ),
      GoRoute(
        path: '/',
        pageBuilder: (_, s) => NoTransitionPage(
          key: const ValueKey('admin-shell'),
          child: AdminShell(repo, location: s.uri),
        ),
      ),
      GoRoute(
        path: '/chats/:id',
        builder: (_, s) => AdminProtected(
          repo: repo,
          permission: 'customer.read',
          child: ResolvedRoute<Booking>(
            load: () => repo.bookingById(s.pathParameters['id']!),
            builder: (b) => BookingChat(
              repo: repo,
              bookingId: b.id,
              bookingNumber: b.number,
              support: true,
            ),
          ),
        ),
      ),
      GoRoute(
        path: '/unit-images',
        builder: (_, s) => AdminProtected(
          repo: repo,
          permission: 'catalog.write',
          child: ImagesPanel(repo),
        ),
      ),
      GoRoute(
        path: '/property-addresses',
        builder: (_, s) => AdminProtected(
          repo: repo,
          permission: 'catalog.write',
          child: Scaffold(
            appBar: AppBar(title: const Text('العناوين الدقيقة')),
            body: RecordsPanel(
              repo,
              table: 'property_private',
              title: 'العناوين الدقيقة',
            ),
          ),
        ),
      ),
      GoRoute(
        path: '/:section',
        pageBuilder: (_, s) => NoTransitionPage(
          key: const ValueKey('admin-shell'),
          child:
              pages.any(
                (p) => p.$1.replaceAll('_', '-') == s.pathParameters['section'],
              )
              ? AdminShell(repo, location: s.uri)
              : const RouteFailure(),
        ),
      ),
    ],
  );
}

class AdminProtected extends StatefulWidget {
  final SakanRepository repo;
  final String permission;
  final Widget child;
  const AdminProtected({
    required this.repo,
    required this.permission,
    required this.child,
    super.key,
  });
  @override
  State<AdminProtected> createState() => _AdminProtectedState();
}

class _AdminProtectedState extends State<AdminProtected> {
  late Future<bool> permission = widget.repo.allowed(widget.permission);
  @override
  Widget build(BuildContext context) =>
      !widget.repo.signedIn && !widget.repo.demo
      ? AdminWelcome(
          onLogin: () async {
            await openPage(
              context,
              '/login',
              (_) => AdminLoginPage(widget.repo),
            );
            if (mounted) {
              setState(
                () => permission = widget.repo.allowed(widget.permission),
              );
            }
          },
        )
      : FutureBuilder<bool>(
          future: permission,
          builder: (context, s) {
            if (s.connectionState != ConnectionState.done) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }
            if (s.data != true) {
              return const RouteFailure(
                'سجّل الدخول إلى الإدارة بحساب يملك صلاحية الوصول لهذه الصفحة.',
              );
            }
            return widget.child;
          },
        );
}
