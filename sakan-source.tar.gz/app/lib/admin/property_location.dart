import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/map_address.dart';
import '../core/repository.dart';
import '../customer/widgets.dart';

/// The exact address is private and shared by units in the selected property.
/// It is saved explicitly, independently from the unit form.
class PropertyLocation extends StatefulWidget {
  final SakanRepository repo;
  final String propertyId;
  const PropertyLocation(this.repo, {required this.propertyId, super.key});
  @override
  State<PropertyLocation> createState() => _PropertyLocationState();
}

class _PropertyLocationState extends State<PropertyLocation> {
  final address = TextEditingController();
  bool loading = true, saving = false;
  String? error;
  String savedAddress = '';

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    address.dispose();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final row = await widget.repo.propertyLocation(widget.propertyId);
      if (!mounted) return;
      savedAddress = row?['address'] as String? ?? '';
      address.text = savedAddress;
      setState(() {
        loading = false;
        error = null;
      });
    } catch (_) {
      if (mounted) {
        setState(() {
          loading = false;
          error = 'تعذّر تحميل العنوان. أعد المحاولة قبل تعديله.';
        });
      }
    }
  }

  Future<void> openMap() async {
    try {
      final uri = googleMapsAddress(address.text);
      final opened = await launchUrl(
        uri,
        mode: LaunchMode.externalApplication,
        webOnlyWindowName: '_blank',
      );
      if (!opened) throw StateError('لم تفتح الخريطة');
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('أدخل العنوان واسم المدينة ثم أعد فتح الخريطة.'),
          ),
        );
      }
    }
  }

  Future<void> save() async {
    final text = address.text.trim();
    googleMapsAddress(text); // Validate without sending the address anywhere.
    setState(() => saving = true);
    try {
      await widget.repo.savePropertyAddress(widget.propertyId, text);
      if (!mounted) return;
      setState(() => savedAddress = text);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ عنوان العقار المرتبط بالوحدة')),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 20),
    child: Padding(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'موقع الوحدة على خرائط Google',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
          ),
          const SizedBox(height: 8),
          const Text(
            'الصق العنوان كاملًا مع المدينة، ثم افتحه على الخريطة للتأكد من الموقع.',
          ),
          const SizedBox(height: 16),
          if (loading)
            const Center(child: CircularProgressIndicator())
          else if (error != null) ...[
            Text(error!),
            TextButton(
              onPressed: () {
                setState(() => loading = true);
                load();
              },
              child: const Text('إعادة المحاولة'),
            ),
          ] else ...[
            TextField(
              controller: address,
              enabled: !saving,
              minLines: 2,
              maxLines: 3,
              maxLength: 1000,
              decoration: const InputDecoration(
                labelText: 'العنوان المنسوخ من Google Maps',
                hintText: 'رقم المبنى، الشارع، الحي، المدينة، الرمز البريدي',
                prefixIcon: Icon(Icons.location_on_outlined),
              ),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                OutlinedButton.icon(
                  onPressed: address.text.trim().isEmpty ? null : openMap,
                  icon: const Icon(Icons.map_outlined),
                  label: const Text('تحديد الموقع في Google Maps'),
                ),
                AsyncAction(label: 'حفظ عنوان العقار', action: save),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              address.text.trim() == savedAddress && savedAddress.isNotEmpty
                  ? 'العنوان محفوظ'
                  : 'احفظ العنوان من الزر أعلاه قبل إغلاق النموذج.',
            ),
            const SizedBox(height: 8),
            const Text(
              'هذا عنوان العقار ويُستخدم لجميع وحداته. تأكد من دبوس الموقع في Google قبل حفظ العنوان.',
              style: TextStyle(fontSize: 12, color: Color(0xff5d685f)),
            ),
          ],
        ],
      ),
    ),
  );
}
