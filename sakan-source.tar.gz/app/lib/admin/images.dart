import 'dart:convert';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:uuid/uuid.dart';
import '../core/models.dart';
import '../core/repository.dart';
import '../customer/widgets.dart';

class ImagesPanel extends StatefulWidget {
  final SakanRepository repo;
  const ImagesPanel(this.repo, {super.key});
  @override
  State<ImagesPanel> createState() => _ImagesPanelState();
}

class _ImagesPanelState extends State<ImagesPanel> {
  String? selected;
  late Future<List<Json>> units, images;
  @override
  void initState() {
    super.initState();
    units = widget.repo.table('units');
    reload();
  }

  void reload() {
    images = widget.repo.table('unit_images');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('صور الوحدات')),
    body: ListView(
      padding: const EdgeInsets.all(28),
      children: [
        FutureBuilder<List<Json>>(
          future: units,
          builder: (c, s) => DropdownButtonFormField<String>(
            decoration: const InputDecoration(labelText: 'اختر الوحدة'),
            items: (s.data ?? [])
                .map(
                  (u) => DropdownMenuItem(
                    value: u['id'] as String,
                    child: Text(u['name_ar']),
                  ),
                )
                .toList(),
            onChanged: (v) => setState(() => selected = v),
          ),
        ),
        const Space(),
        AsyncAction(label: 'رفع صور من جهازك', action: upload),
        const Space(12),
        Text(
          widget.repo.demo
              ? 'التجربة المحلية تقبل صورًا حتى 1 ميغابايت للصورة.'
              : 'JPG / PNG / WebP حتى 10 ميغابايت للصورة.',
        ),
        const Space(),
        FutureBuilder<List<Json>>(
          future: images,
          builder: (c, s) {
            if (s.hasError) return EmptyState('تعذر عرض الصور', '${s.error}');
            final rows =
                (s.data ?? []).where((i) => i['unit_id'] == selected).toList()
                  ..sort(
                    (a, b) =>
                        (a['sort_order'] as int).compareTo(b['sort_order']),
                  );
            return Wrap(
              spacing: 16,
              runSpacing: 16,
              children: rows
                  .map(
                    (i) => SizedBox(
                      width: 260,
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Column(
                            children: [
                              Picture(i['image_url'], height: 160),
                              const Space(8),
                              if (i['is_cover'] == true)
                                const Tag('صورة الغلاف'),
                              Text('الترتيب ${i['sort_order']}'),
                              AsyncAction(
                                label: 'تعيين غلاف',
                                action: () async {
                                  if (widget.repo.demo) {
                                    for (final row
                                        in widget.repo.local['unit_images'] ??
                                            <Json>[]) {
                                      if (row['unit_id'] == selected) {
                                        row['is_cover'] = row['id'] == i['id'];
                                      }
                                    }
                                    await widget.repo.save();
                                  } else {
                                    await widget.repo.client!.rpc(
                                      'set_cover_image',
                                      params: {'p_image': i['id']},
                                    );
                                  }
                                  setState(reload);
                                },
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  IconButton(
                                    tooltip: 'تقديم',
                                    onPressed: () => order(i, -1),
                                    icon: const Icon(Icons.arrow_upward),
                                  ),
                                  IconButton(
                                    tooltip: 'تأخير',
                                    onPressed: () => order(i, 1),
                                    icon: const Icon(Icons.arrow_downward),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            );
          },
        ),
      ],
    ),
  );
  Future<void> order(Json i, int delta) async {
    try {
      await widget.repo.upsert('unit_images', {
        'id': i['id'],
        'unit_id': i['unit_id'],
        'image_url': i['image_url'],
        'is_cover': i['is_cover'],
        'sort_order': ((i['sort_order'] as int) + delta).clamp(0, 999),
      });
      setState(reload);
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  Future<void> upload() async {
    if (selected == null) throw StateError('اختر الوحدة أولًا');
    const type = XTypeGroup(
      label: 'Images',
      extensions: ['jpg', 'jpeg', 'png', 'webp'],
      mimeTypes: ['image/jpeg', 'image/png', 'image/webp'],
      uniformTypeIdentifiers: ['public.image'],
    );
    final files = await openFiles(acceptedTypeGroups: [type]);
    final existing = (await widget.repo.table(
      'unit_images',
    )).where((i) => i['unit_id'] == selected).length;
    int index = existing;
    for (final file in files) {
      final ext = file.name.split('.').last.toLowerCase();
      final mime = ext == 'png'
          ? 'image/png'
          : ext == 'webp'
          ? 'image/webp'
          : 'image/jpeg';
      final bytes = await file.readAsBytes();
      if (bytes.length > (widget.repo.demo ? 1048576 : 10485760)) {
        throw StateError('الصورة ${file.name} أكبر من الحد المسموح');
      }
      if (!['jpg', 'jpeg', 'png', 'webp'].contains(ext)) {
        throw StateError('صيغة غير مدعومة');
      }
      String url;
      if (widget.repo.demo) {
        url = 'data:$mime;base64,${base64Encode(bytes)}';
      } else {
        final path = '$selected/${const Uuid().v4()}.$ext';
        await widget.repo.client!.storage
            .from('unit-images')
            .uploadBinary(
              path,
              bytes,
              fileOptions: FileOptions(contentType: mime),
            );
        url = widget.repo.client!.storage
            .from('unit-images')
            .getPublicUrl(path);
      }
      await widget.repo.upsert('unit_images', {
        'unit_id': selected,
        'image_url': url,
        'sort_order': index,
        'is_cover': index == 0,
      });
      index++;
    }
    if (mounted) setState(reload);
  }
}
