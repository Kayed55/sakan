import 'package:flutter/material.dart';
import '../core/models.dart';
import '../core/repository.dart';
import '../customer/widgets.dart';

class AdminCalendar extends StatefulWidget {
  final SakanRepository repo;
  const AdminCalendar(this.repo, {super.key});
  @override
  State<AdminCalendar> createState() => _AdminCalendarState();
}

class _AdminCalendarState extends State<AdminCalendar> {
  DateTime start = dayOnly(DateTime.now());
  late Future<List<List<Json>>> future;
  @override
  void initState() {
    super.initState();
    reload();
  }

  void reload() {
    future = Future.wait(
      [
        'units',
        'bookings',
        'unit_rates',
        'inventory_locks',
      ].map(widget.repo.table),
    );
  }

  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(28),
    children: [
      Row(
        children: [
          const Expanded(
            child: SectionTitle(
              'تقويم الوحدات',
              subtitle: 'اختر يومًا لتعديل سعره أو حجب الوحدة.',
            ),
          ),
          IconButton(
            onPressed: () =>
                setState(() => start = start.subtract(const Duration(days: 7))),
            icon: const Icon(Icons.chevron_right),
          ),
          Text(dateKey(start)),
          IconButton(
            onPressed: () =>
                setState(() => start = start.add(const Duration(days: 7))),
            icon: const Icon(Icons.chevron_left),
          ),
        ],
      ),
      FutureBuilder<List<List<Json>>>(
        future: future,
        builder: (c, s) {
          if (s.hasError) return EmptyState('تعذر تحميل التقويم', '${s.error}');
          if (!s.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final units = s.data![0],
              bookings = s.data![1],
              rates = s.data![2],
              locks = s.data![3];
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: [
                const DataColumn(label: Text('الوحدة')),
                for (int i = 0; i < 7; i++)
                  DataColumn(
                    label: Text(dateKey(start.add(Duration(days: i)))),
                  ),
              ],
              rows: units
                  .map(
                    (u) => DataRow(
                      cells: [
                        DataCell(Text(u['name_ar'])),
                        for (int i = 0; i < 7; i++)
                          cell(
                            u,
                            start.add(Duration(days: i)),
                            bookings,
                            rates,
                            locks,
                          ),
                      ],
                    ),
                  )
                  .toList(),
            ),
          );
        },
      ),
    ],
  );
  DataCell cell(
    Json unit,
    DateTime day,
    List<Json> bookings,
    List<Json> rates,
    List<Json> locks,
  ) {
    final key = dateKey(day);
    final b = bookings
        .where(
          (b) =>
              b['unit_id'] == unit['id'] &&
              ['hold', 'confirmed', 'checked_in'].contains(b['status']) &&
              key.compareTo(b['check_in']) >= 0 &&
              key.compareTo(b['check_out']) < 0 &&
              (b['status'] != 'hold' ||
                  DateTime.parse(b['hold_expires_at']).isAfter(DateTime.now())),
        )
        .firstOrNull;
    final blocked = locks.any((l) {
      if (l['unit_id'] != unit['id']) return false;
      if (l['start'] != null) {
        return key.compareTo(l['start']) >= 0 && key.compareTo(l['end']) < 0;
      }
      final range = (l['stay'] ?? '')
          .toString()
          .replaceAll(RegExp(r'[\[\)\"]'), '')
          .split(',');
      return l['kind'] != 'hold' &&
          range.length == 2 &&
          key.compareTo(range[0]) >= 0 &&
          key.compareTo(range[1]) < 0;
    });
    final r = rates
        .where((r) => r['unit_id'] == unit['id'] && r['day'] == key)
        .firstOrNull;
    return DataCell(
      Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: b != null
              ? brand.withValues(alpha: .18)
              : blocked
              ? Colors.orange.shade100
              : Colors.white,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          b != null
              ? statusLabel(b['status'])
              : blocked
              ? 'محجوبة'
              : money(r?['price'] ?? unit['base_price']),
        ),
      ),
      onTap: b != null || blocked ? null : () => edit(unit, day, r),
    );
  }

  Future<void> edit(Json unit, DateTime day, Json? rate) async {
    final price = TextEditingController(
      text: '${(rate?['price'] ?? unit['base_price']) / 100}',
    );
    final reason = TextEditingController();
    bool block = false;
    await showDialog(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('${unit['name_ar']} • ${dateKey(day)}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SwitchListTile(
                title: const Text('حجب اليوم'),
                value: block,
                onChanged: (v) => set(() => block = v),
              ),
              TextField(
                controller: block ? reason : price,
                decoration: InputDecoration(
                  labelText: block ? 'سبب الحجب' : 'السعر بالريال',
                ),
              ),
            ],
          ),
          actions: [
            AsyncAction(
              label: 'تطبيق',
              action: () async {
                if (block) {
                  if (reason.text.trim().isEmpty) {
                    throw StateError('اذكر سبب الحجب');
                  }
                  await widget.repo.block(
                    unit['id'],
                    Stay(day, day.add(const Duration(days: 1)), adults: 1),
                    reason.text,
                  );
                } else {
                  final value = double.tryParse(price.text);
                  if (value == null || value <= 0) {
                    throw StateError('أدخل سعرًا صحيحًا');
                  }
                  if (widget.repo.demo) {
                    widget.repo.local['unit_rates']!.removeWhere(
                      (r) =>
                          r['unit_id'] == unit['id'] &&
                          r['day'] == dateKey(day),
                    );
                  }
                  await widget.repo.upsert('unit_rates', {
                    'unit_id': unit['id'],
                    'day': dateKey(day),
                    'price': (value * 100).round(),
                    'min_nights': 1,
                  });
                }
                if (c.mounted) Navigator.pop(c);
              },
            ),
          ],
        ),
      ),
    );
    price.dispose();
    reason.dispose();
    if (mounted) setState(reload);
  }
}
