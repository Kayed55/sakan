import '../ui/system.dart';
import 'package:flutter/material.dart';
import '../core/models.dart';
import '../core/repository.dart';
import '../customer/widgets.dart';

class NotificationComposer extends StatefulWidget {
  final SakanRepository repo;
  const NotificationComposer(this.repo, {super.key});
  @override
  State<NotificationComposer> createState() => _NotificationComposerState();
}

class _NotificationComposerState extends State<NotificationComposer> {
  final title = TextEditingController(), body = TextEditingController();
  String? customer;
  late Future<List<Json>> people;
  @override
  void initState() {
    super.initState();
    people = widget.repo.table('profiles');
  }

  @override
  void dispose() {
    title.dispose();
    body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    scrollable: true,
    title: const Text('إشعار إلى عميل'),
    content: SizedBox(
      width: 480,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          FutureBuilder<List<Json>>(
            future: people,
            builder: (c, s) => DropdownButtonFormField<String>(
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'العميل'),
              items: (s.data ?? [])
                  .map(
                    (p) => DropdownMenuItem(
                      value: p['id'] as String,
                      child: Text(
                        p['full_name'].toString().isEmpty
                            ? p['id']
                            : p['full_name'],
                      ),
                    ),
                  )
                  .toList(),
              onChanged: (v) => customer = v,
            ),
          ),
          const Space(),
          TextField(
            controller: title,
            decoration: const InputDecoration(labelText: 'العنوان'),
          ),
          const Space(),
          TextField(
            controller: body,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'المحتوى'),
          ),
          const Space(),
          const Text(
            'يسجل الإشعار داخل التطبيق. التسليم عبر Push يحتاج ربط مزود الإشعارات.',
          ),
        ],
      ),
    ),
    actions: [
      AsyncAction(
        label: 'إرسال',
        action: () async {
          if (customer == null || title.text.trim().isEmpty) {
            throw StateError('اختر العميل وأدخل العنوان');
          }
          if (widget.repo.demo) {
            await widget.repo.upsert('notifications', {
              'customer_id': customer,
              'title': title.text,
              'body': body.text,
              'created_at': DateTime.now().toIso8601String(),
            });
          } else {
            await widget.repo.client!.rpc(
              'send_notification',
              params: {
                'p_customer': customer,
                'p_title': title.text,
                'p_body': body.text,
              },
            );
          }
          if (context.mounted) Navigator.pop(context);
        },
      ),
    ],
  );
}

class RefundComposer extends StatefulWidget {
  final SakanRepository repo;
  final Json payment;
  const RefundComposer(this.repo, this.payment, {super.key});
  @override
  State<RefundComposer> createState() => _RefundComposerState();
}

class _RefundComposerState extends State<RefundComposer> {
  final amount = TextEditingController(), reason = TextEditingController();
  @override
  void dispose() {
    amount.dispose();
    reason.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    scrollable: true,
    title: const Text('اعتماد طلب استرداد'),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('الدفعة: ${money(widget.payment['amount'])}'),
        const Space(),
        TextField(
          controller: amount,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'المبلغ بالريال'),
        ),
        const Space(),
        TextField(
          controller: reason,
          decoration: const InputDecoration(labelText: 'السبب'),
        ),
        const Space(),
        const Text(
          'الاعتماد يسجل طلبًا ماليًا؛ التنفيذ لدى مزود الدفع مرحلة مستقلة.',
        ),
      ],
    ),
    actions: [
      AsyncAction(
        label: 'اعتماد الطلب',
        action: () async {
          final v = double.tryParse(amount.text);
          if (v == null ||
              v <= 0 ||
              v * 100 > widget.payment['amount'] ||
              reason.text.trim().length < 2) {
            throw StateError('تحقق من المبلغ والسبب');
          }
          if (widget.repo.demo) {
            final reserved = widget.repo.local['refunds']!
                .where(
                  (r) =>
                      r['payment_id'] == widget.payment['id'] &&
                      ['approved', 'processing', 'paid'].contains(r['status']),
                )
                .fold<int>(0, (s, r) => s + (r['amount'] as int));
            if (reserved + (v * 100).round() > widget.payment['amount']) {
              throw StateError('المبلغ يتجاوز الرصيد المتاح');
            }
            await widget.repo.upsert('refunds', {
              'payment_id': widget.payment['id'],
              'booking_id': widget.payment['booking_id'],
              'amount': (v * 100).round(),
              'reason': reason.text,
              'status': 'approved',
            });
          } else {
            await widget.repo.client!.rpc(
              'approve_refund',
              params: {
                'p_payment': widget.payment['id'],
                'p_amount': (v * 100).round(),
                'p_reason': reason.text,
              },
            );
          }
          if (context.mounted) Navigator.pop(context);
        },
      ),
    ],
  );
}

class StaffTasks extends StatefulWidget {
  final SakanRepository repo;
  const StaffTasks(this.repo, {super.key});
  @override
  State<StaffTasks> createState() => _StaffTasksState();
}

class _StaffTasksState extends State<StaffTasks> {
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Json>>(
    future: widget.repo.table('operations_tasks'),
    builder: (c, s) {
      if (s.hasError) return EmptyState('تعذر تحميل المهام', '${s.error}');
      if (!s.hasData) return const Center(child: CircularProgressIndicator());
      return ListView(
        padding: SakanLayout.padding(context),
        children: [
          const SectionTitle('مهامي المسندة'),
          for (final task in s.data!)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(task['notes'] ?? ''),
                    Tag(statusLabel(task['status'])),
                    const Space(),
                    for (final next in ['in_progress', 'inspection'])
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: AsyncAction(
                          label: next == 'in_progress'
                              ? 'بدء العمل'
                              : 'إرسال للمشرف للفحص',
                          action: () async {
                            if (widget.repo.demo) {
                              await widget.repo.upsert('operations_tasks', {
                                'id': task['id'],
                                'status': next,
                                'checklist': task['checklist'] ?? {},
                              });
                            } else {
                              await widget.repo.client!.rpc(
                                'update_assigned_task',
                                params: {
                                  'p_task': task['id'],
                                  'p_status': next,
                                  'p_checklist': task['checklist'] ?? {},
                                },
                              );
                            }
                            setState(() {});
                          },
                        ),
                      ),
                  ],
                ),
              ),
            ),
        ],
      );
    },
  );
}
