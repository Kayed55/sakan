import 'package:flutter/material.dart';
import 'core/bootstrap.dart';
import 'customer/app.dart';

Future<void> main() async {
  try {
    runApp(SakanApp(repo: await bootstrap()));
  } catch (e) {
    runApp(FailureApp(e));
  }
}
