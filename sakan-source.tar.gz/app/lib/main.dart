import 'package:flutter_web_plugins/url_strategy.dart';
import 'package:flutter/material.dart';
import 'core/bootstrap.dart';
import 'customer/app.dart';

Future<void> main() async {
  usePathUrlStrategy();
  try {
    runApp(SakanApp(repo: await bootstrap()));
  } catch (e) {
    runApp(FailureApp(e));
  }
}
