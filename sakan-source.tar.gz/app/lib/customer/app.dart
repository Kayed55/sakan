import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/bootstrap.dart';
import '../core/models.dart';
import '../core/repository.dart';
import 'widgets.dart';
import 'design.dart';
import 'auth.dart';
import 'booking.dart';

class SakanApp extends StatefulWidget {
  final SakanRepository repo;
  const SakanApp({required this.repo, super.key});
  @override
  State<SakanApp> createState() => _SakanAppState();
}

class _SakanAppState extends State<SakanApp> {
  bool english = false;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'سكن | Sakan',
    theme: sakanTheme(),
    locale: Locale(english ? 'en' : 'ar'),
    supportedLocales: locales,
    localizationsDelegates: delegates,
    home: LaunchPage(
      repo: widget.repo,
      english: english,
      onLanguage: () => setState(() => english = !english),
    ),
  );
}

class LaunchPage extends StatefulWidget {
  final SakanRepository repo;
  final bool english;
  final VoidCallback onLanguage;
  const LaunchPage({
    required this.repo,
    required this.english,
    required this.onLanguage,
    super.key,
  });
  @override
  State<LaunchPage> createState() => _LaunchPageState();
}

class _LaunchPageState extends State<LaunchPage> {
  bool loading = true;
  late bool onboard;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    onboard = !(widget.repo.prefs.getBool('onboarded') ?? false);
    timer = Timer(const Duration(milliseconds: 650), () {
      if (mounted) setState(() => loading = false);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        backgroundColor: brand,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(light: true, width: 220),
              SizedBox(height: 24),
              Text(
                'إقامتك تبدأ من هنا',
                style: TextStyle(color: Colors.white70, fontSize: 20),
              ),
            ],
          ),
        ),
      );
    }
    if (onboard) {
      return Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 1160),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: BrandMark(),
                    ),
                    EditorialHero(
                      english: widget.english,
                      welcome: true,
                      onStart: () async {
                        await widget.repo.prefs.setBool('onboarded', true);
                        if (mounted) setState(() => onboard = false);
                      },
                    ),
                    const Space(16),
                    SakanDetails(english: widget.english),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
    }

    return HomeShell(
      repo: widget.repo,
      english: widget.english,
      onLanguage: widget.onLanguage,
    );
  }
}

class HomeShell extends StatefulWidget {
  final SakanRepository repo;
  final bool english;
  final VoidCallback onLanguage;
  const HomeShell({
    required this.repo,
    required this.english,
    required this.onLanguage,
    super.key,
  });
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  late Stay stay;
  late Future<List<Unit>> future;
  Set<String> favorites = {};
  bool map = false, onlyFavorites = false;
  String district = 'الكل', kind = 'الكل', sort = 'recommended';
  double maxPrice = 1500;
  String tr(String ar, String en) => widget.english ? en : ar;
  @override
  void initState() {
    super.initState();
    final today = dayOnly(DateTime.now());
    stay = Stay(
      today.add(const Duration(days: 1)),
      today.add(const Duration(days: 3)),
    );
    reload();
  }

  void reload() {
    future = widget.repo.units(stay);
    widget.repo.favorites().then((f) {
      if (mounted) setState(() => favorites = f);
    });
  }

  Future<bool> login() async {
    if (widget.repo.signedIn) return true;
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => LoginPage(widget.repo)),
    );
    if (mounted) setState(reload);
    return widget.repo.signedIn;
  }

  Future<void> dates() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: dayOnly(DateTime.now()),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: DateTimeRange(start: stay.start, end: stay.end),
      helpText: 'اختر تاريخ إقامتك',
    );
    if (r != null) {
      if (r.end.difference(r.start).inDays < 1) {
        if (mounted) showError(context, 'اختر ليلة واحدة على الأقل');
        return;
      }
      setState(() {
        stay = Stay(
          r.start,
          r.end,
          adults: stay.adults,
          children: stay.children,
        );
        reload();
      });
    }
  }

  Future<void> guests() async {
    int adults = stay.adults, children = stay.children;
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SectionTitle('من بيكون معك؟'),
              for (final child in [false, true])
                Row(
                  children: [
                    Expanded(child: Text(child ? 'الأطفال' : 'البالغون')),
                    IconButton(
                      onPressed: () => set(() {
                        if (child && children > 0) children--;
                        if (!child && adults > 1) adults--;
                      }),
                      icon: const Icon(Icons.remove_circle_outline),
                    ),
                    Text('${child ? children : adults}'),
                    IconButton(
                      onPressed: () => set(() {
                        if (adults + children < 12) {
                          if (child) {
                            children++;
                          } else {
                            adults++;
                          }
                        }
                      }),
                      icon: const Icon(Icons.add_circle_outline),
                    ),
                  ],
                ),
              const Space(),
              FilledButton(
                onPressed: () => Navigator.pop(c),
                child: const Text('تأكيد الضيوف'),
              ),
            ],
          ),
        ),
      ),
    );
    setState(() {
      stay = Stay(stay.start, stay.end, adults: adults, children: children);
      reload();
    });
  }

  Future<void> filters() async {
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SectionTitle('إقامة على ذوقك'),
              Text('حد السعر لليلة: ${maxPrice.round()} ر.س'),
              Slider(
                value: maxPrice,
                min: 200,
                max: 2000,
                divisions: 36,
                onChanged: (v) => set(() => maxPrice = v),
              ),
              Wrap(
                spacing: 8,
                children: ['الكل', 'استديو', 'شقة']
                    .map(
                      (v) => ChoiceChip(
                        label: Text(v),
                        selected: kind == v,
                        onSelected: (_) => set(() => kind = v),
                      ),
                    )
                    .toList(),
              ),
              const Space(),
              Wrap(
                spacing: 8,
                children: ['الكل', 'الياسمين', 'الملقا', 'حطين']
                    .map(
                      (v) => ChoiceChip(
                        label: Text(v),
                        selected: district == v,
                        onSelected: (_) => set(() => district = v),
                      ),
                    )
                    .toList(),
              ),
              const Space(),
              FilledButton(
                onPressed: () => Navigator.pop(c),
                child: const Text('عرض النتائج'),
              ),
              const Space(),
            ],
          ),
        ),
      ),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      toolbarHeight: 86,
      titleSpacing: MediaQuery.sizeOf(context).width > 850 ? 42 : 20,
      title: const BrandMark(),
      actions: [
        if (MediaQuery.sizeOf(context).width > 850)
          for (final item in [
            (0, tr('الرئيسية', 'Home')),
            (1, tr('اكتشف الإقامات', 'Explore')),
            (2, tr('حجوزاتي', 'My bookings')),
            (3, tr('حسابي', 'Account')),
          ])
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: TextButton(
                onPressed: () => setState(() => tab = item.$1),
                style: TextButton.styleFrom(
                  backgroundColor: tab == item.$1
                      ? const Color(0xffe9eee8)
                      : Colors.transparent,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 20,
                    vertical: 18,
                  ),
                ),
                child: Text(item.$2),
              ),
            ),

        IconButton(
          tooltip: 'المفضلة',
          onPressed: () async {
            if (await login()) {
              setState(() {
                onlyFavorites = !onlyFavorites;
                tab = 1;
              });
            }
          },
          icon: Icon(onlyFavorites ? Icons.favorite : Icons.favorite_border),
        ),
        IconButton(
          tooltip: 'الإشعارات',
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => NotificationsPage(widget.repo)),
          ),
          icon: const Icon(Icons.notifications_none),
        ),
        const SizedBox(width: 12),
      ],
    ),
    body: Column(
      children: [
        if (widget.repo.demo)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(6),
            color: const Color(0xffeee2ca),
            child: Text(
              tr(
                'نسخة تجريبية • بيانات محلية • لا مدفوعات حقيقية',
                'Demo • local data • no real payments',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        Expanded(
          child: tab < 2
              ? explore()
              : tab == 2
              ? BookingsPage(widget.repo, onLogin: login)
              : profile(),
        ),
      ],
    ),
    bottomNavigationBar: MediaQuery.sizeOf(context).width > 850
        ? null
        : NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: [
              NavigationDestination(
                icon: const Icon(Icons.home_outlined),
                selectedIcon: const Icon(Icons.home),
                label: tr('الرئيسية', 'Home'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.search),
                label: tr('استكشف', 'Explore'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.calendar_month_outlined),
                label: tr('حجوزاتي', 'Bookings'),
              ),
              NavigationDestination(
                icon: const Icon(Icons.person_outline),
                label: tr('حسابي', 'Account'),
              ),
            ],
          ),
  );
  Widget explore() => RefreshIndicator(
    onRefresh: () async {
      setState(reload);
      await future;
    },
    child: ListView(
      padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
      children: [
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1200),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (tab == 0) ...[
                  const Space(12),
                  FutureBuilder<List<Json>>(
                    future: widget.repo.table('home_content'),
                    builder: (context, snapshot) => EditorialHero(
                      english: widget.english,
                      heading:
                          snapshot.data
                                  ?.where(
                                    (v) =>
                                        v['is_active'] == true &&
                                        v['kind'] == 'banner',
                                  )
                                  .firstOrNull?[widget.english
                                  ? 'title_en'
                                  : 'title_ar']
                              as String?,
                    ),
                  ),
                  const Space(22),
                ],
                StaySearch(
                  stay: stay,
                  english: widget.english,
                  dates: dates,
                  guests: guests,
                  search: () => setState(() {
                    tab = 1;
                    reload();
                  }),
                ),
                if (tab == 0) ...[
                  const Space(20),
                  SakanDetails(english: widget.english),
                  const Space(12),
                ],
                SectionTitle(
                  onlyFavorites
                      ? tr('أماكن حفظتها', 'Your favorites')
                      : tab == 0
                      ? tr('مختارة لإقامتك', 'Picked for your stay')
                      : tr('إقامات في الرياض', 'Stays in Riyadh'),
                  subtitle:
                      '${stay.nights} ${tr('ليالٍ', 'nights')} • ${stay.guests} ${tr('ضيوف', 'guests')}',
                ),
                if (tab == 1)
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      OutlinedButton.icon(
                        onPressed: filters,
                        icon: const Icon(Icons.tune),
                        label: const Text('فلترة'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => setState(() => map = !map),
                        icon: Icon(map ? Icons.view_list : Icons.map_outlined),
                        label: Text(map ? 'القائمة' : 'الخريطة'),
                      ),
                      DropdownButton<String>(
                        value: sort,
                        items: const [
                          DropdownMenuItem(
                            value: 'recommended',
                            child: Text('المقترحة'),
                          ),
                          DropdownMenuItem(
                            value: 'price',
                            child: Text('الأقل سعرًا'),
                          ),
                          DropdownMenuItem(
                            value: 'high',
                            child: Text('الأعلى سعرًا'),
                          ),
                        ],
                        onChanged: (v) => setState(() => sort = v!),
                      ),
                    ],
                  ),
                const Space(12),
                FutureBuilder<List<Unit>>(
                  future: future,
                  builder: (c, s) {
                    if (s.hasError) {
                      return Column(
                        children: [
                          EmptyState('تعذر تحميل الوحدات', '${s.error}'),
                          TextButton(
                            onPressed: () => setState(reload),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      );
                    }
                    if (!s.hasData) {
                      return const Padding(
                        padding: EdgeInsets.all(48),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    final units = s.data!
                        .where(
                          (u) =>
                              (!onlyFavorites || favorites.contains(u.id)) &&
                              u.price <= maxPrice * 100 &&
                              (district == 'الكل' || u.district == district) &&
                              (kind == 'الكل' ||
                                  u.kind ==
                                      (kind == 'استديو'
                                          ? 'studio'
                                          : 'apartment')),
                        )
                        .toList();
                    if (sort != 'recommended') {
                      units.sort(
                        (a, b) => sort == 'price'
                            ? a.price.compareTo(b.price)
                            : b.price.compareTo(a.price),
                      );
                    }
                    if (units.isEmpty) {
                      return const EmptyState(
                        'إقامتك القادمة تبدأ هنا',
                        'لا توجد إقامات متاحة حاليًا بهذه الخيارات. جرّب تغيير التواريخ أو عد لاحقًا.',
                      );
                    }
                    if (map) {
                      return SizedBox(
                        height: 450,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: FlutterMap(
                            options: const MapOptions(
                              initialCenter: LatLng(24.80, 46.62),
                              initialZoom: 12,
                            ),
                            children: [
                              TileLayer(
                                urlTemplate:
                                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                userAgentPackageName: 'sa.sakan.app',
                              ),
                              MarkerLayer(
                                markers: units
                                    .where((u) => u.hasMapLocation)
                                    .map(
                                      (u) => Marker(
                                        point: LatLng(u.lat, u.lng),
                                        width: 130,
                                        height: 48,
                                        child: FilledButton(
                                          onPressed: () => detail(u),
                                          child: Text(money(u.price)),
                                        ),
                                      ),
                                    )
                                    .toList(),
                              ),
                              const RichAttributionWidget(
                                attributions: [
                                  TextSourceAttribution(
                                    '© OpenStreetMap contributors',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                    return LayoutBuilder(
                      builder: (c, constraints) {
                        final cols = constraints.maxWidth > 900
                            ? 3
                            : constraints.maxWidth > 600
                            ? 2
                            : 1;
                        return Wrap(
                          spacing: 20,
                          runSpacing: 24,
                          children: units
                              .map(
                                (u) => SizedBox(
                                  width:
                                      (constraints.maxWidth - (cols - 1) * 20) /
                                      cols,
                                  child: unitCard(u),
                                ),
                              )
                              .toList(),
                        );
                      },
                    );
                  },
                ),
                const Space(24),
                Text(
                  tr(
                    'المواقع على الخريطة تقريبية. يظهر العنوان الدقيق للمستحقين فقط.',
                    'Map locations are approximate. Exact access details are released to eligible guests.',
                  ),
                  style: const TextStyle(color: Colors.black45, fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
  Widget unitCard(Unit u) => Card(
    child: InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: () => detail(u),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Stack(
            children: [
              Picture(u.images.firstOrNull),
              Positioned(
                top: 12,
                left: 12,
                child: IconButton.filledTonal(
                  onPressed: () async {
                    if (await login()) {
                      try {
                        await widget.repo.favorite(
                          u.id,
                          !favorites.contains(u.id),
                        );
                        setState(reload);
                      } catch (e) {
                        if (mounted) showError(context, e);
                      }
                    }
                  },
                  icon: Icon(
                    favorites.contains(u.id)
                        ? Icons.favorite
                        : Icons.favorite_border,
                  ),
                ),
              ),
              Positioned(
                bottom: 12,
                right: 12,
                child: Tag(u.kind == 'studio' ? 'استديو' : 'شقة'),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  u.nameFor(widget.english),
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                Text(
                  '${u.district}، الرياض',
                  style: const TextStyle(color: Colors.black54),
                ),
                const Space(10),
                Text(
                  '${u.capacity} ضيوف  •  ${u.data['beds']} أسرّة  •  ${u.data['area']} م²',
                  style: const TextStyle(color: Colors.black54, fontSize: 12),
                ),
                const Divider(height: 26),
                Row(
                  children: [
                    Text(
                      money(u.price),
                      style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        fontSize: 19,
                        color: brand,
                      ),
                    ),
                    Text(tr(' / ليلة', ' / night')),
                    const Spacer(),
                    const Icon(Icons.arrow_forward, size: 19, color: brand),
                  ],
                ),
                FutureBuilder<Json>(
                  future: widget.repo.quote(u, stay),
                  builder: (c, q) => Text(
                    q.hasData
                        ? '${money(q.data!['total'])} ${tr('إجمالي الإقامة', 'total stay')}'
                        : '',
                    style: const TextStyle(color: Colors.black54, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
  void detail(Unit u) =>
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => UnitPage(
            repo: widget.repo,
            unit: u,
            stay: stay,
            english: widget.english,
          ),
        ),
      ).then((_) {
        if (mounted) setState(reload);
      });
  Widget profile() => ListView(
    padding: const EdgeInsets.all(24),
    children: [
      const Icon(Icons.account_circle_outlined, size: 64, color: brand),
      SectionTitle(
        widget.repo.signedIn ? 'أهلاً بك في سكن' : 'إقامتك تبدأ بحسابك',
      ),
      if (!widget.repo.signedIn)
        FilledButton(onPressed: login, child: const Text('تسجيل الجوال')),
      ListTile(
        leading: const Icon(Icons.language),
        title: Text(widget.english ? 'العربية' : 'English'),
        onTap: widget.onLanguage,
      ),
      if (widget.repo.signedIn)
        ListTile(
          leading: const Icon(Icons.edit_outlined),
          title: const Text('بياناتي'),
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ProfilePage(widget.repo)),
          ),
        ),
      ListTile(
        leading: const Icon(Icons.favorite_border),
        title: const Text('المفضلة'),
        onTap: () async {
          if (await login()) {
            setState(() {
              onlyFavorites = true;
              tab = 1;
            });
          }
        },
      ),
      ListTile(
        leading: const Icon(Icons.support_agent),
        title: const Text('الدعم والمساعدة'),
        onTap: () => request('support'),
      ),
      ListTile(
        leading: const Icon(Icons.description_outlined),
        title: const Text('الشروط والخصوصية وسياسة الإلغاء'),
        onTap: () => showDialog(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('سياسات سكن'),
            content: const Text(
              'هذه نسخة تطويرية ولا تستقبل مدفوعات حقيقية قبل تفعيل مزود الدفع واعتماد الشروط والخصوصية وسياسة الإلغاء. طلب الإلغاء يخضع لمراجعة الإدارة، ولا يعني استردادًا تلقائيًا.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(c),
                child: const Text('فهمت'),
              ),
            ],
          ),
        ),
      ),
      if (widget.repo.signedIn) ...[
        ListTile(
          leading: const Icon(Icons.delete_outline),
          title: const Text('طلب حذف الحساب'),
          onTap: () => request('account_deletion'),
        ),
        ListTile(
          leading: const Icon(Icons.logout),
          title: const Text('تسجيل الخروج'),
          onTap: () async {
            await widget.repo.signOut();
            setState(reload);
          },
        ),
      ],
    ],
  );
  Future<void> request(String kind) async {
    if (!await login()) return;
    if (!mounted) return;
    final text = TextEditingController();
    final message = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(kind == 'support' ? 'كيف نساعدك؟' : 'طلب حذف الحساب'),
        content: TextField(
          controller: text,
          decoration: const InputDecoration(labelText: 'رسالتك'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('رجوع'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, text.text),
            child: const Text('إرسال الطلب'),
          ),
        ],
      ),
    );
    text.dispose();
    if (message == null || message.trim().isEmpty) return;
    try {
      await widget.repo.upsert('support_requests', {
        'customer_id': widget.repo.userId,
        'kind': kind,
        'message': message,
        'status': 'open',
      });
      if (mounted) showError(context, 'تم تسجيل الطلب');
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }
}

class UnitPage extends StatelessWidget {
  final SakanRepository repo;
  final Unit unit;
  final Stay stay;
  final bool english;
  const UnitPage({
    required this.repo,
    required this.unit,
    required this.stay,
    required this.english,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(unit.nameFor(english))),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        SizedBox(
          height: 300,
          child: PageView(
            children: (unit.images.isEmpty ? <String?>[null] : unit.images)
                .map(
                  (p) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: Picture(p, height: 300),
                  ),
                )
                .toList(),
          ),
        ),
        const Space(),
        Text(
          unit.nameFor(english),
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        Text('${unit.district}، الرياض'),
        const Space(),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            Tag('${unit.capacity} ضيوف'),
            Tag('${unit.bedrooms} غرف نوم'),
            Tag('${unit.data['bathrooms']} حمام'),
            Tag('${unit.data['area']} م²'),
          ],
        ),
        const SectionTitle('عن المساحة'),
        Text(unit.data[english ? 'description_en' : 'description_ar'] ?? ''),
        const SectionTitle('كل ما تحتاجه'),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: unit.amenities
              .map(
                (a) => Chip(
                  label: Text(a),
                  avatar: const Icon(Icons.check, size: 16),
                ),
              )
              .toList(),
        ),
        const SectionTitle('أوقات الإقامة'),
        const Text('الدخول من 4:00 مساءً • الخروج قبل 12:00 ظهرًا'),
        const SectionTitle('موقعك في الرياض'),
        Text(
          'حي ${unit.district} • الموقع تقريبي، ويظهر العنوان التفصيلي عند استحقاق الدخول.',
        ),
        const SectionTitle('قواعد المكان'),
        Text(
          unit.data['rules_ar'] ??
              'يمنع التدخين والحفلات. يرجى المحافظة على هدوء المكان.',
        ),
        const SectionTitle('آراء الضيوف'),
        FutureBuilder<List<Json>>(
          future: repo.table('reviews'),
          builder: (c, s) {
            final reviews = (s.data ?? [])
                .where((r) => r['unit_id'] == unit.id && r['published'] == true)
                .toList();
            return reviews.isEmpty
                ? const Text('لا توجد تقييمات منشورة بعد.')
                : Column(
                    children: reviews
                        .map(
                          (r) => ListTile(
                            title: Text('★ ${r['rating']} / 5'),
                            subtitle: Text(r['comment']),
                          ),
                        )
                        .toList(),
                  );
          },
        ),
        const Space(30),
      ],
    ),
    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Expanded(
              child: Text(
                '${money(unit.price)} / ليلة',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            FilledButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      CheckoutPage(repo: repo, unit: unit, stay: stay),
                ),
              ),
              child: const Text('احجز الآن'),
            ),
          ],
        ),
      ),
    ),
  );
}

class NotificationsPage extends StatelessWidget {
  final SakanRepository repo;
  const NotificationsPage(this.repo, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإشعارات')),
    body: FutureBuilder<List<Json>>(
      future: repo.signedIn ? repo.table('notifications') : Future.value([]),
      builder: (c, s) {
        if (s.hasError) return EmptyState('تعذر التحميل', '${s.error}');
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.isEmpty) {
          return const EmptyState('كل شيء هادئ', 'ستجد تحديثات حجزك هنا.');
        }
        return ListView(
          children: s.data!.reversed
              .map(
                (n) => ListTile(
                  leading: const Icon(
                    Icons.notifications_active_outlined,
                    color: brand,
                  ),
                  title: Text(n['title']),
                  subtitle: Text(n['body']),
                ),
              )
              .toList(),
        );
      },
    ),
  );
}

class ProfilePage extends StatefulWidget {
  final SakanRepository repo;
  const ProfilePage(this.repo, {super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final name = TextEditingController(), email = TextEditingController();
  @override
  void initState() {
    super.initState();
    widget.repo.table('profiles').then((p) {
      final me = p.where((p) => p['id'] == widget.repo.userId).firstOrNull;
      if (me != null && mounted) {
        name.text = me['full_name'];
        email.text = me['email'] ?? '';
      }
    });
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('بياناتي')),
    body: ListView(
      padding: const EdgeInsets.all(24),
      children: [
        TextField(
          controller: name,
          decoration: const InputDecoration(labelText: 'الاسم'),
        ),
        const Space(),
        TextField(
          controller: email,
          decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
        ),
        const Space(),
        AsyncAction(
          label: 'حفظ',
          action: () async {
            if (name.text.trim().length < 2) throw StateError('الاسم مطلوب');
            if (widget.repo.demo) {
              await widget.repo.upsert('profiles', {
                'id': widget.repo.userId,
                'full_name': name.text,
                'email': email.text,
              });
            } else {
              await widget.repo.client!
                  .from('profiles')
                  .update({'full_name': name.text, 'email': email.text})
                  .eq('id', widget.repo.userId!);
            }
            if (context.mounted) Navigator.pop(context);
          },
        ),
      ],
    ),
  );
}
