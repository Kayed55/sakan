import '../ui/system.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/bootstrap.dart';
import '../core/models.dart';
import '../core/repository.dart';
import 'widgets.dart';
import 'design.dart';
import 'reference.dart';
import 'planned_services.dart';
import '../chat/chat.dart';
import 'auth.dart';
import 'booking.dart';

class SakanApp extends StatefulWidget {
  final SakanRepository repo;
  const SakanApp({required this.repo, super.key});
  @override
  State<SakanApp> createState() => _SakanAppState();
}

class _SakanAppState extends State<SakanApp> {
  bool english = false;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'سكن | SAKN',
    theme: sakanTheme().copyWith(
      scaffoldBackgroundColor: const Color(0xfff6f4ef),
    ),
    builder: sakanViewport,
    locale: Locale(english ? 'en' : 'ar'),
    supportedLocales: locales,
    localizationsDelegates: delegates,
    home: LaunchPage(
      repo: widget.repo,
      english: english,
      onLanguage: () => setState(() => english = !english),
    ),
  );
}

class LaunchPage extends StatefulWidget {
  final SakanRepository repo;
  final bool english;
  final VoidCallback onLanguage;
  const LaunchPage({
    required this.repo,
    required this.english,
    required this.onLanguage,
    super.key,
  });
  @override
  State<LaunchPage> createState() => _LaunchPageState();
}

class _LaunchPageState extends State<LaunchPage> {
  bool loading = true;
  Timer? timer;
  @override
  void initState() {
    super.initState();
    timer = Timer(const Duration(milliseconds: 650), () {
      if (mounted) setState(() => loading = false);
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        backgroundColor: brandCream,
        body: Center(child: BrandMark(width: 220)),
      );
    }
    return HomeShell(
      repo: widget.repo,
      english: widget.english,
      onLanguage: widget.onLanguage,
    );
  }
}

class HomeShell extends StatefulWidget {
  final SakanRepository repo;
  final bool english;
  final VoidCallback onLanguage;
  const HomeShell({
    required this.repo,
    required this.english,
    required this.onLanguage,
    super.key,
  });
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  int accountSection = 0;
  late Stay stay;
  late Future<List<Unit>> future;
  Set<String> favorites = {};
  bool map = false, onlyFavorites = false;
  String district = 'الكل', kind = 'الكل', sort = 'recommended';
  double maxPrice = 1500;
  String tr(String ar, String en) => widget.english ? en : ar;
  @override
  void initState() {
    super.initState();
    final today = dayOnly(DateTime.now());
    stay = Stay(
      today.add(const Duration(days: 1)),
      today.add(const Duration(days: 3)),
    );
    reload();
  }

  void reload() {
    future = widget.repo.units(stay);
    widget.repo.favorites().then((f) {
      if (mounted) setState(() => favorites = f);
    });
  }

  Future<bool> login() async {
    if (widget.repo.signedIn) return true;
    if (MediaQuery.sizeOf(context).width >= 700) {
      await showDialog<bool>(
        context: context,
        builder: (c) => Dialog(
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            width: 480,
            height: MediaQuery.sizeOf(c).height * .85,
            child: LoginPage(widget.repo),
          ),
        ),
      );
    } else {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => LoginPage(widget.repo)),
      );
    }
    if (mounted) setState(reload);
    return widget.repo.signedIn;
  }

  Future<void> supportChat() async {
    if (!await login() || !mounted) return;
    try {
      final bookings = await widget.repo.bookings();
      if (!mounted) return;
      if (bookings.isEmpty) {
        await request('support');
        return;
      }
      final selected = await showModalBottomSheet<Booking>(
        context: context,
        isScrollControlled: true,
        builder: (c) => SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(c).height * .75,
            ),
            child: ListView(
              shrinkWrap: true,
              padding: const EdgeInsets.all(24),
              children: [
                const SectionTitle(
                  'كيف نقدر نساعدك؟',
                  subtitle: 'اختر الحجز لفتح محادثته الخاصة',
                ),
                for (final b in bookings)
                  ListTile(
                    title: Text(b.number),
                    subtitle: Text(
                      '${b.data['unit_name'] ?? ''} · ${statusLabel(b.status)}',
                    ),
                    trailing: const Icon(Icons.chat_bubble_outline),
                    onTap: () => Navigator.pop(c, b),
                  ),
              ],
            ),
          ),
        ),
      );
      if (selected == null || !mounted) return;
      final chat = BookingChat(
        repo: widget.repo,
        bookingId: selected.id,
        bookingNumber: selected.number,
      );
      if (MediaQuery.sizeOf(context).width >= 700) {
        await showDialog<void>(
          context: context,
          builder: (c) => Dialog(
            clipBehavior: Clip.antiAlias,
            child: SizedBox(
              width: 420,
              height: MediaQuery.sizeOf(c).height * .8,
              child: chat,
            ),
          ),
        );
      } else {
        await Navigator.push(context, MaterialPageRoute(builder: (_) => chat));
      }
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }

  void monthlyStays() => setState(() {
    stay = Stay(
      stay.start,
      stay.start.add(const Duration(days: 30)),
      adults: stay.adults,
      children: stay.children,
    );
    onlyFavorites = false;
    tab = 1;
    reload();
  });

  Future<void> dates() async {
    final r = await showDateRangePicker(
      context: context,
      firstDate: dayOnly(DateTime.now()),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      initialDateRange: DateTimeRange(start: stay.start, end: stay.end),
      helpText: 'اختر تاريخ إقامتك',
    );
    if (r != null) {
      if (r.end.difference(r.start).inDays < 1) {
        if (mounted) showError(context, 'اختر ليلة واحدة على الأقل');
        return;
      }
      setState(() {
        stay = Stay(
          r.start,
          r.end,
          adults: stay.adults,
          children: stay.children,
        );
        reload();
      });
    }
  }

  Future<void> guests() async {
    int adults = stay.adults, children = stay.children;
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => SingleChildScrollView(
          child: Padding(
            padding: SakanLayout.padding(context),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const SectionTitle('من بيكون معك؟'),
                for (final child in [false, true])
                  Row(
                    children: [
                      Expanded(child: Text(child ? 'الأطفال' : 'البالغون')),
                      IconButton(
                        tooltip: child
                            ? 'تقليل عدد الأطفال'
                            : 'تقليل عدد البالغين',
                        onPressed: () => set(() {
                          if (child && children > 0) children--;
                          if (!child && adults > 1) adults--;
                        }),
                        icon: const Icon(Icons.remove_circle_outline),
                      ),
                      Text('${child ? children : adults}'),
                      IconButton(
                        tooltip: child
                            ? 'زيادة عدد الأطفال'
                            : 'زيادة عدد البالغين',
                        onPressed: () => set(() {
                          if (adults + children < 12) {
                            if (child) {
                              children++;
                            } else {
                              adults++;
                            }
                          }
                        }),
                        icon: const Icon(Icons.add_circle_outline),
                      ),
                    ],
                  ),
                const Space(),
                FilledButton(
                  onPressed: () => Navigator.pop(c),
                  child: const Text('تأكيد الضيوف'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
    setState(() {
      stay = Stay(stay.start, stay.end, adults: adults, children: children);
      reload();
    });
  }

  Future<void> filters() async {
    await showModalBottomSheet(
      context: context,
      showDragHandle: true,
      useSafeArea: true,
      isScrollControlled: true,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => SingleChildScrollView(
          child: Padding(
            padding: SakanLayout.padding(context),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SectionTitle('إقامة على ذوقك'),
                Text('حد السعر لليلة: ${maxPrice.round()} ر.س'),
                Slider(
                  value: maxPrice,
                  min: 200,
                  max: 2000,
                  divisions: 36,
                  onChanged: (v) => set(() => maxPrice = v),
                ),
                Wrap(
                  spacing: 8,
                  children: ['الكل', 'استديو', 'شقة']
                      .map(
                        (v) => ChoiceChip(
                          label: Text(v),
                          selected: kind == v,
                          onSelected: (_) => set(() => kind = v),
                        ),
                      )
                      .toList(),
                ),
                const Space(),
                Wrap(
                  spacing: 8,
                  children: ['الكل', 'الياسمين', 'الملقا', 'حطين']
                      .map(
                        (v) => ChoiceChip(
                          label: Text(v),
                          selected: district == v,
                          onSelected: (_) => set(() => district = v),
                        ),
                      )
                      .toList(),
                ),
                const Space(),
                FilledButton(
                  onPressed: () => Navigator.pop(c),
                  child: const Text('عرض النتائج'),
                ),
                const Space(),
              ],
            ),
          ),
        ),
      ),
    );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      backgroundColor: canvas,
      elevation: 0,
      shape: const Border(bottom: BorderSide(color: Color(0xffe2ddd3))),
      toolbarHeight: MediaQuery.sizeOf(context).width < 600 ? 68 : 80,
      titleSpacing: MediaQuery.sizeOf(context).width > 1280
          ? (MediaQuery.sizeOf(context).width - 1200) / 2
          : 20,
      title: BrandMark(
        width: MediaQuery.sizeOf(context).width < 600 ? 100 : 120,
      ),
      actions: [
        if (MediaQuery.sizeOf(context).width >= 1200)
          TextButton(
            onPressed: widget.onLanguage,
            child: Text(widget.english ? 'العربية' : 'English'),
          ),
        if (MediaQuery.sizeOf(context).width >= 1000) ...[
          for (final item in [
            (0, tr('الإقامات', 'Stays')),
            (1, tr('الأحياء', 'Areas')),
            (2, tr('حجوزاتي', 'Bookings')),
            (3, tr('حسابي', 'Account')),
          ])
            Container(
              decoration: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: tab == item.$1 ? brandInk : Colors.transparent,
                    width: 2,
                  ),
                ),
              ),
              margin: const EdgeInsets.symmetric(horizontal: 8),
              child: TextButton(
                onPressed: () {
                  if (item.$1 == 1) {
                    filters();
                  } else {
                    setState(() {
                      tab = item.$1;
                      onlyFavorites = false;
                    });
                  }
                },
                child: Text(item.$2),
              ),
            ),
          if (!widget.repo.signedIn)
            OutlinedButton(
              onPressed: login,
              child: Text(tr('تسجيل الدخول', 'Sign in')),
            ),
        ],

        if (MediaQuery.sizeOf(context).width >= 1200)
          TextButton(
            onPressed: monthlyStays,
            child: Text(tr('إقامات شهرية', 'Monthly stays')),
          ),
        if (MediaQuery.sizeOf(context).width < 1000)
          PopupMenuButton<String>(
            tooltip: tr('القائمة', 'Menu'),
            icon: const Icon(Icons.menu),
            onSelected: (v) {
              if (v == 'monthly') {
                monthlyStays();
              } else if (v == 'areas') {
                filters();
              } else if (v == 'help') {
                supportChat();
              } else {
                widget.onLanguage();
              }
            },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'areas', child: Text('الأحياء')),
              const PopupMenuItem(
                value: 'monthly',
                child: Text('الإقامات الشهرية'),
              ),
              const PopupMenuItem(value: 'help', child: Text('المساعدة')),
              PopupMenuItem(
                value: 'language',
                child: Text(widget.english ? 'العربية' : 'English'),
              ),
            ],
          ),
        IconButton(
          tooltip: 'المفضلة',
          onPressed: () async {
            if (await login()) {
              setState(() {
                onlyFavorites = !onlyFavorites;
                tab = 1;
              });
            }
          },
          icon: Icon(onlyFavorites ? Icons.favorite : Icons.favorite_border),
        ),
        IconButton(
          tooltip: 'الإشعارات',
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => NotificationsPage(widget.repo)),
          ),
          icon: const Icon(Icons.notifications_none),
        ),
        SizedBox(
          width: MediaQuery.sizeOf(context).width > 1280
              ? (MediaQuery.sizeOf(context).width - 1200) / 2
              : 12,
        ),
      ],
    ),
    floatingActionButton: MediaQuery.sizeOf(context).width < 600
        ? FloatingActionButton.small(
            onPressed: supportChat,
            tooltip: tr('تواصل مع الدعم', 'Contact support'),
            child: const Icon(Icons.chat_bubble_outline),
          )
        : FloatingActionButton.extended(
            onPressed: supportChat,
            icon: const Icon(Icons.chat_bubble_outline),
            label: Text(tr('تواصل مع الدعم', 'Contact support')),
          ),
    body: Column(
      children: [
        if (widget.repo.demo)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(6),
            color: const Color(0xfff2e8d0),
            child: Text(
              tr(
                'نسخة تجريبية • بيانات محلية • لا مدفوعات حقيقية',
                'Demo • local data • no real payments',
              ),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 12),
            ),
          ),
        Expanded(
          child: tab < 2
              ? explore()
              : tab == 2
              ? BookingsPage(widget.repo, onLogin: login)
              : profile(),
        ),
      ],
    ),
    bottomNavigationBar: MediaQuery.sizeOf(context).width >= 1000
        ? null
        : DecoratedBox(
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Color(0xffe2ddd3))),
            ),
            child: NavigationBar(
              selectedIndex: tab,
              onDestinationSelected: (i) => setState(() {
                tab = i;
                onlyFavorites = false;
              }),
              destinations: [
                NavigationDestination(
                  icon: const Icon(Icons.home_outlined),
                  selectedIcon: const Icon(Icons.home),
                  label: tr('الرئيسية', 'Home'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.search),
                  label: tr('استكشف', 'Explore'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.calendar_month_outlined),
                  label: tr('حجوزاتي', 'Bookings'),
                ),
                NavigationDestination(
                  icon: const Icon(Icons.person_outline),
                  label: tr('حسابي', 'Account'),
                ),
              ],
            ),
          ),
  );
  Widget explore() => RefreshIndicator(
    onRefresh: () async {
      setState(reload);
      await future;
    },
    child: ListView(
      padding: EdgeInsets.fromLTRB(
        SakanLayout.gutter(context),
        8,
        SakanLayout.gutter(context),
        32,
      ),
      children: [
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1200),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (tab == 0) ...[
                  const Space(12),
                  FutureBuilder<List<Json>>(
                    future: widget.repo.table('home_content'),
                    builder: (context, snapshot) => EditorialHero(
                      english: widget.english,
                      heading:
                          snapshot.data
                                  ?.where(
                                    (v) =>
                                        v['is_active'] == true &&
                                        v['kind'] == 'banner',
                                  )
                                  .firstOrNull?[widget.english
                                  ? 'title_en'
                                  : 'title_ar']
                              as String?,
                    ),
                  ),
                  const Space(16),
                ],
                if (!onlyFavorites)
                  StaySearch(
                    stay: stay,
                    english: widget.english,
                    dates: dates,
                    guests: guests,
                    search: () => setState(() {
                      tab = 1;
                      reload();
                    }),
                  ),
                if (tab == 0) ...[
                  const Space(24),
                  const Divider(),
                  const Space(16),
                ],
                if (tab == 0) ...[
                  const SectionTitle(
                    'عروض الإقامة',
                    subtitle: 'تابع العروض التي يعلنها فريق سكن هنا.',
                  ),
                  const ReferencePanel(
                    child: Row(
                      children: [
                        Icon(
                          Icons.local_offer_outlined,
                          color: Color(0xffb5543a),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Text(
                            'لا توجد عروض معلنة حاليًا. استعرض الإقامات المتاحة لتواريخك أدناه.',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Space(36),
                ],
                SectionTitle(
                  onlyFavorites
                      ? tr('أماكن حفظتها', 'Your favorites')
                      : tab == 0
                      ? tr('متاح لتواريخك', 'Available for your dates')
                      : tr('إقامات في الرياض', 'Stays in Riyadh'),
                  subtitle:
                      '${stay.nights} ${tr('ليالٍ', 'nights')} • ${stay.guests} ${tr('ضيوف', 'guests')}',
                ),
                if (tab < 2)
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      OutlinedButton.icon(
                        onPressed: filters,
                        icon: const Icon(Icons.tune),
                        label: const Text('فلترة'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () => setState(() => map = !map),
                        icon: Icon(map ? Icons.view_list : Icons.map_outlined),
                        label: Text(map ? 'القائمة' : 'الخريطة'),
                      ),
                      DropdownButton<String>(
                        value: sort,
                        items: const [
                          DropdownMenuItem(
                            value: 'recommended',
                            child: Text('المقترحة'),
                          ),
                          DropdownMenuItem(
                            value: 'price',
                            child: Text('الأقل سعرًا'),
                          ),
                          DropdownMenuItem(
                            value: 'high',
                            child: Text('الأعلى سعرًا'),
                          ),
                        ],
                        onChanged: (v) => setState(() => sort = v!),
                      ),
                    ],
                  ),
                const Space(12),
                if (!onlyFavorites)
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    children: [
                      for (final value in ['الكل', 'استديو', 'شقة'])
                        ChoiceChip(
                          label: Text(value),
                          selected: kind == value,
                          onSelected: (_) => setState(() => kind = value),
                        ),
                    ],
                  ),
                const Space(20),
                FutureBuilder<List<Unit>>(
                  future: future,
                  builder: (c, s) {
                    if (s.hasError) {
                      return Column(
                        children: [
                          EmptyState('تعذر تحميل الوحدات', '${s.error}'),
                          TextButton(
                            onPressed: () => setState(reload),
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      );
                    }
                    if (!s.hasData) {
                      return const Padding(
                        padding: EdgeInsets.all(48),
                        child: Center(child: CircularProgressIndicator()),
                      );
                    }
                    final units = s.data!
                        .where(
                          (u) =>
                              (!onlyFavorites || favorites.contains(u.id)) &&
                              u.price <= maxPrice * 100 &&
                              (district == 'الكل' || u.district == district) &&
                              (kind == 'الكل' ||
                                  u.kind ==
                                      (kind == 'استديو'
                                          ? 'studio'
                                          : 'apartment')),
                        )
                        .toList();
                    if (sort != 'recommended') {
                      units.sort(
                        (a, b) => sort == 'price'
                            ? a.price.compareTo(b.price)
                            : b.price.compareTo(a.price),
                      );
                    }
                    if (units.isEmpty && onlyFavorites) {
                      return Column(
                        children: [
                          const EmptyState(
                            'قائمتك فارغة',
                            'اضغط على القلب في أي إقامة لحفظها هنا.',
                          ),
                          FilledButton(
                            onPressed: () => setState(() {
                              onlyFavorites = false;
                              tab = 1;
                            }),
                            child: const Text('تصفح الإقامات'),
                          ),
                        ],
                      );
                    }
                    if (units.isEmpty) {
                      return const EmptyState(
                        'إقامتك القادمة تبدأ هنا',
                        'لا توجد إقامات متاحة حاليًا بهذه الخيارات. جرّب تغيير التواريخ أو عد لاحقًا.',
                      );
                    }
                    if (map) {
                      return SizedBox(
                        height: 450,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(20),
                          child: FlutterMap(
                            options: const MapOptions(
                              initialCenter: LatLng(24.80, 46.62),
                              initialZoom: 12,
                            ),
                            children: [
                              TileLayer(
                                urlTemplate:
                                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                                userAgentPackageName: 'sa.sakan.app',
                              ),
                              MarkerLayer(
                                markers: units
                                    .where((u) => u.hasMapLocation)
                                    .map(
                                      (u) => Marker(
                                        point: LatLng(u.lat, u.lng),
                                        width: 130,
                                        height: 48,
                                        child: FilledButton(
                                          onPressed: () => detail(u),
                                          child: Text(money(u.price)),
                                        ),
                                      ),
                                    )
                                    .toList(),
                              ),
                              const RichAttributionWidget(
                                attributions: [
                                  TextSourceAttribution(
                                    '© OpenStreetMap contributors',
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    }
                    if (tab == 1 && !onlyFavorites) {
                      return LayoutBuilder(
                        builder: (context, box) {
                          final results = Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                '${units.length} إقامة متاحة',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const Space(20),
                              for (final u in units)
                                Padding(
                                  padding: const EdgeInsets.only(bottom: 24),
                                  child: searchRow(u),
                                ),
                            ],
                          );
                          if (box.maxWidth < 900) return results;
                          return Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                width: 230,
                                child: ReferencePanel(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      const Text(
                                        'خصّص إقامتك',
                                        style: TextStyle(
                                          fontSize: 22,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const Space(24),
                                      const Text('نوع الوحدة'),
                                      for (final k in ['الكل', 'استديو', 'شقة'])
                                        CheckboxListTile(
                                          contentPadding: EdgeInsets.zero,
                                          title: Text(k),
                                          value: kind == k,
                                          onChanged: (_) =>
                                              setState(() => kind = k),
                                        ),
                                      const Divider(height: 32),
                                      const Text('الحد الأعلى للسعر / ليلة'),
                                      Text(money((maxPrice * 100).round())),
                                      Slider(
                                        value: maxPrice.clamp(200, 2000),
                                        min: 200,
                                        max: 2000,
                                        onChanged: (v) =>
                                            setState(() => maxPrice = v),
                                      ),
                                      const Divider(height: 32),
                                      const Text('الحي'),
                                      const Space(8),
                                      DropdownButton<String>(
                                        isExpanded: true,
                                        value: district,
                                        items:
                                            {
                                                  ...s.data!.map(
                                                    (u) => u.district,
                                                  ),
                                                  'الكل',
                                                  district,
                                                }
                                                .map(
                                                  (d) => DropdownMenuItem(
                                                    value: d,
                                                    child: Text(
                                                      d,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                )
                                                .toList(),
                                        onChanged: (v) =>
                                            setState(() => district = v!),
                                      ),
                                      const Space(20),
                                      TextButton(
                                        onPressed: () => setState(() {
                                          kind = 'الكل';
                                          district = 'الكل';
                                          maxPrice = 1500;
                                        }),
                                        child: const Text('إعادة ضبط الفلاتر'),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(width: 32),
                              Expanded(child: results),
                            ],
                          );
                        },
                      );
                    }
                    return LayoutBuilder(
                      builder: (c, constraints) {
                        final cols = constraints.maxWidth > 900
                            ? 3
                            : constraints.maxWidth > 600
                            ? 2
                            : 1;
                        return Wrap(
                          spacing: 20,
                          runSpacing: 24,
                          children: units
                              .map(
                                (u) => SizedBox(
                                  width:
                                      (constraints.maxWidth - (cols - 1) * 20) /
                                      cols,
                                  child: unitCard(u),
                                ),
                              )
                              .toList(),
                        );
                      },
                    );
                  },
                ),
                const Space(24),
                Text(
                  tr(
                    'المواقع على الخريطة تقريبية. يظهر العنوان الدقيق للمستحقين فقط.',
                    'Map locations are approximate. Exact access details are released to eligible guests.',
                  ),
                  style: const TextStyle(
                    color: Color(0xff5b6672),
                    fontSize: 12,
                  ),
                ),
                const Space(40),
                if (tab == 0) ...[
                  FutureBuilder<List<Unit>>(
                    future: future,
                    builder: (context, snapshot) {
                      return NeighbourhoodCards(
                        units: snapshot.data ?? [],
                        english: widget.english,
                        onSelect: (value) => setState(() {
                          district = value;
                          tab = 1;
                        }),
                      );
                    },
                  ),
                  SakanDetails(english: widget.english),
                  const Space(48),
                  PocketSection(
                    english: widget.english,
                    onBookings: () => setState(() => tab = 2),
                  ),
                  const Space(48),
                ],
                SakanFooter(
                  english: widget.english,
                  onExplore: () => setState(() => tab = 1),
                  onBookings: () => setState(() => tab = 2),
                  onAccount: () => setState(() => tab = 3),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
  );
  Widget searchRow(Unit u) => LayoutBuilder(
    builder: (context, box) {
      if (box.maxWidth < 560) return unitCard(u);
      return Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => detail(u),
          child: Row(
            children: [
              SizedBox(
                width: 220,
                child: Picture(u.images.firstOrNull, height: 220),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${u.kind == 'studio' ? 'استديو' : 'شقة'} · ${u.district}',
                        style: const TextStyle(color: Color(0xff5b6672)),
                      ),
                      const Space(8),
                      Text(
                        u.nameFor(widget.english),
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Space(12),
                      Text('${u.capacity} ضيوف · ${u.bedrooms} غرف نوم'),
                      const Divider(height: 32),
                      Text(
                        '${money(u.price)} / ليلة',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const Space(8),
                      const Text(
                        'عرض تفاصيل الإقامة ←',
                        style: TextStyle(color: brand),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
  Widget unitCard(Unit u) => Card(
    color: Colors.transparent,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    clipBehavior: Clip.antiAlias,
    child: InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: () => detail(u),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Stack(
            children: [
              Padding(
                padding: EdgeInsets.zero,
                child: Picture(u.images.firstOrNull, height: 230),
              ),
              Positioned(
                top: 18,
                left: 18,
                child: IconButton.filledTonal(
                  tooltip: favorites.contains(u.id)
                      ? 'إزالة من المفضلة'
                      : 'إضافة للمفضلة',
                  onPressed: () async {
                    if (await login()) {
                      try {
                        await widget.repo.favorite(
                          u.id,
                          !favorites.contains(u.id),
                        );
                        setState(reload);
                      } catch (e) {
                        if (mounted) showError(context, e);
                      }
                    }
                  },
                  icon: Icon(
                    favorites.contains(u.id)
                        ? Icons.favorite
                        : Icons.favorite_border,
                  ),
                ),
              ),
              Positioned(
                bottom: 20,
                right: 20,
                child: Tag(u.kind == 'studio' ? 'استديو' : 'شقة'),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  u.nameFor(widget.english),
                  style: const TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w600,
                    height: 1.55,
                  ),
                ),
                const Space(6),
                Text(
                  '${u.district}، الرياض',
                  style: const TextStyle(color: Color(0xff5b6672)),
                ),
                const Space(10),
                Text(
                  '${u.capacity} ضيوف  •  ${u.data['beds']} أسرّة  •  ${u.data['area']} م²',
                  style: const TextStyle(
                    color: Color(0xff5b6672),
                    fontSize: 12,
                  ),
                ),
                const Divider(height: 26),
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${money(u.price)}${tr(' / ليلة', ' / night')}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 19,
                          color: brand,
                        ),
                      ),
                    ),
                    const Icon(Icons.arrow_forward, size: 19, color: brand),
                  ],
                ),
                FutureBuilder<Json>(
                  future: widget.repo.quote(u, stay),
                  builder: (c, q) => Text(
                    q.hasData
                        ? '${money(q.data!['total'])} ${tr('إجمالي الإقامة', 'total stay')}'
                        : '',
                    style: const TextStyle(
                      color: Color(0xff5b6672),
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ),
  );
  void detail(Unit u) =>
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => UnitPage(
            repo: widget.repo,
            unit: u,
            stay: stay,
            english: widget.english,
          ),
        ),
      ).then((_) {
        if (mounted) setState(reload);
      });
  Widget profile() => PageList(
    maxWidth: 1200,
    padding: SakanLayout.padding(context),
    children: [
      const SectionTitle('حسابي', subtitle: 'بياناتك وتفضيلاتك، في مكان واحد.'),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final item in [
            (0, 'البيانات الشخصية'),
            (1, 'طرق الدفع'),
            (2, 'تفضيلات الإشعارات'),
            (3, 'الفواتير'),
          ])
            ChoiceChip(
              label: Text(item.$2),
              selected: accountSection == item.$1,
              onSelected: (_) => setState(() => accountSection = item.$1),
            ),
        ],
      ),
      const Space(24),
      ReferenceColumns(
        main: accountSection == 1
            ? const FuturePaymentsPanel()
            : accountSection == 2
            ? const ReferencePanel(child: FuturePreferencesPanel())
            : accountSection == 3
            ? const FutureInvoicesPanel()
            : ReferencePanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const NafathPanel(),
                    const Space(24),
                    const Icon(
                      Icons.account_circle_outlined,
                      size: 64,
                      color: brand,
                    ),
                    SectionTitle(
                      widget.repo.signedIn
                          ? 'أهلاً بك في سكن'
                          : 'إقامتك تبدأ بحسابك',
                    ),
                    if (!widget.repo.signedIn)
                      FilledButton(
                        onPressed: login,
                        child: const Text('تسجيل الجوال'),
                      ),
                    ListTile(
                      leading: const Icon(Icons.language),
                      title: Text(widget.english ? 'العربية' : 'English'),
                      onTap: widget.onLanguage,
                    ),
                    if (widget.repo.signedIn)
                      ListTile(
                        leading: const Icon(Icons.edit_outlined),
                        title: const Text('بياناتي'),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ProfilePage(widget.repo),
                          ),
                        ),
                      ),
                    ListTile(
                      leading: const Icon(Icons.favorite_border),
                      title: const Text('المفضلة'),
                      onTap: () async {
                        if (await login()) {
                          setState(() {
                            onlyFavorites = true;
                            tab = 1;
                          });
                        }
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.support_agent),
                      title: const Text('الدعم والمساعدة'),
                      onTap: () => request('support'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.description_outlined),
                      title: const Text('الشروط والخصوصية وسياسة الإلغاء'),
                      onTap: () => showDialog(
                        context: context,
                        builder: (c) => AlertDialog(
                          scrollable: true,
                          title: const Text('سياسات سكن'),
                          content: const Text(
                            'هذه نسخة تطويرية ولا تستقبل مدفوعات حقيقية قبل تفعيل مزود الدفع واعتماد الشروط والخصوصية وسياسة الإلغاء. طلب الإلغاء يخضع لمراجعة الإدارة، ولا يعني استردادًا تلقائيًا.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(c),
                              child: const Text('فهمت'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (widget.repo.signedIn) ...[
                      ListTile(
                        leading: const Icon(Icons.delete_outline),
                        title: const Text('طلب حذف الحساب'),
                        onTap: () => request('account_deletion'),
                      ),
                      ListTile(
                        leading: const Icon(Icons.logout),
                        title: const Text('تسجيل الخروج'),
                        onTap: () async {
                          await widget.repo.signOut();
                          setState(reload);
                        },
                      ),
                    ],
                  ],
                ),
              ),
        aside: ReferencePanel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'إدارة حسابك',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const Space(20),
              for (final item in [
                (0, 'البيانات الشخصية', Icons.person_outline),
                (1, 'طرق الدفع', Icons.credit_card),
                (2, 'تفضيلات الإشعارات', Icons.notifications_outlined),
                (3, 'الفواتير', Icons.receipt_long_outlined),
              ])
                ListTile(
                  selected: accountSection == item.$1,
                  selectedTileColor: const Color(0xffe6edf4),
                  leading: Icon(item.$3),
                  title: Text(item.$2),
                  onTap: () => setState(() => accountSection = item.$1),
                ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.calendar_month_outlined),
                title: const Text('حجوزاتي'),
                onTap: () => setState(() => tab = 2),
              ),
              ListTile(
                leading: const Icon(Icons.notifications_none),
                title: const Text('الإشعارات'),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => NotificationsPage(widget.repo),
                  ),
                ),
              ),
              const Divider(height: 32),
              const Text(
                'الهوية وطرق الدفع',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Space(12),
              const Text(
                'لا توجد خدمة نفاذ أو بطاقات محفوظة مفعّلة حاليًا. تظهر خيارات الدفع المتاحة أثناء إتمام الحجز.',
                style: TextStyle(color: Color(0xff5b6672), height: 1.8),
              ),
            ],
          ),
        ),
      ),
    ],
  );
  Future<void> request(String kind) async {
    if (!await login()) return;
    if (!mounted) return;
    final text = TextEditingController();
    final message = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        scrollable: true,
        title: Text(kind == 'support' ? 'كيف نساعدك؟' : 'طلب حذف الحساب'),
        content: TextField(
          controller: text,
          decoration: const InputDecoration(labelText: 'رسالتك'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(c),
            child: const Text('رجوع'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(c, text.text),
            child: const Text('إرسال الطلب'),
          ),
        ],
      ),
    );
    text.dispose();
    if (message == null || message.trim().isEmpty) return;
    try {
      await widget.repo.upsert('support_requests', {
        'customer_id': widget.repo.userId,
        'kind': kind,
        'message': message,
        'status': 'open',
      });
      if (mounted) showError(context, 'تم تسجيل الطلب');
    } catch (e) {
      if (mounted) showError(context, e);
    }
  }
}

class UnitPage extends StatelessWidget {
  final SakanRepository repo;
  final Unit unit;
  final Stay stay;
  final bool english;
  const UnitPage({
    required this.repo,
    required this.unit,
    required this.stay,
    required this.english,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(unit.nameFor(english))),
    body: PageList(
      padding: SakanLayout.padding(context),
      children: [
        Text(
          'الإقامات / ${unit.district} / ${unit.nameFor(english)}',
          style: const TextStyle(color: Color(0xff5b6672)),
        ),
        const Space(24),
        UnitGallery(unit.images),
        const Space(32),
        ReferenceColumns(
          main: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Space(),
              Text(
                unit.nameFor(english),
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              Text('${unit.district}، الرياض'),
              const Space(),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  Tag('${unit.capacity} ضيوف'),
                  Tag('${unit.bedrooms} غرف نوم'),
                  Tag('${unit.data['bathrooms']} حمام'),
                  Tag('${unit.data['area']} م²'),
                ],
              ),
              const SectionTitle('عن المساحة'),
              Text(
                unit.data[english ? 'description_en' : 'description_ar'] ?? '',
              ),
              const SectionTitle('كل ما تحتاجه'),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: unit.amenities
                    .map(
                      (a) => Chip(
                        label: Text(a),
                        avatar: const Icon(Icons.check, size: 16),
                      ),
                    )
                    .toList(),
              ),
              const SectionTitle('أوقات الإقامة'),
              const Text('الدخول من 4:00 مساءً • الخروج قبل 12:00 ظهرًا'),
              const SectionTitle('موقعك في الرياض'),
              Text(
                'حي ${unit.district} • الموقع تقريبي، ويظهر العنوان التفصيلي عند استحقاق الدخول.',
              ),
              const Space(16),
              if (unit.hasMapLocation)
                SizedBox(
                  height: 300,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: FlutterMap(
                      options: MapOptions(
                        initialCenter: LatLng(unit.lat, unit.lng),
                        initialZoom: 13,
                      ),
                      children: [
                        TileLayer(
                          urlTemplate:
                              'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                          userAgentPackageName: 'sa.sakan.app',
                        ),
                        MarkerLayer(
                          markers: [
                            Marker(
                              point: LatLng(unit.lat, unit.lng),
                              child: const Icon(
                                Icons.location_on,
                                color: brand,
                                size: 40,
                              ),
                            ),
                          ],
                        ),
                        const RichAttributionWidget(
                          attributions: [
                            TextSourceAttribution(
                              '© OpenStreetMap contributors',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              const SectionTitle('قواعد المكان'),
              Text(
                unit.data['rules_ar'] ??
                    'يمنع التدخين والحفلات. يرجى المحافظة على هدوء المكان.',
              ),
              const SectionTitle('آراء الضيوف'),
              FutureBuilder<List<Json>>(
                future: repo.table('reviews'),
                builder: (c, s) {
                  final reviews = (s.data ?? [])
                      .where(
                        (r) =>
                            r['unit_id'] == unit.id && r['published'] == true,
                      )
                      .toList();
                  return reviews.isEmpty
                      ? const Text('لا توجد تقييمات منشورة بعد.')
                      : Column(
                          children: reviews
                              .map(
                                (r) => ListTile(
                                  title: Text('★ ${r['rating']} / 5'),
                                  subtitle: Text(r['comment']),
                                ),
                              )
                              .toList(),
                        );
                },
              ),
              const Space(30),
            ],
          ),
          aside: ReferencePanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  '${money(unit.price)} / ليلة',
                  style: const TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Space(24),
                const Text(
                  'الوصول — المغادرة',
                  style: TextStyle(color: Color(0xff5b6672)),
                ),
                Text('${dateKey(stay.start)} ← ${dateKey(stay.end)}'),
                const Divider(height: 32),
                Text('${stay.guests} ضيوف · ${stay.nights} ليالٍ'),
                const Space(24),
                FilledButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          CheckoutPage(repo: repo, unit: unit, stay: stay),
                    ),
                  ),
                  child: const Text('احجز الآن'),
                ),
                const Space(16),
                const Text(
                  'راجع السعر النهائي والرسوم في الخطوة التالية. لن يتم خصم مبلغ قبل إتمام الدفع.',
                  style: TextStyle(fontSize: 12, color: Color(0xff5b6672)),
                ),
              ],
            ),
          ),
        ),
      ],
    ),
    bottomNavigationBar: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Expanded(
              child: Text(
                '${money(unit.price)} / ليلة',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            FilledButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      CheckoutPage(repo: repo, unit: unit, stay: stay),
                ),
              ),
              child: const Text('احجز الآن'),
            ),
          ],
        ),
      ),
    ),
  );
}

class NotificationsPage extends StatelessWidget {
  final SakanRepository repo;
  const NotificationsPage(this.repo, {super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الإشعارات')),
    body: FutureBuilder<List<Json>>(
      future: repo.signedIn ? repo.table('notifications') : Future.value([]),
      builder: (c, s) {
        if (s.hasError) return EmptyState('تعذر التحميل', '${s.error}');
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.isEmpty) {
          return const PageList(
            maxWidth: SakanLayout.form,
            children: [EmptyState('كل شيء هادئ', 'ستجد تحديثات حجزك هنا.')],
          );
        }
        return PageList(
          maxWidth: SakanLayout.form,
          children: s.data!.reversed
              .map(
                (n) => ListTile(
                  leading: const Icon(
                    Icons.notifications_active_outlined,
                    color: brand,
                  ),
                  title: Text(n['title']),
                  subtitle: Text(n['body']),
                ),
              )
              .toList(),
        );
      },
    ),
  );
}

class ProfilePage extends StatefulWidget {
  final SakanRepository repo;
  const ProfilePage(this.repo, {super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final name = TextEditingController(), email = TextEditingController();
  @override
  void initState() {
    super.initState();
    widget.repo.table('profiles').then((p) {
      final me = p.where((p) => p['id'] == widget.repo.userId).firstOrNull;
      if (me != null && mounted) {
        name.text = me['full_name'];
        email.text = me['email'] ?? '';
      }
    });
  }

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('بياناتي')),
    body: PageList(
      maxWidth: SakanLayout.form,
      padding: SakanLayout.padding(context),
      children: [
        TextField(
          controller: name,
          decoration: const InputDecoration(labelText: 'الاسم'),
        ),
        const Space(),
        TextField(
          controller: email,
          decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
        ),
        const Space(),
        AsyncAction(
          label: 'حفظ',
          action: () async {
            if (name.text.trim().length < 2) throw StateError('الاسم مطلوب');
            if (widget.repo.demo) {
              await widget.repo.upsert('profiles', {
                'id': widget.repo.userId,
                'full_name': name.text,
                'email': email.text,
              });
            } else {
              await widget.repo.client!
                  .from('profiles')
                  .update({'full_name': name.text, 'email': email.text})
                  .eq('id', widget.repo.userId!);
            }
            if (context.mounted) Navigator.pop(context);
          },
        ),
      ],
    ),
  );
}
