import 'package:flutter/material.dart';
import '../core/models.dart';
import 'reference.dart';
import 'widgets.dart';

/// Presentation-only integration states. No tokens, identity numbers, or card
/// details are collected until a real provider supplies the corresponding flow.
enum IdentityStage { unavailable, entry, pending, verified, expired, failed }

class IdentityPresentation {
  final IdentityStage stage;
  final String? challenge, maskedId, error;
  final Map<String, String> verifiedFields;
  const IdentityPresentation({
    this.stage = IdentityStage.unavailable,
    this.challenge,
    this.maskedId,
    this.error,
    this.verifiedFields = const {},
  });
}

class NafathPanel extends StatefulWidget {
  final IdentityPresentation presentation;
  const NafathPanel({
    this.presentation = const IdentityPresentation(),
    super.key,
  });
  @override
  State<NafathPanel> createState() => _NafathPanelState();
}

class _NafathPanelState extends State<NafathPanel> {
  bool expanded = false;
  @override
  Widget build(BuildContext context) {
    final data = widget.presentation;
    return ReferencePanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              const Icon(Icons.verified_user_outlined, color: brand),
              const Text(
                'توثيق الهوية عبر نفاذ',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              if (data.stage == IdentityStage.unavailable) const Tag('قريبًا'),
            ],
          ),
          const Space(12),
          if (data.stage == IdentityStage.unavailable ||
              data.stage == IdentityStage.entry) ...[
            const Text(
              'سيتيح الربط توثيق هويتك من خلال النفاذ الوطني الموحد. الخدمة غير مفعّلة حاليًا ولا يُرسل أي طلب تحقق.',
              style: TextStyle(color: Color(0xff5b6670), height: 1.8),
            ),
            const Space(16),
            if (!expanded)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: OutlinedButton(
                  onPressed: () => setState(() => expanded = true),
                  child: const Text('استعراض خطوات التحقق'),
                ),
              ),
            if (expanded) ...[
              const TextField(
                enabled: false,
                decoration: InputDecoration(
                  labelText: 'رقم الهوية الوطنية أو الإقامة',
                  hintText: 'يُتاح الإدخال بعد تفعيل الخدمة',
                  prefixIcon: Icon(Icons.badge_outlined),
                ),
              ),
              const Space(12),
              const Text(
                '١ أدخل رقم هويتك بعد التفعيل\n٢ وافق على الطلب داخل تطبيق نفاذ\n٣ تظهر بياناتك الموثقة في حسابك',
                style: TextStyle(height: 2),
              ),
              const Space(16),
              const FilledButton(
                onPressed: null,
                child: Text('إرسال طلب نفاذ — قريبًا'),
              ),
              TextButton(
                onPressed: () => setState(() => expanded = false),
                child: const Text('إغلاق'),
              ),
            ],
          ],
          if (data.stage == IdentityStage.pending) ...[
            Text(
              data.challenge ?? '—',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 60, fontWeight: FontWeight.bold),
            ),
            const Text(
              'افتح تطبيق نفاذ واختر الرقم الظاهر لإكمال طلب التحقق.',
              textAlign: TextAlign.center,
            ),
            const Space(16),
            const LinearProgressIndicator(),
            const Space(12),
            const Text('بانتظار تأكيد مزوّد التحقق'),
          ],
          if (data.stage == IdentityStage.verified) ...[
            const ListTile(
              leading: Icon(Icons.verified, color: brand),
              title: Text('تم التحقق من الهوية'),
              subtitle: Text('البيانات الموثقة مقفلة ولا يمكن تعديلها'),
            ),
            if (data.maskedId != null) Text(data.maskedId!),
            for (final field in data.verifiedFields.entries)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Wrap(
                  spacing: 24,
                  children: [
                    Text(field.key),
                    Text(
                      field.value,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
          ],
          if (data.stage == IdentityStage.expired ||
              data.stage == IdentityStage.failed)
            Text(
              data.error ??
                  (data.stage == IdentityStage.expired
                      ? 'انتهت صلاحية طلب التحقق. ابدأ طلبًا جديدًا من الخدمة بعد تفعيلها.'
                      : 'تعذر إكمال التحقق. حاول لاحقًا.'),
              style: const TextStyle(color: Color(0xffb5543a)),
            ),
        ],
      ),
    );
  }
}

class FuturePaymentsPanel extends StatelessWidget {
  const FuturePaymentsPanel({super.key});
  void cardForm(BuildContext context) => showDialog<void>(
    context: context,
    builder: (c) => AlertDialog(
      scrollable: true,
      title: const Text('إضافة بطاقة'),
      content: const SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Tag('قريبًا · الخدمة غير مفعّلة'),
            Space(16),
            Text(
              'سيتم إدخال بيانات البطاقة داخل نافذة بوابة الدفع الآمنة بعد الربط. لا تدخل بيانات بطاقة حقيقية الآن.',
            ),
            Space(20),
            TextField(
              enabled: false,
              decoration: InputDecoration(labelText: 'اسم حامل البطاقة'),
            ),
            Space(16),
            TextField(
              enabled: false,
              decoration: InputDecoration(
                labelText: 'رقم البطاقة',
                prefixIcon: Icon(Icons.credit_card),
              ),
            ),
            Space(16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    enabled: false,
                    decoration: InputDecoration(labelText: 'MM / YY'),
                  ),
                ),
                SizedBox(width: 12),
                Expanded(
                  child: TextField(
                    enabled: false,
                    decoration: InputDecoration(labelText: 'CVV'),
                  ),
                ),
              ],
            ),
            Space(12),
            CheckboxListTile(
              value: false,
              onChanged: null,
              title: Text('اجعلها وسيلة الدفع الافتراضية'),
            ),
            FilledButton(onPressed: null, child: Text('حفظ البطاقة — قريبًا')),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(c),
          child: const Text('إغلاق'),
        ),
      ],
    ),
  );
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const SectionTitle(
        'طرق الدفع',
        subtitle: 'بطاقاتك ومحافظك الرقمية في مكان واحد.',
      ),
      const ReferencePanel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(Icons.credit_card_outlined, size: 40, color: brand),
            Space(12),
            Text(
              'لا توجد بطاقات محفوظة',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Space(8),
            Text(
              'حفظ البطاقات وإدارة الوسيلة الافتراضية سيُتاحان بعد ربط بوابة الدفع.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
      const Space(12),
      for (final method in ['مدى', 'Visa / Mastercard', 'Apple Pay'])
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: ReferencePanel(
            child: Row(
              children: [
                const Icon(Icons.account_balance_wallet_outlined, color: brand),
                const SizedBox(width: 16),
                Expanded(
                  child: Text(
                    method,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const Tag('قريبًا'),
              ],
            ),
          ),
        ),
      OutlinedButton.icon(
        onPressed: () => cardForm(context),
        icon: const Icon(Icons.add),
        label: const Text('إضافة بطاقة'),
      ),
    ],
  );
}

class AppDownloadButtons extends StatelessWidget {
  const AppDownloadButtons({super.key});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Wrap(
        spacing: 12,
        runSpacing: 12,
        children: [
          for (final store in [
            (Icons.apple, 'App Store'),
            (Icons.android, 'Google Play'),
          ])
            OutlinedButton.icon(
              onPressed: () => showDialog<void>(
                context: context,
                builder: (c) => AlertDialog(
                  title: Text(store.$2),
                  content: const Text(
                    'تطبيق سكن قادم قريبًا. يمكنك الآن استخدام الموقع وإدارة حجوزاتك من متصفح الجوال.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(c),
                      child: const Text('حسنًا'),
                    ),
                  ],
                ),
              ),
              icon: Icon(store.$1),
              label: Text('${store.$2} · قريبًا'),
            ),
        ],
      ),
      const Space(12),
      const Text(
        'ستُضاف روابط المتاجر ورمز التحميل بعد إصدار التطبيق.',
        style: TextStyle(fontSize: 12),
      ),
    ],
  );
}

class FuturePreferencesPanel extends StatelessWidget {
  const FuturePreferencesPanel({super.key});
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const SectionTitle(
        'تفضيلات الإشعارات',
        subtitle: 'إدارة قنوات التنبيه ستُتاح بعد ربط الخدمات.',
      ),
      for (final item in [
        ('تأكيدات الحجز', 'رسالة نصية وإشعار عند تأكيد الحجز'),
        ('تعليمات الوصول', 'تنبيه عند إتاحة تعليمات الدخول'),
        ('العروض', 'عروض الإقامات والإقامات الشهرية'),
        ('الفواتير على البريد', 'نسخة من الفاتورة عند إصدارها'),
      ])
        Column(
          children: [
            SwitchListTile(
              value: false,
              onChanged: null,
              title: Text(item.$1),
              subtitle: Text('${item.$2} · قريبًا'),
            ),
            const Divider(),
          ],
        ),
    ],
  );
}

class FutureInvoicesPanel extends StatelessWidget {
  const FutureInvoicesPanel({super.key});
  @override
  Widget build(BuildContext context) => const ReferencePanel(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionTitle('الفواتير', subtitle: 'فواتير إقاماتك في مكان واحد'),
        Icon(Icons.receipt_long_outlined, size: 48, color: brand),
        Space(20),
        Text(
          'تحميل الفواتير الضريبية PDF قريبًا',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
        Space(12),
        Text(
          'يمكنك حاليًا مراجعة السعر والمدفوعات المسجلة من تفاصيل حجزك.',
          textAlign: TextAlign.center,
        ),
        Space(20),
        OutlinedButton(onPressed: null, child: Text('تحميل الفاتورة — قريبًا')),
      ],
    ),
  );
}
