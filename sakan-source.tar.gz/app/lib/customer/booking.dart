import '../ui/system.dart';
import '../chat/chat.dart';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import '../core/models.dart';
import '../core/repository.dart';
import 'widgets.dart';
import 'auth.dart';

class CheckoutPage extends StatefulWidget {
  final SakanRepository repo;
  final Unit unit;
  final Stay stay;
  const CheckoutPage({
    required this.repo,
    required this.unit,
    required this.stay,
    super.key,
  });
  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  int step = 0;
  late Future<Json> quote;
  Booking? booking;
  String requestKey = const Uuid().v4();
  final coupon = TextEditingController(),
      name = TextEditingController(),
      phone = TextEditingController(),
      email = TextEditingController();
  Timer? timer;
  @override
  void initState() {
    super.initState();
    quote = widget.repo.quote(widget.unit, widget.stay);
    phone.text = widget.repo.phone;
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && step == 2) setState(() {});
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    coupon.dispose();
    name.dispose();
    phone.dispose();
    email.dispose();
    super.dispose();
  }

  Future<void> next() async {
    if (!widget.repo.signedIn) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => LoginPage(widget.repo)),
      );
      if (!widget.repo.signedIn) return;
      phone.text = widget.repo.phone;
    }
    setState(() => step = 1);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        ['راجع حجزك', 'بيانات الضيف', 'إتمام الدفع', 'تم تأكيد حجزك'][step],
      ),
    ),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 650),
        child: ListView(
          padding: SakanLayout.padding(context),
          children: [
            if (step < 3) ...[
              Text(
                widget.unit.name,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              Text(
                '${dateKey(widget.stay.start)} ← ${dateKey(widget.stay.end)}',
              ),
              Text('${widget.stay.nights} ليالٍ • ${widget.stay.guests} ضيوف'),
              const Space(24),
              LinearProgressIndicator(value: (step + 1) / 3, minHeight: 4),
              const Space(24),
            ],
            if (step == 0) ...[
              Picture(widget.unit.images.firstOrNull, height: 170),
              const SectionTitle('تفاصيل السعر'),
              FutureBuilder<Json>(
                future: quote,
                builder: (c, s) {
                  if (s.hasError) {
                    return EmptyState('تعذر احتساب السعر', '${s.error}');
                  }
                  if (!s.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  return Column(
                    children: [
                      PriceBreakdown(s.data!),
                      const Space(),
                      TextField(
                        controller: coupon,
                        decoration: InputDecoration(
                          labelText: 'هل لديك كوبون؟',
                          suffixIcon: IconButton(
                            tooltip: 'تطبيق الكوبون',
                            onPressed: () async {
                              if (coupon.text.isNotEmpty &&
                                  !widget.repo.signedIn) {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => LoginPage(widget.repo),
                                  ),
                                );
                                if (!mounted) return;
                              }
                              setState(
                                () => quote = widget.repo.quote(
                                  widget.unit,
                                  widget.stay,
                                  coupon: coupon.text.trim(),
                                ),
                              );
                            },
                            icon: const Icon(Icons.check),
                          ),
                        ),
                      ),
                      const Space(),
                      SizedBox(
                        width: double.infinity,
                        child: AsyncAction(label: 'متابعة', action: next),
                      ),
                    ],
                  );
                },
              ),
            ],
            if (step == 1) ...[
              TextField(
                controller: name,
                autofillHints: const [AutofillHints.name],
                decoration: const InputDecoration(
                  labelText: 'اسم الضيف الرئيسي',
                ),
              ),
              const Space(),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr,
                decoration: const InputDecoration(labelText: 'الجوال'),
              ),
              const Space(),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'البريد الإلكتروني (اختياري)',
                ),
              ),
              const Space(),
              const Text(
                'عند المتابعة نحتفظ بالوحدة لمدة 10 دقائق لإكمال الدفع. السعر المعتمد سيظهر في الخطوة التالية.',
              ),
              const Space(),
              AsyncAction(
                label: 'متابعة للدفع',
                action: () async {
                  if (name.text.trim().length < 2 ||
                      !RegExp(
                        r'^\+9665[0-9]{8}$',
                      ).hasMatch(phone.text.trim())) {
                    throw StateError('أكمل الاسم والجوال بصورة صحيحة');
                  }
                  final b = await widget.repo.hold(
                    widget.unit,
                    widget.stay,
                    requestKey,
                    coupon: coupon.text.trim(),
                  );
                  await widget.repo.guest(
                    b,
                    name.text.trim(),
                    phone.text.trim(),
                    email.text.trim(),
                  );
                  setState(() {
                    booking = b;
                    step = 2;
                  });
                },
              ),
            ],
            if (step == 2 && booking != null) ...[
              const Icon(Icons.lock_outline, size: 54, color: brand),
              const Space(),
              Text(
                booking!.expired
                    ? 'انتهت مهلة الحجز'
                    : 'الوحدة محفوظة لك ${remaining()}',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const Space(),
              PriceBreakdown(
                Map<String, dynamic>.from(booking!.data['price_snapshot']),
              ),
              const Space(),
              if (booking!.expired)
                AsyncAction(
                  label: 'محاولة الحجز من جديد',
                  action: () async {
                    requestKey = const Uuid().v4();
                    setState(() => step = 1);
                  },
                )
              else if (widget.repo.demo) ...[
                const Tag('محاكاة فقط — لن نطلب بيانات بطاقة أو نخصم مبلغًا'),
                const Space(),
                AsyncAction(
                  label: 'محاكاة نجاح الدفع',
                  action: () async {
                    final b = await widget.repo.demoPay(booking!);
                    setState(() {
                      booking = b;
                      step = 3;
                    });
                  },
                ),
              ] else ...[
                const Text(
                  'مدى • Apple Pay • Visa / Mastercard\nتظهر وسائل الدفع المتاحة لدى المزود بعد تفعيله.',
                ),
                const Space(),
                AsyncAction(
                  label: 'فتح صفحة الدفع الآمنة',
                  action: () async {
                    final url = await widget.repo.checkout(booking!);
                    final uri = Uri.parse(url);
                    if (uri.scheme != 'https') {
                      throw StateError('رابط دفع غير آمن');
                    }
                    if (!await launchUrl(
                      uri,
                      mode: LaunchMode.externalApplication,
                    )) {
                      throw StateError('تعذر فتح بوابة الدفع');
                    }
                  },
                ),
                const Space(),
                AsyncAction(
                  label: 'تحقق من حالة الدفع',
                  action: () async {
                    final b = (await widget.repo.bookings()).firstWhere(
                      (b) => b.id == booking!.id,
                    );
                    if (b.status != 'confirmed') {
                      throw StateError('لم يصل تأكيد الدفع من الخادم بعد');
                    }
                    setState(() {
                      booking = b;
                      step = 3;
                    });
                  },
                ),
              ],
            ],
            if (step == 3) ...[
              const Space(40),
              const Icon(Icons.check_circle, size: 84, color: brand),
              const SectionTitle(
                'مكانك ينتظرك',
                subtitle: 'تفاصيل إقامتك محفوظة في حجوزاتي.',
              ),
              Text(
                booking!.number,
                style: const TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
              if (widget.repo.demo) const Center(child: Tag('حجز تجريبي')),
              const Space(30),
              FilledButton(
                onPressed: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => BookingDetail(widget.repo, booking!),
                  ),
                ),
                child: const Text('عرض الحجز'),
              ),
              TextButton(
                onPressed: () => Navigator.popUntil(context, (r) => r.isFirst),
                child: const Text('العودة للرئيسية'),
              ),
            ],
          ],
        ),
      ),
    ),
  );
  String remaining() {
    final seconds = DateTime.parse(
      booking!.data['hold_expires_at'],
    ).difference(DateTime.now()).inSeconds.clamp(0, 600);
    return '${seconds ~/ 60}:${(seconds % 60).toString().padLeft(2, '0')}';
  }
}

class PriceBreakdown extends StatelessWidget {
  final Json quote;
  const PriceBreakdown(this.quote, {super.key});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          for (final line
              in (quote['nights'] is List ? quote['nights'] : []) as List)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(child: Text(line['day'])),
                const SizedBox(width: 12),
                Flexible(
                  child: Text(money(line['price']), textAlign: TextAlign.end),
                ),
              ],
            ),
          const Divider(),
          for (final field in [
            ('subtotal', 'الإقامة'),
            ('service_fee', 'رسوم الخدمة'),
            ('discount', 'الخصم'),
            ('tax', 'الضريبة'),
            ('total', 'الإجمالي'),
          ])
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Wrap(
                alignment: WrapAlignment.spaceBetween,
                spacing: 16,
                runSpacing: 4,
                children: [
                  Text(
                    field.$2,
                    style: TextStyle(
                      fontWeight: field.$1 == 'total'
                          ? FontWeight.bold
                          : FontWeight.normal,
                    ),
                  ),
                  Text(
                    '${field.$1 == 'discount' ? '- ' : ''}${money(quote[field.$1] ?? 0)}',
                    style: TextStyle(
                      fontWeight: field.$1 == 'total'
                          ? FontWeight.bold
                          : FontWeight.normal,
                      color: brand,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    ),
  );
}

class BookingsPage extends StatefulWidget {
  final SakanRepository repo;
  final Future<bool> Function() onLogin;
  const BookingsPage(this.repo, {required this.onLogin, super.key});
  @override
  State<BookingsPage> createState() => _BookingsPageState();
}

class _BookingsPageState extends State<BookingsPage> {
  String filter = 'all';
  @override
  Widget build(BuildContext context) => PageList(
    maxWidth: 960,
    padding: SakanLayout.padding(context),
    children: [
      const SectionTitle('إقاماتك، في مكان واحد'),
      if (!widget.repo.signedIn) ...[
        const EmptyState('ننتظر رحلتك الأولى', 'سجّل الدخول لعرض حجوزاتك.'),
        FilledButton(
          onPressed: () async {
            await widget.onLogin();
            setState(() {});
          },
          child: const Text('تسجيل الدخول'),
        ),
      ] else ...[
        Wrap(
          spacing: 8,
          children: [
            for (final f in [
              ('all', 'الكل'),
              ('upcoming', 'القادمة'),
              ('current', 'الحالية'),
              ('past', 'السابقة'),
            ])
              ChoiceChip(
                label: Text(f.$2),
                selected: filter == f.$1,
                onSelected: (_) => setState(() => filter = f.$1),
              ),
          ],
        ),
        const Space(),
        FutureBuilder<List<Booking>>(
          future: widget.repo.bookings(),
          builder: (c, s) {
            if (s.hasError) {
              return EmptyState('تعذر تحميل الحجوزات', '${s.error}');
            }
            if (!s.hasData) {
              return const Center(child: CircularProgressIndicator());
            }
            final rows = s.data!
                .where(
                  (b) =>
                      filter == 'all' ||
                      (filter == 'upcoming' &&
                          ['hold', 'confirmed'].contains(b.status)) ||
                      (filter == 'current' && b.status == 'checked_in') ||
                      (filter == 'past' &&
                          [
                            'completed',
                            'cancelled',
                            'expired',
                          ].contains(b.status)),
                )
                .toList();
            if (rows.isEmpty) {
              return const EmptyState(
                'رحلتك القادمة تبدأ هنا',
                'اكتشف إقامات الرياض واختر ما يناسبك.',
              );
            }
            return Column(
              children: rows
                  .map(
                    (b) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Card(
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(18),
                          leading: MediaQuery.sizeOf(context).width < 400
                              ? null
                              : const Icon(Icons.home_outlined, color: brand),
                          title: Text(b.number),
                          subtitle: Text(
                            '${b.data['unit_name'] ?? ''}\n${b.data['check_in']} ← ${b.data['check_out']}\n${money(b.total)}${MediaQuery.sizeOf(context).width < 600 ? '\n${statusLabel(b.expired ? 'expired' : b.status)}' : ''}',
                          ),
                          trailing: MediaQuery.sizeOf(context).width < 600
                              ? null
                              : Tag(
                                  statusLabel(b.expired ? 'expired' : b.status),
                                ),
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => BookingDetail(widget.repo, b),
                              ),
                            );
                            setState(() {});
                          },
                        ),
                      ),
                    ),
                  )
                  .toList(),
            );
          },
        ),
      ],
    ],
  );
}

class BookingDetail extends StatefulWidget {
  final SakanRepository repo;
  final Booking booking;
  const BookingDetail(this.repo, this.booking, {super.key});
  @override
  State<BookingDetail> createState() => _BookingDetailState();
}

class _BookingDetailState extends State<BookingDetail> {
  @override
  Widget build(BuildContext context) {
    final b = widget.booking;
    return Scaffold(
      appBar: AppBar(title: Text(b.number)),
      body: PageList(
        maxWidth: SakanLayout.form,
        padding: SakanLayout.padding(context),
        children: [
          Tag(statusLabel(b.status)),
          const SectionTitle('تفاصيل إقامتك'),
          Text(
            '${b.data['check_in']} ← ${b.data['check_out']}\n${b.data['guests_count']} ضيوف',
          ),
          const Space(),
          PriceBreakdown(Map<String, dynamic>.from(b.data['price_snapshot'])),
          const Space(),
          Card(
            child: ListTile(
              leading: const Icon(Icons.support_agent),
              title: const Text('تواصل مع خدمة العملاء'),
              subtitle: const Text('محادثة خاصة بخصوص هذا الحجز'),
              trailing: const Icon(Icons.chevron_left),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BookingChat(
                    repo: widget.repo,
                    bookingId: b.id,
                    bookingNumber: b.number,
                  ),
                ),
              ),
            ),
          ),
          const SectionTitle('تعليمات الوصول'),
          FutureBuilder<Json?>(
            future: widget.repo.access(b),
            builder: (c, s) {
              if (s.hasError) {
                return const Text('تعذر تحميل التعليمات. أعد المحاولة لاحقًا.');
              }
              if (!s.hasData) {
                return const Card(
                  child: Padding(
                    padding: EdgeInsets.all(22),
                    child: Text(
                      'ستظهر معلومات الدخول في الوقت المحدد قبل إقامتك. لا تُعرض رموز الدخول في النسخة التجريبية.',
                    ),
                  ),
                );
              }
              return Card(
                child: Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s.data!['address']),
                      Text(s.data!['instructions']),
                      SelectableText(
                        s.data!['entry_code'] ?? '',
                        style: const TextStyle(fontSize: 28),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          const Space(),
          if (['confirmed', 'hold'].contains(b.status))
            AsyncAction(
              label: b.status == 'hold'
                  ? 'إلغاء الحجز المؤقت'
                  : 'طلب إلغاء الحجز',
              action: () async {
                await widget.repo.cancel(b);
                if (context.mounted) {
                  showError(
                    context,
                    b.status == 'hold'
                        ? 'أُلغي الحجز المؤقت'
                        : 'سُجل طلب الإلغاء للمراجعة؛ لم ينفذ استرداد مالي بعد',
                  );
                  Navigator.pop(context);
                }
              },
            ),
          if (b.status == 'completed') ...[
            const Space(),
            AsyncAction(label: 'قيّم إقامتك', action: review),
          ],
          const Space(),
          const Text(
            'ملخص الحجز أعلاه ليس فاتورة ضريبية. إصدار الفاتورة مرتبط بإعدادات المشغّل المالية.',
          ),
        ],
      ),
    );
  }

  Future<void> review() async {
    int rating = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          scrollable: true,
          title: const Text('كيف كانت إقامتك؟'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Slider(
                value: rating.toDouble(),
                min: 1,
                max: 5,
                divisions: 4,
                label: '$rating',
                onChanged: (v) => set(() => rating = v.round()),
              ),
              TextField(
                controller: comment,
                decoration: const InputDecoration(labelText: 'تعليقك'),
              ),
            ],
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(c, true),
              child: const Text('إرسال التقييم'),
            ),
          ],
        ),
      ),
    );
    if (ok == true) {
      await widget.repo.upsert('reviews', {
        'booking_id': widget.booking.id,
        'customer_id': widget.repo.userId,
        'unit_id': widget.booking.unitId,
        'rating': rating,
        'comment': comment.text,
        'published': false,
      });
    }
    comment.dispose();
  }
}
