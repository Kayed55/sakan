import 'package:flutter/material.dart';
import '../core/models.dart';
import 'widgets.dart';
import 'design.dart';
import 'planned_services.dart';

/// Shared responsive composition for the supplied desktop and mobile layouts.
class ReferenceColumns extends StatelessWidget {
  final Widget main, aside;
  final double asideWidth;
  const ReferenceColumns({
    required this.main,
    required this.aside,
    this.asideWidth = 340,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) => box.maxWidth >= 1000
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(child: main),
              const SizedBox(width: 28),
              SizedBox(
                width: box.maxWidth < 1100 ? 300 : asideWidth,
                child: aside,
              ),
            ],
          )
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [main, const Space(24), aside],
          ),
  );
}

class ReferencePanel extends StatelessWidget {
  final Widget child;
  const ReferencePanel({required this.child, super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.all(MediaQuery.sizeOf(context).width < 600 ? 16 : 24),
    decoration: BoxDecoration(
      color: surface,
      border: Border.all(color: const Color(0xffe9dfc9)),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Material(color: Colors.transparent, child: child),
  );
}

class UnitGallery extends StatelessWidget {
  final List<String> images;
  const UnitGallery(this.images, {super.key});
  void open(BuildContext context) => showDialog<void>(
    context: context,
    builder: (c) => Dialog.fullscreen(
      child: Scaffold(
        appBar: AppBar(title: Text('صور الوحدة · ${images.length}')),
        body: PageView(
          children: images
              .map(
                (p) => InteractiveViewer(
                  child: Center(
                    child: Picture(
                      p,
                      height: MediaQuery.sizeOf(c).height * .75,
                    ),
                  ),
                ),
              )
              .toList(),
        ),
      ),
    ),
  );
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 800;
      final height = wide ? 480.0 : 280.0;
      Widget photo(int n) => GestureDetector(
        onTap: () => open(context),
        child: Picture(images[n], height: wide ? 236 : height),
      );
      return SizedBox(
        height: height,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (wide && images.length >= 3)
              Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: GestureDetector(
                      onTap: () => open(context),
                      child: Picture(images.first, height: height),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      children: [photo(1), const SizedBox(height: 8), photo(2)],
                    ),
                  ),
                  if (images.length >= 5) ...[
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        children: [
                          photo(3),
                          const SizedBox(height: 8),
                          photo(4),
                        ],
                      ),
                    ),
                  ],
                ],
              )
            else
              PageView(
                children: (images.isEmpty ? <String?>[null] : images)
                    .map((p) => Picture(p, height: height))
                    .toList(),
              ),
            if (images.isNotEmpty)
              Positioned(
                bottom: 16,
                left: 16,
                child: FilledButton.tonalIcon(
                  onPressed: () => open(context),
                  icon: const Icon(Icons.grid_view),
                  label: Text('كل الصور · ${images.length}'),
                ),
              ),
          ],
        ),
      );
    },
  );
}

class NeighbourhoodCards extends StatelessWidget {
  final List<Unit> units;
  final void Function(String) onSelect;
  final bool english;
  const NeighbourhoodCards({
    required this.units,
    required this.onSelect,
    this.english = false,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final groups = <String, List<Unit>>{};
    for (final u in units) {
      groups.putIfAbsent(u.district, () => []).add(u);
    }
    if (groups.isEmpty) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SectionTitle(
          english ? 'Find your neighbourhood' : 'كل حي، حكاية مختلفة',
          subtitle: english
              ? 'Explore Riyadh through its neighbourhoods'
              : 'اختر الحي الأقرب لوجهتك في الرياض',
        ),
        const Space(12),
        LayoutBuilder(
          builder: (context, box) {
            final cols = box.maxWidth >= 900
                ? 3
                : box.maxWidth >= 560
                ? 2
                : 1;
            return Wrap(
              spacing: 24,
              runSpacing: 24,
              children: groups.entries.map((g) {
                final prices = g.value.map((u) => u.price).toList()..sort();
                return SizedBox(
                  width: (box.maxWidth - (cols - 1) * 24) / cols,
                  child: InkWell(
                    onTap: () => onSelect(g.key),
                    borderRadius: BorderRadius.circular(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Stack(
                          children: [
                            AspectRatio(
                              aspectRatio: 1.6,
                              child: Picture(
                                g.value.first.images.firstOrNull,
                                height: 240,
                              ),
                            ),
                            Positioned(
                              top: 12,
                              right: 12,
                              child: Chip(
                                label: Text(
                                  '${g.value.length} ${english ? 'stays' : 'إقامات'}',
                                ),
                              ),
                            ),
                          ],
                        ),
                        const Space(16),
                        Row(
                          children: [
                            Expanded(
                              child: Text(
                                g.key,
                                style: const TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const Icon(Icons.arrow_forward),
                          ],
                        ),
                        Text(
                          '${english ? 'From' : 'تبدأ من'} ${money(prices.first)} / ${english ? 'night' : 'ليلة'}',
                        ),
                        const Space(12),
                      ],
                    ),
                  ),
                );
              }).toList(),
            );
          },
        ),
        const Space(48),
      ],
    );
  }
}

class PocketSection extends StatelessWidget {
  final bool english;
  final VoidCallback onBookings;
  const PocketSection({
    required this.onBookings,
    this.english = false,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xffe4ecf3),
    padding: EdgeInsets.all(MediaQuery.sizeOf(context).width < 600 ? 24 : 48),
    child: ReferenceColumns(
      main: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            english ? 'Your stay, in your pocket' : 'إقامتك كلها\nفي جيبك',
            style: const TextStyle(
              fontSize: 38,
              height: 1.3,
              fontWeight: FontWeight.w700,
            ),
          ),
          const Space(24),
          for (final item in [
            (
              Icons.calendar_month_outlined,
              english
                  ? 'Your bookings in one place'
                  : 'حجوزاتك وتفاصيلها في مكان واحد',
            ),
            (
              Icons.key_outlined,
              english
                  ? 'Arrival instructions when eligible'
                  : 'تعليمات الوصول عند استحقاق الدخول',
            ),
            (
              Icons.chat_bubble_outline,
              english
                  ? 'Chat with support from your booking'
                  : 'دردشة مباشرة مع الدعم من حجزك',
            ),
          ])
            Padding(
              padding: const EdgeInsets.only(bottom: 20),
              child: Row(
                children: [
                  Icon(item.$1, color: brand),
                  const SizedBox(width: 16),
                  Expanded(child: Text(item.$2)),
                ],
              ),
            ),
          FilledButton(
            onPressed: onBookings,
            child: Text(english ? 'Open my bookings' : 'افتح حجوزاتي'),
          ),
          const Space(12),
          const AppDownloadButtons(),
          const Space(16),
          Text(
            english
                ? 'Available now from your mobile browser.'
                : 'متاح الآن مباشرة من متصفح جوالك.',
            style: const TextStyle(color: Color(0xff5b6670)),
          ),
        ],
      ),
      aside: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: brandInk,
          borderRadius: BorderRadius.circular(32),
        ),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: const Color(0xfffaf6ee),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            children: [
              const BrandMark(width: 100),
              const Space(36),
              const Icon(Icons.home_outlined, size: 60, color: brand),
              const Space(24),
              Text(
                english
                    ? 'Everything you need for your stay'
                    : 'كل ما تحتاجه لإقامتك',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Space(28),
              for (final label in [
                english ? 'Booking details' : 'تفاصيل الحجز',
                english ? 'Arrival instructions' : 'تعليمات الوصول',
                english ? 'Customer support' : 'خدمة العملاء',
              ])
                ListTile(
                  dense: true,
                  title: Text(label),
                  trailing: const Icon(Icons.chevron_left),
                ),
              const Space(16),
              Text(
                english ? 'Interface preview' : 'معاينة الواجهة',
                style: const TextStyle(fontSize: 12, color: Color(0xff5b6670)),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
