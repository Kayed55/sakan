import '../core/routes.dart';
import '../ui/system.dart';
import 'package:flutter/material.dart';
import '../core/repository.dart';
import 'widgets.dart';
import 'design.dart';

class LoginPage extends StatefulWidget {
  final SakanRepository repo;
  final VoidCallback? onAuthenticated;
  const LoginPage(this.repo, {this.onAuthenticated, super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController(text: '+966');
  final code = TextEditingController();
  bool sent = false, agreed = false;
  @override
  void dispose() {
    phone.dispose();
    code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      leading: BackButton(onPressed: () => finishPage(context)),
      title: const Text('أهلاً بك في سكن'),
    ),
    body: LayoutBuilder(
      builder: (context, box) {
        final form = Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: ListView(
              padding: SakanLayout.padding(context),
              children: [
                const Space(30),
                const Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: BrandMark(width: 132),
                ),
                SectionTitle(
                  sent ? 'أدخل رمز التحقق' : 'أهلًا بك في سكن',
                  subtitle: sent
                      ? 'أرسلنا رمز التحقق إلى رقم جوالك.'
                      : 'سجّل دخولك برقم جوالك. خطوة واحدة وتكمل حجزك.',
                ),
                TextField(
                  controller: phone,
                  enabled: !sent,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(
                    labelText: 'رقم الجوال +9665XXXXXXXX',
                  ),
                ),
                const Space(),
                if (!sent)
                  CheckboxListTile(
                    value: agreed,
                    onChanged: (v) => setState(() => agreed = v!),
                    title: const Text(
                      'أوافق على شروط الاستخدام وسياسة الخصوصية',
                    ),
                  ),
                if (sent) ...[
                  TextField(
                    controller: code,
                    keyboardType: TextInputType.number,
                    maxLength: 6,
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.ltr,
                    style: const TextStyle(fontSize: 28, letterSpacing: 12),
                    decoration: const InputDecoration(labelText: 'رمز التحقق'),
                  ),
                  if (widget.repo.demo) const Tag('تجربة محلية — الرمز 123456'),
                ],
                const Space(),
                AsyncAction(
                  label: sent ? 'تحقق ومتابعة' : 'إرسال رمز التحقق',
                  action: () async {
                    if (!sent) {
                      if (!agreed) {
                        throw StateError('الموافقة مطلوبة قبل المتابعة');
                      }
                      await widget.repo.sendOtp(phone.text.trim());
                      setState(() => sent = true);
                    } else {
                      await widget.repo.verifyOtp(
                        phone.text.trim(),
                        code.text.trim(),
                      );
                      if (context.mounted) {
                        if (widget.onAuthenticated != null) {
                          widget.onAuthenticated!();
                        } else {
                          finishPage(context, true);
                        }
                      }
                    }
                  },
                ),
                if (sent)
                  TextButton(
                    onPressed: () => setState(() => sent = false),
                    child: const Text('تغيير رقم الجوال أو إعادة الإرسال'),
                  ),
                const Space(),
                const Text(
                  'نسخة تطويرية: وثائق الشروط والخصوصية النهائية تحتاج اعتماد المشغّل قبل استقبال حجوزات حقيقية.',
                  style: TextStyle(color: Color(0xff5b6670)),
                ),
              ],
            ),
          ),
        );
        if (box.maxWidth < 900) return form;
        return Row(
          children: [
            Expanded(child: form),
            Expanded(
              child: Container(
                color: const Color(0xffe4ecf3),
                padding: const EdgeInsets.all(56),
                child: const Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      BrandMark(width: 180),
                      Space(48),
                      Text(
                        'مساحتك في الرياض.\nوتفاصيلك في مكان واحد.',
                        style: TextStyle(
                          fontSize: 48,
                          height: 1.4,
                          fontWeight: FontWeight.w300,
                        ),
                      ),
                      Space(24),
                      Text(
                        'احفظ إقاماتك المفضلة، تابع حجوزاتك، وتواصل مع فريق الدعم.',
                        style: TextStyle(fontSize: 20, height: 1.8),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    ),
  );
}
