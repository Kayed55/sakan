import 'package:flutter/material.dart';
import '../core/repository.dart';
import 'widgets.dart';

class LoginPage extends StatefulWidget {
  final SakanRepository repo;
  const LoginPage(this.repo, {super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController(text: '+966');
  final code = TextEditingController();
  bool sent = false, agreed = false;
  @override
  void dispose() {
    phone.dispose();
    code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('أهلاً بك في سكن')),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: ListView(
          padding: const EdgeInsets.all(28),
          children: [
            const Space(30),
            const Icon(Icons.home_work_outlined, size: 64),
            const SectionTitle(
              'إقامتك أقرب مما تتخيل',
              subtitle: 'نحتاج رقم جوالك لتأكيد الحجز ومتابعة إقامتك.',
            ),
            TextField(
              controller: phone,
              enabled: !sent,
              keyboardType: TextInputType.phone,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                labelText: 'رقم الجوال +9665XXXXXXXX',
              ),
            ),
            const Space(),
            if (!sent)
              CheckboxListTile(
                value: agreed,
                onChanged: (v) => setState(() => agreed = v!),
                title: const Text('أوافق على شروط الاستخدام وسياسة الخصوصية'),
              ),
            if (sent) ...[
              TextField(
                controller: code,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(labelText: 'رمز التحقق'),
              ),
              if (widget.repo.demo) const Tag('تجربة محلية — الرمز 123456'),
            ],
            const Space(),
            AsyncAction(
              label: sent ? 'تحقق ومتابعة' : 'إرسال رمز التحقق',
              action: () async {
                if (!sent) {
                  if (!agreed) throw StateError('الموافقة مطلوبة قبل المتابعة');
                  await widget.repo.sendOtp(phone.text.trim());
                  setState(() => sent = true);
                } else {
                  await widget.repo.verifyOtp(
                    phone.text.trim(),
                    code.text.trim(),
                  );
                  if (context.mounted) Navigator.pop(context, true);
                }
              },
            ),
            if (sent)
              TextButton(
                onPressed: () => setState(() => sent = false),
                child: const Text('تغيير رقم الجوال أو إعادة الإرسال'),
              ),
            const Space(),
            const Text(
              'نسخة تطويرية: وثائق الشروط والخصوصية النهائية تحتاج اعتماد المشغّل قبل استقبال حجوزات حقيقية.',
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    ),
  );
}
