import 'dart:convert';
import 'package:flutter/material.dart';
import '../core/models.dart';

class Space extends StatelessWidget {
  final double height;
  const Space([this.height = 20, Key? key]) : super(key: key);
  @override
  Widget build(BuildContext context) => SizedBox(height: height);
}

class Picture extends StatelessWidget {
  final String? url;
  final double height;
  const Picture(this.url, {this.height = 210, super.key});
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(20),
    child: url == null
        ? fallback()
        : url!.startsWith('data:')
        ? Image.memory(
            base64Decode(url!.split(',').last),
            height: height,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (c, e, s) => fallback(),
          )
        : Image.network(
            url!,
            height: height,
            width: double.infinity,
            fit: BoxFit.cover,
            errorBuilder: (c, e, s) => fallback(),
          ),
  );
  Widget fallback() => Container(
    height: height,
    color: const Color(0xffdedbce),
    child: const Center(
      child: Icon(Icons.weekend_outlined, size: 70, color: brand),
    ),
  );
}

class Tag extends StatelessWidget {
  final String text;
  const Tag(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(
      color: brand.withValues(alpha: .08),
      borderRadius: BorderRadius.circular(30),
    ),
    child: Text(
      text,
      style: const TextStyle(
        color: brand,
        fontSize: 12,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  const SectionTitle(this.title, {this.subtitle, super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall),
        if (subtitle != null)
          Text(subtitle!, style: const TextStyle(color: Colors.black54)),
      ],
    ),
  );
}

class EmptyState extends StatelessWidget {
  final String title, body;
  final IconData icon;
  const EmptyState(
    this.title,
    this.body, {
    this.icon = Icons.inbox_outlined,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(36),
    child: Column(
      children: [
        Container(
          padding: const EdgeInsets.all(23),
          decoration: BoxDecoration(
            color: const Color(0xffeeeee5),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Icon(icon, size: 36, color: gold),
        ),
        const Space(),
        Text(
          title,
          style: Theme.of(context).textTheme.titleLarge,
          textAlign: TextAlign.center,
        ),
        const Space(8),
        Text(
          body,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.black54),
        ),
      ],
    ),
  );
}

void showError(BuildContext context, Object error) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text(error.toString().replaceFirst('Bad state: ', ''))),
  );
}

class AsyncAction extends StatefulWidget {
  final String label;
  final Future<void> Function() action;
  const AsyncAction({required this.label, required this.action, super.key});
  @override
  State<AsyncAction> createState() => _AsyncActionState();
}

class _AsyncActionState extends State<AsyncAction> {
  bool busy = false;
  @override
  Widget build(BuildContext context) => FilledButton(
    onPressed: busy
        ? null
        : () async {
            setState(() => busy = true);
            try {
              await widget.action();
            } catch (e) {
              if (context.mounted) showError(context, e);
            } finally {
              if (mounted) setState(() => busy = false);
            }
          },
    child: busy
        ? const SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(strokeWidth: 2),
          )
        : Text(widget.label),
  );
}
