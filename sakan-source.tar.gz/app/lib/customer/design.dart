import 'package:flutter/material.dart';
import '../core/models.dart';

class BrandMark extends StatelessWidget {
  final bool light;
  const BrandMark({this.light = false, super.key});
  @override
  Widget build(BuildContext context) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 36,
        height: 42,
        decoration: BoxDecoration(
          border: Border.all(color: light ? gold : brand, width: 1.3),
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(20),
            bottom: Radius.circular(4),
          ),
        ),
        child: Icon(
          Icons.door_front_door_outlined,
          size: 21,
          color: light ? gold : brand,
        ),
      ),
      const SizedBox(width: 10),
      Text(
        'سكن',
        style: TextStyle(
          fontSize: 32,
          height: 1.2,
          fontWeight: FontWeight.w800,
          color: light ? Colors.white : brand,
        ),
      ),
    ],
  );
}

class EditorialHero extends StatelessWidget {
  final bool english;
  final bool welcome;
  final String? heading;
  final VoidCallback? onStart;
  const EditorialHero({
    this.english = false,
    this.welcome = false,
    this.heading,
    this.onStart,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth > 740;
      final copy = Padding(
        padding: EdgeInsets.all(wide ? 46 : 26),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              children: [
                Container(width: 24, height: 1, color: gold),
                const SizedBox(width: 10),
                Text(
                  english ? 'YOUR RIYADH CHAPTER' : 'إقامتك، على ذوقك',
                  style: const TextStyle(
                    color: Color(0xffd9c8aa),
                    fontSize: 12,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            Text(
              heading ??
                  (english
                      ? 'A little away.\nA lot like home.'
                      : 'غيّر مكانك.\nخلّ الراحة معك.'),
              style: TextStyle(
                fontSize: wide ? 48 : 35,
                height: 1.45,
                fontWeight: FontWeight.w600,
                color: Colors.white,
                letterSpacing: -.8,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              english
                  ? 'Thoughtful spaces for your time in Riyadh.\nFind a stay that feels like you.'
                  : 'مساحات تختارها لوقتك في الرياض.\nإقامة مريحة، وتفاصيل تشبهك.',
              style: const TextStyle(
                fontSize: 15,
                height: 1.9,
                color: Color(0xffd4ddd7),
              ),
            ),
            const SizedBox(height: 28),
            if (onStart != null)
              FilledButton.icon(
                onPressed: onStart,
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xffe7d8bd),
                  foregroundColor: brand,
                ),
                icon: const Icon(Icons.arrow_forward, size: 18),
                label: Text(english ? 'Discover Sakan' : 'اكتشف سكن'),
              )
            else
              Row(
                children: [
                  const Icon(Icons.location_on_outlined, size: 16, color: gold),
                  const SizedBox(width: 6),
                  Text(
                    english
                        ? 'RIYADH, SAUDI ARABIA'
                        : 'الرياض، المملكة العربية السعودية',
                    style: const TextStyle(
                      color: Color(0xffd4ddd7),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
          ],
        ),
      );
      final photo = Stack(
        fit: StackFit.expand,
        children: [
          Image.network(
            photos.first,
            fit: BoxFit.cover,
            errorBuilder: (_, error, stack) => const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xffb7aa91), Color(0xffe6ddcb)],
                ),
              ),
              child: Center(
                child: Icon(Icons.weekend_outlined, size: 100, color: brand),
              ),
            ),
          ),
          const DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Color(0x990f2520), Colors.transparent],
                stops: [0, .6],
              ),
            ),
          ),
          Positioned(
            bottom: 22,
            left: 22,
            right: 22,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  english ? 'ROOM TO SLOW DOWN' : 'خذ وقتك. خذ راحتك.',
                  style: const TextStyle(color: Colors.white, fontSize: 16),
                ),
                Text(
                  english ? 'Illustrative image' : 'صورة تعبيرية',
                  style: const TextStyle(color: Colors.white70, fontSize: 10),
                ),
              ],
            ),
          ),
        ],
      );
      return ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Container(
          color: brand,
          child: wide
              ? SizedBox(
                  height: welcome ? 510 : 410,
                  child: Row(
                    children: [
                      Expanded(child: copy),
                      Expanded(child: photo),
                    ],
                  ),
                )
              : Column(
                  children: [
                    copy,
                    SizedBox(height: welcome ? 240 : 180, child: photo),
                  ],
                ),
        ),
      );
    },
  );
}

class StaySearch extends StatelessWidget {
  final Stay stay;
  final bool english;
  final VoidCallback dates, guests, search;
  const StaySearch({
    required this.stay,
    required this.english,
    required this.dates,
    required this.guests,
    required this.search,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth > 850;
      Widget field(
        IconData icon,
        String label,
        String value,
        VoidCallback? tap,
      ) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              children: [
                Icon(icon, size: 22, color: gold),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Color(0xff7b8079),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        value,
                        style: const TextStyle(
                          fontSize: 13,
                          color: brand,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (tap != null)
                  const Icon(Icons.keyboard_arrow_down, size: 16, color: brand),
              ],
            ),
          ),
        ),
      );
      String day(DateTime date) => '${date.day} / ${date.month}';
      final fields = [
        field(
          Icons.place_outlined,
          english ? 'DESTINATION' : 'الوجهة',
          english ? 'Riyadh, Saudi Arabia' : 'الرياض، السعودية',
          null,
        ),
        field(
          Icons.calendar_today_outlined,
          english ? 'CHECK-IN — CHECK-OUT' : 'الوصول — المغادرة',
          '${day(stay.start)}  —  ${day(stay.end)}',
          dates,
        ),
        field(
          Icons.people_outline,
          english ? 'GUESTS' : 'الضيوف',
          '${stay.guests} ${english ? 'guests' : 'ضيوف'} · ${stay.nights} ${english ? 'nights' : 'ليالٍ'}',
          guests,
        ),
      ];
      final button = FilledButton.icon(
        onPressed: search,
        icon: const Icon(Icons.search, size: 20),
        label: Text(english ? 'Find your stay' : 'ابحث عن إقامتك'),
      );
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: const Color(0xffe8e5dc)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x0c233b30),
              blurRadius: 32,
              offset: Offset(0, 10),
            ),
          ],
        ),
        child: wide
            ? Row(
                children: [
                  for (final f in fields) Expanded(child: f),
                  const SizedBox(width: 12),
                  button,
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  fields[0],
                  const Divider(height: 1),
                  fields[1],
                  const Divider(height: 1),
                  fields[2],
                  const SizedBox(height: 8),
                  button,
                ],
              ),
      );
    },
  );
}

class SakanDetails extends StatelessWidget {
  final bool english;
  const SakanDetails({this.english = false, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final wide = c.maxWidth > 680;
      final items = [
        (
          Icons.weekend_outlined,
          english ? 'A space of your own' : 'مساحة لك',
          english
              ? 'Studios and apartments for your kind of stay.'
              : 'استديوهات وشقق تناسب أسلوب إقامتك.',
        ),
        (
          Icons.receipt_long_outlined,
          english ? 'Every detail, clearly' : 'كل التفاصيل واضحة',
          english
              ? 'Review your stay and total before payment.'
              : 'راجع تفاصيل الإقامة والسعر قبل الدفع.',
        ),
        (
          Icons.key_outlined,
          english ? 'Arrive with ease' : 'وصول بكل راحة',
          english
              ? 'Your eligible access details in one place.'
              : 'تعليمات دخول إقامتك في مكان واحد.',
        ),
      ];
      final children = items
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(13),
                    decoration: BoxDecoration(
                      color: const Color(0xffeeeee5),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(item.$1, color: brand, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.$2,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.$3,
                          style: const TextStyle(
                            color: Color(0xff777e76),
                            fontSize: 12,
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList();
      return wide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children.map((w) => Expanded(child: w)).toList(),
            )
          : Column(children: children);
    },
  );
}

class AdminWelcome extends StatelessWidget {
  final VoidCallback onLogin;
  const AdminWelcome({required this.onLogin, super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: LayoutBuilder(
              builder: (context, box) {
                final panel = Container(
                  padding: EdgeInsets.all(box.maxWidth > 700 ? 56 : 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const BrandMark(),
                      const SizedBox(height: 52),
                      const Text(
                        'مساحة الإدارة',
                        style: TextStyle(
                          fontSize: 12,
                          color: gold,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'كل إقامة رائعة،\nتبدأ من هنا.',
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                          color: brand,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'الحجوزات، الوحدات، وفريق التشغيل.\nكل ما تحتاجه لإدارة سكن في مساحة واحدة.',
                        style: TextStyle(color: Color(0xff737b72), height: 1.9),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: onLogin,
                          icon: const Icon(Icons.arrow_forward, size: 18),
                          label: const Text('تسجيل الدخول للموظفين'),
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Row(
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 14,
                            color: Color(0xff7b8079),
                          ),
                          SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              'وصول مخصص لأعضاء الفريق المصرّح لهم',
                              style: TextStyle(
                                fontSize: 11,
                                color: Color(0xff7b8079),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
                return Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xffe7e5dc)),
                  ),
                  child: box.maxWidth > 700
                      ? Row(
                          children: [
                            Expanded(child: panel),
                            Expanded(
                              child: SizedBox(
                                height: 590,
                                child: Image.network(
                                  photos.first,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, e, s) => Container(
                                    color: brand,
                                    child: const Center(
                                      child: BrandMark(light: true),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : panel,
                );
              },
            ),
          ),
        ),
      ),
    ),
  );
}
