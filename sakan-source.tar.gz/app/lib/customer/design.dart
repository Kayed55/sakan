import '../ui/system.dart';
import 'package:flutter/material.dart';
import '../core/models.dart';
import 'planned_services.dart';

/// Original Sakan artwork supplied by the owner; never mirrored in RTL layouts.
class BrandMark extends StatelessWidget {
  final bool light;
  final double width;
  const BrandMark({this.light = false, this.width = 124, super.key});
  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/brand/logo-${light ? "light" : "dark"}.png',
    width: width,
    height: width * 106 / 280,
    fit: BoxFit.contain,
    matchTextDirection: false,
    semanticLabel: 'سكن',
  );
}

/// Editorial introduction from the supplied Home v3 reference.
class EditorialHero extends StatelessWidget {
  final bool english, welcome;
  final String? heading;
  final VoidCallback? onStart;
  const EditorialHero({
    this.english = false,
    this.welcome = false,
    this.heading,
    this.onStart,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final title = Text(
        heading ??
            (english
                ? 'Selected stays\nin Riyadh'
                : 'إقامات مختارة\nفي الرياض'),
        style: TextStyle(
          fontSize: wide ? (box.maxWidth * .055).clamp(44, 64) : 32,
          height: 1.25,
          fontWeight: FontWeight.w700,
          color: brandInk,
        ),
      );
      final description = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            english
                ? 'Furnished apartments and studios for your time in Riyadh. Choose your dates, explore the details, and find your next stay.'
                : 'شقق واستديوهات مفروشة لإقامتك في الرياض. اختر تواريخك، واستكشف تفاصيل كل وحدة، واحجز المساحة التي تناسبك.',
            style: TextStyle(
              fontSize: wide ? 18 : 15,
              height: 1.7,
              color: Color(0xff5b6672),
            ),
          ),
          if (onStart != null) ...[
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: onStart,
              icon: const Icon(Icons.arrow_forward, size: 18),
              label: Text(english ? 'Explore stays' : 'اكتشف الإقامات'),
            ),
          ],
        ],
      );
      return Padding(
        padding: EdgeInsets.symmetric(vertical: wide ? 40 : 16),
        child: wide
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(child: title),
                  const SizedBox(width: 64),
                  Expanded(child: description),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [title, const SizedBox(height: 12), description],
              ),
      );
    },
  );
}

class StaySearch extends StatelessWidget {
  final Stay stay;
  final bool english;
  final VoidCallback dates, guests, search;
  const StaySearch({
    required this.stay,
    required this.english,
    required this.dates,
    required this.guests,
    required this.search,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 1000;
      Widget field(
        IconData icon,
        String label,
        String value,
        VoidCallback? tap,
      ) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: wide ? 14 : 10,
              vertical: 12,
            ),
            child: Row(
              children: [
                if (wide || box.maxWidth >= 500) ...[
                  Icon(icon, size: 21, color: brand),
                  const SizedBox(width: 12),
                ],
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(
                          fontSize: 13,
                          color: Color(0xff5b6672),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        value,
                        style: const TextStyle(
                          fontSize: 16,
                          color: brandInk,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (tap != null)
                  const Icon(Icons.keyboard_arrow_down, size: 16, color: brand),
              ],
            ),
          ),
        ),
      );
      String day(DateTime date) => '${date.day} / ${date.month}';
      final fields = [
        field(
          Icons.place_outlined,
          english ? 'DESTINATION' : 'الوجهة',
          english ? 'Riyadh, Saudi Arabia' : 'الرياض، السعودية',
          null,
        ),
        field(
          Icons.calendar_today_outlined,
          english ? 'CHECK-IN' : 'الوصول',
          day(stay.start),
          dates,
        ),
        field(
          Icons.calendar_today_outlined,
          english ? 'CHECK-OUT' : 'المغادرة',
          day(stay.end),
          dates,
        ),
        field(
          Icons.people_outline,
          english ? 'GUESTS' : 'الضيوف',
          '${stay.guests} ${english ? 'guests' : 'ضيوف'} · ${stay.nights} ${english ? 'nights' : 'ليالٍ'}',
          guests,
        ),
      ];
      final button = FilledButton.icon(
        onPressed: search,
        icon: const Icon(Icons.search, size: 20),
        label: Text(english ? 'Search' : 'بحث'),
      );
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: brandInk),
        ),
        child: wide
            ? Row(
                children: [
                  for (final f in fields) Expanded(child: f),
                  const SizedBox(width: 12),
                  button,
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(10, 4, 10, 12),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.place_outlined,
                          size: 20,
                          color: brand,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            english
                                ? 'Riyadh, Saudi Arabia'
                                : 'الرياض، السعودية',
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Divider(height: 1),
                  Row(
                    children: [
                      Expanded(child: fields[1]),
                      Container(
                        width: 1,
                        height: 36,
                        color: const Color(0xffe2ddd3),
                      ),
                      Expanded(child: fields[2]),
                    ],
                  ),
                  const Divider(height: 1),
                  fields[3],
                  const SizedBox(height: 8),
                  SizedBox(height: 52, child: button),
                ],
              ),
      );
    },
  );
}

class SakanDetails extends StatelessWidget {
  final bool english;
  const SakanDetails({this.english = false, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final wide = c.maxWidth > 680;
      final items = [
        (
          Icons.weekend_outlined,
          english ? 'A space of your own' : 'مساحة لك',
          english
              ? 'Studios and apartments for your kind of stay.'
              : 'استديوهات وشقق تناسب أسلوب إقامتك.',
        ),
        (
          Icons.receipt_long_outlined,
          english ? 'Every detail, clearly' : 'كل التفاصيل واضحة',
          english
              ? 'Review your stay and total before payment.'
              : 'راجع تفاصيل الإقامة والسعر قبل الدفع.',
        ),
        (
          Icons.key_outlined,
          english ? 'Arrive with ease' : 'وصول بكل راحة',
          english
              ? 'Your eligible access details in one place.'
              : 'تعليمات دخول إقامتك في مكان واحد.',
        ),
      ];
      final children = items
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xfff2e8d0),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(item.$1, color: brand, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.$2,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.$3,
                          style: const TextStyle(
                            color: Color(0xff5b6672),
                            fontSize: 12,
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList();
      return wide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children.map((w) => Expanded(child: w)).toList(),
            )
          : Column(children: children);
    },
  );
}

class AdminWelcome extends StatelessWidget {
  final VoidCallback onLogin;
  const AdminWelcome({required this.onLogin, super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: SakanLayout.padding(context),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: LayoutBuilder(
              builder: (context, box) {
                final panel = Container(
                  padding: EdgeInsets.all(box.maxWidth > 700 ? 56 : 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const BrandMark(),
                      const SizedBox(height: 52),
                      const Text(
                        'مساحة الإدارة',
                        style: TextStyle(
                          fontSize: 12,
                          color: gold,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'كل إقامة رائعة،\nتبدأ من هنا.',
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                          color: brand,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'الحجوزات، الوحدات، وفريق التشغيل.\nكل ما تحتاجه لإدارة سكن في مساحة واحدة.',
                        style: TextStyle(color: Color(0xff5b6672), height: 1.9),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: onLogin,
                          icon: const Icon(Icons.arrow_forward, size: 18),
                          label: const Text('تسجيل الدخول للموظفين'),
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Row(
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 14,
                            color: Color(0xff5b6672),
                          ),
                          SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              'وصول مخصص لأعضاء الفريق المصرّح لهم',
                              style: TextStyle(
                                fontSize: 11,
                                color: Color(0xff5b6672),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
                return Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xffe2ddd3)),
                  ),
                  child: box.maxWidth > 700
                      ? Row(
                          children: [
                            Expanded(child: panel),
                            Expanded(
                              child: SizedBox(
                                height: 590,
                                child: Image.network(
                                  photos.first,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, e, s) => Container(
                                    color: brand,
                                    child: const Center(
                                      child: BrandMark(light: true),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : panel,
                );
              },
            ),
          ),
        ),
      ),
    ),
  );
}

class SakanFooter extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore, onBookings, onAccount;
  const SakanFooter({
    required this.english,
    required this.onExplore,
    required this.onBookings,
    required this.onAccount,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Container(
    color: brandInk,
    padding: EdgeInsets.all(MediaQuery.sizeOf(context).width < 600 ? 24 : 48),
    child: LayoutBuilder(
      builder: (context, box) {
        Widget link(String ar, String en, VoidCallback action) => TextButton(
          onPressed: action,
          style: TextButton.styleFrom(
            foregroundColor: Colors.white,
            alignment: AlignmentDirectional.centerStart,
            minimumSize: const Size(44, 48),
          ),
          child: Text(english ? en : ar),
        );
        final cols = box.maxWidth >= 900
            ? 4
            : box.maxWidth >= 550
            ? 2
            : 1;
        final sections = <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const BrandMark(light: true, width: 120),
              const SizedBox(height: 24),
              Text(
                english
                    ? 'Selected stays in Riyadh. A space that feels like you.'
                    : 'إقامات مختارة في الرياض.\nمساحة تشبهك، وتفاصيل تريحك.',
                style: const TextStyle(color: Colors.white, height: 1.9),
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                english ? 'STAYS' : 'الإقامات',
                style: const TextStyle(
                  color: Color(0xfff2e8d0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              link('اكتشف الإقامات', 'Explore stays', onExplore),
              link('أحياء الرياض', 'Riyadh neighbourhoods', onExplore),
              link('خطّط لإقامتك', 'Plan your stay', onExplore),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                english ? 'YOUR STAY' : 'إقامتك',
                style: const TextStyle(
                  color: Color(0xfff2e8d0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              link('حجوزاتي', 'My bookings', onBookings),
              link('تعليمات الوصول', 'Arrival instructions', onBookings),
              link('الدعم المرتبط بالحجز', 'Booking support', onBookings),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                english ? 'SAKN' : 'مع سكن',
                style: const TextStyle(
                  color: Color(0xfff2e8d0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              link('حسابي', 'My account', onAccount),
              link('المساعدة والسياسات', 'Help and policies', onAccount),
              link('اللغة والتفضيلات', 'Language and preferences', onAccount),
            ],
          ),
        ];
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Wrap(
              spacing: 32,
              runSpacing: 32,
              children: [
                for (final item in [
                  (
                    Icons.support_agent,
                    english ? 'Here for your stay' : 'معك في كل خطوة',
                    english
                        ? 'Support from your booking or account'
                        : 'تواصل مع الدعم من حجزك أو حسابك',
                  ),
                  (
                    Icons.business_center_outlined,
                    english ? 'Make room for your plans' : 'مساحة تناسب خططك',
                    english
                        ? 'Choose your dates and compare available stays'
                        : 'اختر مدة إقامتك وقارن الخيارات المتاحة',
                  ),
                  (
                    Icons.phone_iphone,
                    english ? 'Always within reach' : 'سكن معك أينما كنت',
                    english
                        ? 'Your bookings from your mobile browser'
                        : 'كل تفاصيل حجوزاتك من متصفح الجوال',
                  ),
                ])
                  SizedBox(
                    width: box.maxWidth >= 800
                        ? (box.maxWidth - 64) / 3
                        : box.maxWidth,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(item.$1, color: Colors.white),
                        const SizedBox(height: 12),
                        Text(
                          item.$2,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          item.$3,
                          style: const TextStyle(
                            color: Color(0xffc6ccd1),
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 40),
            const Divider(color: Color(0xff45525e)),
            const SizedBox(height: 40),
            Wrap(
              spacing: 24,
              runSpacing: 32,
              children: sections
                  .map(
                    (w) => SizedBox(
                      width: (box.maxWidth - (cols - 1) * 24) / cols,
                      child: w,
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 40),
            const Divider(color: Color(0xff45525e)),
            const SizedBox(height: 20),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: AppDownloadButtons(),
              ),
            ),
            const SizedBox(height: 20),
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              spacing: 24,
              runSpacing: 12,
              children: [
                Text(
                  '© ${DateTime.now().year} SAKN · سكن',
                  style: const TextStyle(color: Colors.white),
                ),
                Text(
                  english
                      ? 'Riyadh, Saudi Arabia · SAR'
                      : 'الرياض، المملكة العربية السعودية · ر.س',
                  style: const TextStyle(color: Color(0xffc6ccd1)),
                ),
              ],
            ),
          ],
        );
      },
    ),
  );
}

/// An editorial guide using existing booking actions, with no invented metrics.
class StayJourney extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore;
  const StayJourney({
    required this.english,
    required this.onExplore,
    super.key,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final copy = Padding(
        padding: EdgeInsets.all(wide ? 40 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              english
                  ? 'MAKE YOURSELF AT HOME'
                  : 'من أول اختيار، إلى لحظة الوصول',
              style: const TextStyle(color: Color(0xff9b4827), fontSize: 12),
            ),
            const SizedBox(height: 16),
            Text(
              english
                  ? 'Less planning.\nMore living.'
                  : 'خطوات بسيطة.\nوإقامة على راحتك.',
              style: TextStyle(
                fontSize: wide ? 32 : 26,
                height: 1.5,
                color: brand,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 24),
            for (final step in [
              (
                '01',
                english ? 'Choose your dates' : 'حدّد وقتك',
                english
                    ? 'Set your arrival, departure and guests.'
                    : 'اختر تواريخ الوصول والمغادرة وعدد الضيوف.',
              ),
              (
                '02',
                english ? 'Find your space' : 'اختر مساحتك',
                english
                    ? 'Explore photos, amenities and prices.'
                    : 'تعرّف على الصور والمرافق وتفاصيل السعر.',
              ),
              (
                '03',
                english ? 'Keep everything close' : 'كل تفاصيلك معك',
                english
                    ? 'Follow your reservation in My bookings.'
                    : 'تابع حجزك وتفاصيل إقامتك من «حجوزاتي».',
              ),
            ])
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      step.$1,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Color(0xff9b4827),
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            step.$2,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            step.$3,
                            style: const TextStyle(
                              fontSize: 13,
                              height: 1.7,
                              color: Color(0xff5b6672),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            TextButton.icon(
              onPressed: onExplore,
              label: Text(english ? 'Explore stays' : 'اكتشف الإقامات'),
              icon: const Icon(Icons.arrow_forward, size: 18),
            ),
          ],
        ),
      );
      final image = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          children: [
            Image.network(
              photos[1],
              width: double.infinity,
              height: wide ? 560 : 240,
              fit: BoxFit.cover,
              errorBuilder: (_, e, s) => SizedBox(
                height: wide ? 560 : 240,
                child: const ColoredBox(
                  color: brand,
                  child: Center(child: BrandMark(light: true)),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                color: const Color(0xaa213b51),
                child: Text(
                  english ? 'Illustrative image' : 'صورة تعبيرية',
                  style: const TextStyle(color: Colors.white, fontSize: 10),
                ),
              ),
            ),
          ],
        ),
      );
      return Container(
        decoration: BoxDecoration(
          color: const Color(0xfff2e8d0),
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.all(8),
        child: wide
            ? Row(
                children: [
                  Expanded(child: copy),
                  Expanded(child: image),
                ],
              )
            : Column(children: [copy, image]),
      );
    },
  );
}
