import '../ui/system.dart';
import 'package:flutter/material.dart';
import '../core/models.dart';

/// Original Sakan artwork supplied by the owner; never mirrored in RTL layouts.
class BrandMark extends StatelessWidget {
  final bool light;
  final double width;
  const BrandMark({this.light = false, this.width = 124, super.key});
  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/brand/logo-${light ? "light" : "dark"}.png',
    width: width,
    height: width * 106 / 280,
    fit: BoxFit.contain,
    matchTextDirection: false,
    semanticLabel: 'سكن',
  );
}

/// Responsive introduction from the November design handoff.
class EditorialHero extends StatelessWidget {
  final bool english, welcome;
  final String? heading;
  final VoidCallback? onStart;
  const EditorialHero({
    this.english = false,
    this.welcome = false,
    this.heading,
    this.onStart,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 800;
      final title = Text.rich(
        TextSpan(
          children: [
            TextSpan(
              text:
                  heading ??
                  (english ? 'Your comfortable place, ' : 'مكانك المريح، '),
            ),
            if (heading == null)
              TextSpan(
                text: english
                    ? 'ready before you arrive.'
                    : 'محجوز قبل ما توصل.',
                style: const TextStyle(
                  color: brand,
                  fontWeight: FontWeight.w400,
                ),
              ),
          ],
        ),
        style: TextStyle(
          fontSize: wide ? (box.maxWidth * .056).clamp(44, 72) : 36,
          fontWeight: FontWeight.w300,
          height: 1.2,
          color: brandInk,
        ),
      );
      final copy = Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            english
                ? 'Furnished apartments and studios in Riyadh. Choose your dates, with every detail clear before you book.'
                : 'شقق واستوديوهات مفروشة في الرياض. اختر تواريخك وكل التفاصيل واضحة قبل الحجز.',
            style: TextStyle(
              fontSize: wide ? 17 : 15,
              height: 1.8,
              color: muted,
            ),
          ),
          if (onStart != null)
            Padding(
              padding: const EdgeInsets.only(top: 20),
              child: FilledButton.icon(
                onPressed: onStart,
                icon: const Icon(Icons.arrow_forward),
                label: Text(english ? 'Explore stays' : 'اكتشف الإقامات'),
              ),
            ),
        ],
      );
      return Padding(
        padding: EdgeInsets.only(top: wide ? 52 : 24, bottom: wide ? 36 : 24),
        child: wide
            ? Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(flex: 2, child: title),
                  const SizedBox(width: 48),
                  Expanded(child: copy),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [title, const SizedBox(height: 16), copy],
              ),
      );
    },
  );
}

class StaySearch extends StatelessWidget {
  final Stay stay;
  final bool english;
  final VoidCallback dates, guests, search;
  const StaySearch({
    required this.stay,
    required this.english,
    required this.dates,
    required this.guests,
    required this.search,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 900;
      Widget field(
        IconData icon,
        String label,
        String value,
        VoidCallback? onTap,
      ) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              children: [
                Icon(icon, size: 22, color: brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(fontSize: 12, color: muted),
                      ),
                      Text(
                        value,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
                if (onTap != null)
                  const Icon(Icons.expand_more, size: 18, color: muted),
              ],
            ),
          ),
        ),
      );
      String day(DateTime d) => '${d.day} / ${d.month}';
      final destination = field(
        Icons.location_on_outlined,
        english ? 'Destination' : 'الوجهة',
        english ? 'Riyadh, Saudi Arabia' : 'الرياض، السعودية',
        null,
      );
      final date = field(
        Icons.calendar_month_outlined,
        english ? 'Arrival — departure' : 'الوصول — المغادرة',
        '${day(stay.start)}  —  ${day(stay.end)}',
        dates,
      );
      final guest = field(
        Icons.people_outline,
        english ? 'Guests' : 'الضيوف',
        '${stay.guests} ${english ? 'guests' : 'ضيوف'} · ${stay.nights} ${english ? 'nights' : 'ليالٍ'}',
        guests,
      );
      final button = FilledButton.icon(
        onPressed: search,
        icon: const Icon(Icons.search, size: 22),
        label: Text(english ? 'Find a stay' : 'ابحث عن إقامة'),
      );
      return Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: surface,
          border: Border.all(color: const Color(0xffe1d4b6)),
          borderRadius: BorderRadius.circular(20),
        ),
        child: wide
            ? Row(
                children: [
                  Expanded(child: destination),
                  Expanded(flex: 2, child: date),
                  Expanded(child: guest),
                  SizedBox(height: 64, child: button),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  destination,
                  const Divider(height: 1),
                  date,
                  const Divider(height: 1),
                  guest,
                  const SizedBox(height: 8),
                  SizedBox(height: 52, child: button),
                ],
              ),
      );
    },
  );
}

class ArrivalBanner extends StatelessWidget {
  final bool english;
  const ArrivalBanner({this.english = false, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final title = Text(
        english
            ? 'Your stay, ready for your arrival.'
            : 'إقامتك جاهزة. وكل التفاصيل معك.',
        style: TextStyle(
          color: Colors.white,
          fontSize: wide ? 32 : 24,
          fontWeight: FontWeight.w300,
          height: 1.4,
        ),
      );
      final description = Text(
        english
            ? 'Clear arrival instructions and support throughout your stay.'
            : 'دخول ذاتي، تعليمات واضحة قبل وصولك، وتواصل مباشر مع فريق سكن طوال الإقامة.',
        style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.8),
      );
      return Container(
        padding: EdgeInsets.all(wide ? 36 : 24),
        decoration: BoxDecoration(
          color: brand,
          borderRadius: BorderRadius.circular(24),
        ),
        child: wide
            ? Row(
                children: [
                  Expanded(flex: 2, child: title),
                  const SizedBox(width: 40),
                  Expanded(child: description),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [title, const SizedBox(height: 16), description],
              ),
      );
    },
  );
}

class SakanDetails extends StatelessWidget {
  final bool english;
  const SakanDetails({this.english = false, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final wide = c.maxWidth > 680;
      final items = [
        (
          Icons.weekend_outlined,
          english ? 'A space of your own' : 'مساحة لك',
          english
              ? 'Studios and apartments for your kind of stay.'
              : 'استديوهات وشقق تناسب أسلوب إقامتك.',
        ),
        (
          Icons.receipt_long_outlined,
          english ? 'Every detail, clearly' : 'كل التفاصيل واضحة',
          english
              ? 'Review your stay and total before payment.'
              : 'راجع تفاصيل الإقامة والسعر قبل الدفع.',
        ),
        (
          Icons.key_outlined,
          english ? 'Arrive with ease' : 'وصول بكل راحة',
          english
              ? 'Your eligible access details in one place.'
              : 'تعليمات دخول إقامتك في مكان واحد.',
        ),
      ];
      final children = items
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xfff2e8d0),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(item.$1, color: brand, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.$2,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.$3,
                          style: const TextStyle(
                            color: Color(0xff5b6670),
                            fontSize: 12,
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList();
      return wide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children.map((w) => Expanded(child: w)).toList(),
            )
          : Column(children: children);
    },
  );
}

class AdminWelcome extends StatelessWidget {
  final VoidCallback onLogin;
  const AdminWelcome({required this.onLogin, super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: SakanLayout.padding(context),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: LayoutBuilder(
              builder: (context, box) {
                final panel = Container(
                  padding: EdgeInsets.all(box.maxWidth > 700 ? 56 : 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const BrandMark(),
                      const SizedBox(height: 52),
                      const Text(
                        'مساحة الإدارة',
                        style: TextStyle(
                          fontSize: 12,
                          color: gold,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'كل إقامة رائعة،\nتبدأ من هنا.',
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                          color: brand,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'الحجوزات، الوحدات، وفريق التشغيل.\nكل ما تحتاجه لإدارة سكن في مساحة واحدة.',
                        style: TextStyle(color: Color(0xff5b6670), height: 1.9),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: onLogin,
                          icon: const Icon(Icons.arrow_forward, size: 18),
                          label: const Text('تسجيل الدخول للموظفين'),
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Row(
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 14,
                            color: Color(0xff5b6670),
                          ),
                          SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              'وصول مخصص لأعضاء الفريق المصرّح لهم',
                              style: TextStyle(
                                fontSize: 11,
                                color: Color(0xff5b6670),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
                return Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xffe9dfc9)),
                  ),
                  child: box.maxWidth > 700
                      ? Row(
                          children: [
                            Expanded(child: panel),
                            Expanded(
                              child: SizedBox(
                                height: 590,
                                child: Image.network(
                                  photos.first,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, e, s) => Container(
                                    color: brand,
                                    child: const Center(
                                      child: BrandMark(light: true),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : panel,
                );
              },
            ),
          ),
        ),
      ),
    ),
  );
}

class SakanFooter extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore, onBookings, onAccount;
  const SakanFooter({
    required this.english,
    required this.onExplore,
    required this.onBookings,
    required this.onAccount,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Container(
    color: brandInk,
    padding: EdgeInsets.symmetric(
      horizontal: MediaQuery.sizeOf(context).width < 600 ? 20 : 32,
      vertical: 40,
    ),
    child: LayoutBuilder(
      builder: (context, box) {
        Widget link(String ar, String en, VoidCallback tap) => Align(
          alignment: AlignmentDirectional.centerStart,
          child: TextButton(
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
              padding: EdgeInsets.zero,
              alignment: AlignmentDirectional.centerStart,
            ),
            onPressed: tap,
            child: Text(english ? en : ar),
          ),
        );
        final intro = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const BrandMark(light: true, width: 124),
            const SizedBox(height: 16),
            Text(
              english
                  ? 'Selected furnished stays in Riyadh, for short visits and longer stays.'
                  : 'منصة حجز وتأجير لمساكن مختارة بعناية في الرياض — للإقامة القصيرة والطويلة.',
              style: const TextStyle(
                color: Color(0xffd9dee3),
                fontSize: 14,
                height: 1.8,
              ),
            ),
          ],
        );
        final links = Wrap(
          spacing: 40,
          runSpacing: 24,
          children: [
            SizedBox(
              width: 150,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    english ? 'Stays' : 'الإقامات',
                    style: const TextStyle(color: brandCream, fontSize: 13),
                  ),
                  link('كل الإقامات', 'Explore stays', onExplore),
                  link('حجوزاتي', 'My bookings', onBookings),
                ],
              ),
            ),
            SizedBox(
              width: 170,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    english ? 'Help & account' : 'المساعدة وحسابك',
                    style: const TextStyle(color: brandCream, fontSize: 13),
                  ),
                  link('حسابي', 'My account', onAccount),
                  link('المساعدة والسياسات', 'Help and policies', onAccount),
                  link(
                    'اللغة والتفضيلات',
                    'Language and preferences',
                    onAccount,
                  ),
                ],
              ),
            ),
          ],
        );
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (box.maxWidth >= 800)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(width: 320, child: intro),
                  const SizedBox(width: 56),
                  Expanded(child: links),
                ],
              )
            else ...[
              intro,
              const SizedBox(height: 28),
              links,
            ],
            const SizedBox(height: 28),
            const Divider(color: Color(0xff34475a)),
            const SizedBox(height: 16),
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              spacing: 20,
              runSpacing: 12,
              children: [
                Text(
                  '© ${DateTime.now().year} سكن',
                  style: const TextStyle(
                    color: Color(0xffd9dee3),
                    fontSize: 13,
                  ),
                ),
                const Text(
                  'SAKN.CO',
                  style: TextStyle(
                    color: Color(0xffd9dee3),
                    fontSize: 13,
                    letterSpacing: 3,
                  ),
                ),
              ],
            ),
          ],
        );
      },
    ),
  );
}

class MonthlyStayCard extends StatelessWidget {
  final VoidCallback onContact;
  final bool english;
  const MonthlyStayCard({
    required this.onContact,
    this.english = false,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(28),
    decoration: BoxDecoration(
      color: brandCream,
      borderRadius: BorderRadius.circular(24),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          english ? 'MONTHLY STAYS' : 'إقامات شهرية',
          style: const TextStyle(fontSize: 12, color: muted),
        ),
        const SizedBox(height: 12),
        Text(
          english ? 'Stay longer. Feel at home.' : 'إقامة أطول، بنفس الهدوء.',
          style: const TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.w300,
            height: 1.3,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          english
              ? 'Find a space that fits your longer stay. Contact our team for availability and details.'
              : 'مساحة تناسب إقامتك الطويلة. تواصل مع الفريق لمعرفة التوافر والتفاصيل.',
          style: const TextStyle(color: muted),
        ),
        const SizedBox(height: 20),
        OutlinedButton(
          onPressed: onContact,
          child: Text(
            english ? 'Ask about monthly stays' : 'تواصل معنا للإقامة الشهرية',
          ),
        ),
      ],
    ),
  );
}

/// An editorial guide using existing booking actions, with no invented metrics.
class StayJourney extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore;
  const StayJourney({
    required this.english,
    required this.onExplore,
    super.key,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final copy = Padding(
        padding: EdgeInsets.all(wide ? 40 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              english
                  ? 'MAKE YOURSELF AT HOME'
                  : 'من أول اختيار، إلى لحظة الوصول',
              style: const TextStyle(color: Color(0xff9b4827), fontSize: 12),
            ),
            const SizedBox(height: 16),
            Text(
              english
                  ? 'Less planning.\nMore living.'
                  : 'خطوات بسيطة.\nوإقامة على راحتك.',
              style: TextStyle(
                fontSize: wide ? 32 : 26,
                height: 1.5,
                color: brand,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 24),
            for (final step in [
              (
                '01',
                english ? 'Choose your dates' : 'حدّد وقتك',
                english
                    ? 'Set your arrival, departure and guests.'
                    : 'اختر تواريخ الوصول والمغادرة وعدد الضيوف.',
              ),
              (
                '02',
                english ? 'Find your space' : 'اختر مساحتك',
                english
                    ? 'Explore photos, amenities and prices.'
                    : 'تعرّف على الصور والمرافق وتفاصيل السعر.',
              ),
              (
                '03',
                english ? 'Keep everything close' : 'كل تفاصيلك معك',
                english
                    ? 'Follow your reservation in My bookings.'
                    : 'تابع حجزك وتفاصيل إقامتك من «حجوزاتي».',
              ),
            ])
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      step.$1,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Color(0xff9b4827),
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            step.$2,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            step.$3,
                            style: const TextStyle(
                              fontSize: 13,
                              height: 1.7,
                              color: Color(0xff5b6670),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            TextButton.icon(
              onPressed: onExplore,
              label: Text(english ? 'Explore stays' : 'اكتشف الإقامات'),
              icon: const Icon(Icons.arrow_forward, size: 18),
            ),
          ],
        ),
      );
      final image = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          children: [
            Image.network(
              photos[1],
              width: double.infinity,
              height: wide ? 560 : 240,
              fit: BoxFit.cover,
              errorBuilder: (_, e, s) => SizedBox(
                height: wide ? 560 : 240,
                child: const ColoredBox(
                  color: brand,
                  child: Center(child: BrandMark(light: true)),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                color: const Color(0xaa213b51),
                child: Text(
                  english ? 'Illustrative image' : 'صورة تعبيرية',
                  style: const TextStyle(color: Colors.white, fontSize: 10),
                ),
              ),
            ),
          ],
        ),
      );
      return Container(
        decoration: BoxDecoration(
          color: const Color(0xfff2e8d0),
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.all(8),
        child: wide
            ? Row(
                children: [
                  Expanded(child: copy),
                  Expanded(child: image),
                ],
              )
            : Column(children: [copy, image]),
      );
    },
  );
}

class SearchSummary extends StatelessWidget {
  final Stay stay;
  final VoidCallback dates, guests;
  const SearchSummary({
    required this.stay,
    required this.dates,
    required this.guests,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(8),
    decoration: BoxDecoration(
      color: surface,
      border: Border.all(color: outline),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      children: [
        Expanded(
          child: TextButton.icon(
            onPressed: dates,
            icon: const Icon(Icons.search, color: brand),
            label: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'الرياض',
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  Text(
                    '${stay.start.day}/${stay.start.month} — ${stay.end.day}/${stay.end.month} · ${stay.nights} ليالٍ',
                    style: const TextStyle(fontSize: 12, color: muted),
                  ),
                ],
              ),
            ),
          ),
        ),
        TextButton(onPressed: guests, child: Text('${stay.guests} ضيوف')),
      ],
    ),
  );
}
