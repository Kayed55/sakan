import '../ui/system.dart';
import 'package:flutter/material.dart';
import '../core/models.dart';

/// Original Sakan artwork supplied by the owner; never mirrored in RTL layouts.
class BrandMark extends StatelessWidget {
  final bool light;
  final double width;
  const BrandMark({this.light = false, this.width = 124, super.key});
  @override
  Widget build(BuildContext context) => Image.asset(
    'assets/brand/logo-${light ? "light" : "dark"}.png',
    width: width,
    height: width * 66 / 186,
    fit: BoxFit.contain,
    matchTextDirection: false,
    semanticLabel: 'سكن',
  );
}

/// Photography-led introduction, with an opaque text scrim for legibility.
class EditorialHero extends StatelessWidget {
  final bool english;
  final bool welcome;
  final String? heading;
  final VoidCallback? onStart;
  const EditorialHero({
    this.english = false,
    this.welcome = false,
    this.heading,
    this.onStart,
    super.key,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final rtl = Directionality.of(context) == TextDirection.rtl;
      return ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.network(
                photos.first,
                fit: BoxFit.cover,
                alignment: const Alignment(-.35, 0),
                errorBuilder: (_, e, s) => const ColoredBox(color: brand),
              ),
            ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: rtl ? Alignment.centerRight : Alignment.centerLeft,
                    end: rtl ? Alignment.centerLeft : Alignment.centerRight,
                    colors: wide
                        ? const [
                            Color(0xf01a3027),
                            Color(0xd91a3027),
                            Color(0x161a3027),
                          ]
                        : const [
                            Color(0xeb1a3027),
                            Color(0xc91a3027),
                            Color(0x801a3027),
                          ],
                    stops: const [0, .46, 1],
                  ),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(
                horizontal: wide ? 56 : 24,
                vertical: wide ? 58 : 36,
              ),
              child: Align(
                alignment: AlignmentDirectional.centerStart,
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: wide ? 590 : 540),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 26,
                            height: 1,
                            color: const Color(0xffd9c7a5),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              english ? 'SAKAN • RIYADH' : 'سكن • الرياض',
                              style: const TextStyle(
                                color: Color(0xffe9d9bc),
                                fontSize: 13,
                                letterSpacing: 2,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 22),
                      Text(
                        heading ??
                            (english
                                ? 'A stay that feels\nlike you.'
                                : 'لك في الرياض،\nمكان يشبهك.'),
                        style: TextStyle(
                          fontSize: wide ? 52 : (box.maxWidth < 350 ? 30 : 37),
                          height: 1.45,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 18),
                      Text(
                        english
                            ? 'Discover your space. Settle into your own rhythm.'
                            : 'اختر مساحتك، واستمتع بإقامة على راحتك.\nشقق واستديوهات لتفاصيل يومك في الرياض.',
                        style: const TextStyle(
                          fontSize: 15,
                          height: 1.9,
                          color: Color(0xffe4e9e4),
                        ),
                      ),
                      const SizedBox(height: 28),
                      if (onStart != null)
                        FilledButton.icon(
                          onPressed: onStart,
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xffeadcc3),
                            foregroundColor: brand,
                          ),
                          icon: const Icon(Icons.arrow_forward, size: 18),
                          label: Text(
                            english ? 'Find your stay' : 'اكتشف إقامتك',
                          ),
                        )
                      else
                        Row(
                          children: [
                            const Icon(
                              Icons.location_on_outlined,
                              size: 17,
                              color: Color(0xffe9d9bc),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                english
                                    ? 'Riyadh, Saudi Arabia'
                                    : 'الرياض، المملكة العربية السعودية',
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 18,
              child: Text(
                english ? 'Illustrative image' : 'صورة تعبيرية',
                style: const TextStyle(fontSize: 10, color: Colors.white70),
              ),
            ),
          ],
        ),
      );
    },
  );
}

class StaySearch extends StatelessWidget {
  final Stay stay;
  final bool english;
  final VoidCallback dates, guests, search;
  const StaySearch({
    required this.stay,
    required this.english,
    required this.dates,
    required this.guests,
    required this.search,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth > 760;
      Widget field(
        IconData icon,
        String label,
        String value,
        VoidCallback? tap,
      ) => Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: tap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
            child: Row(
              children: [
                Icon(icon, size: 21, color: brand),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(
                          fontSize: 11,
                          color: Color(0xff7b8079),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        value,
                        style: const TextStyle(
                          fontSize: 13,
                          color: brand,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                if (tap != null)
                  const Icon(Icons.keyboard_arrow_down, size: 16, color: brand),
              ],
            ),
          ),
        ),
      );
      String day(DateTime date) => '${date.day} / ${date.month}';
      final fields = [
        field(
          Icons.place_outlined,
          english ? 'DESTINATION' : 'الوجهة',
          english ? 'Riyadh, Saudi Arabia' : 'الرياض، السعودية',
          null,
        ),
        field(
          Icons.calendar_today_outlined,
          english ? 'CHECK-IN — CHECK-OUT' : 'الوصول — المغادرة',
          '${day(stay.start)}  —  ${day(stay.end)}',
          dates,
        ),
        field(
          Icons.people_outline,
          english ? 'GUESTS' : 'الضيوف',
          '${stay.guests} ${english ? 'guests' : 'ضيوف'} · ${stay.nights} ${english ? 'nights' : 'ليالٍ'}',
          guests,
        ),
      ];
      final button = FilledButton.icon(
        onPressed: search,
        icon: const Icon(Icons.search, size: 20),
        label: Text(english ? 'Find your stay' : 'ابحث عن إقامتك'),
      );
      return Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xffe8e5dc)),
          boxShadow: const [
            BoxShadow(
              color: Color(0x08233b30),
              blurRadius: 24,
              offset: Offset(0, 10),
            ),
          ],
        ),
        child: wide
            ? Row(
                children: [
                  for (final f in fields) Expanded(child: f),
                  const SizedBox(width: 12),
                  button,
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  fields[0],
                  const Divider(height: 1),
                  fields[1],
                  const Divider(height: 1),
                  fields[2],
                  const SizedBox(height: 8),
                  button,
                ],
              ),
      );
    },
  );
}

class SakanDetails extends StatelessWidget {
  final bool english;
  const SakanDetails({this.english = false, super.key});
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, c) {
      final wide = c.maxWidth > 680;
      final items = [
        (
          Icons.weekend_outlined,
          english ? 'A space of your own' : 'مساحة لك',
          english
              ? 'Studios and apartments for your kind of stay.'
              : 'استديوهات وشقق تناسب أسلوب إقامتك.',
        ),
        (
          Icons.receipt_long_outlined,
          english ? 'Every detail, clearly' : 'كل التفاصيل واضحة',
          english
              ? 'Review your stay and total before payment.'
              : 'راجع تفاصيل الإقامة والسعر قبل الدفع.',
        ),
        (
          Icons.key_outlined,
          english ? 'Arrive with ease' : 'وصول بكل راحة',
          english
              ? 'Your eligible access details in one place.'
              : 'تعليمات دخول إقامتك في مكان واحد.',
        ),
      ];
      final children = items
          .map(
            (item) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xffeeeee5),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(item.$1, color: brand, size: 22),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item.$2,
                          style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          item.$3,
                          style: const TextStyle(
                            color: Color(0xff777e76),
                            fontSize: 12,
                            height: 1.7,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList();
      return wide
          ? Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children.map((w) => Expanded(child: w)).toList(),
            )
          : Column(children: children);
    },
  );
}

class AdminWelcome extends StatelessWidget {
  final VoidCallback onLogin;
  const AdminWelcome({required this.onLogin, super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: SakanLayout.padding(context),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1050),
            child: LayoutBuilder(
              builder: (context, box) {
                final panel = Container(
                  padding: EdgeInsets.all(box.maxWidth > 700 ? 56 : 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const BrandMark(),
                      const SizedBox(height: 52),
                      const Text(
                        'مساحة الإدارة',
                        style: TextStyle(
                          fontSize: 12,
                          color: gold,
                          letterSpacing: 2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'كل إقامة رائعة،\nتبدأ من هنا.',
                        style: TextStyle(
                          fontSize: 34,
                          fontWeight: FontWeight.w600,
                          height: 1.5,
                          color: brand,
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Text(
                        'الحجوزات، الوحدات، وفريق التشغيل.\nكل ما تحتاجه لإدارة سكن في مساحة واحدة.',
                        style: TextStyle(color: Color(0xff737b72), height: 1.9),
                      ),
                      const SizedBox(height: 34),
                      SizedBox(
                        width: double.infinity,
                        child: FilledButton.icon(
                          onPressed: onLogin,
                          icon: const Icon(Icons.arrow_forward, size: 18),
                          label: const Text('تسجيل الدخول للموظفين'),
                        ),
                      ),
                      const SizedBox(height: 18),
                      const Row(
                        children: [
                          Icon(
                            Icons.lock_outline,
                            size: 14,
                            color: Color(0xff7b8079),
                          ),
                          SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              'وصول مخصص لأعضاء الفريق المصرّح لهم',
                              style: TextStyle(
                                fontSize: 11,
                                color: Color(0xff7b8079),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
                return Container(
                  clipBehavior: Clip.antiAlias,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(28),
                    border: Border.all(color: const Color(0xffe7e5dc)),
                  ),
                  child: box.maxWidth > 700
                      ? Row(
                          children: [
                            Expanded(child: panel),
                            Expanded(
                              child: SizedBox(
                                height: 590,
                                child: Image.network(
                                  photos.first,
                                  fit: BoxFit.cover,
                                  errorBuilder: (_, e, s) => Container(
                                    color: brand,
                                    child: const Center(
                                      child: BrandMark(light: true),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : panel,
                );
              },
            ),
          ),
        ),
      ),
    ),
  );
}

/// A distinct closing section using the existing brand and navigation actions.
class SakanFooter extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore;
  final VoidCallback onBookings;
  final VoidCallback onAccount;
  const SakanFooter({
    required this.english,
    required this.onExplore,
    required this.onBookings,
    required this.onAccount,
    super.key,
  });

  @override
  Widget build(BuildContext context) => Container(
    padding: EdgeInsets.symmetric(
      horizontal: MediaQuery.sizeOf(context).width >= 760 ? 40 : 24,
      vertical: 36,
    ),
    decoration: BoxDecoration(
      color: brand,
      borderRadius: BorderRadius.circular(18),
    ),
    child: LayoutBuilder(
      builder: (context, box) {
        final identity = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const BrandMark(light: true, width: 110),
            const SizedBox(height: 16),
            Text(
              english ? 'Your stay, your way.' : 'إقامتك، على ذوقك.',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              english
                  ? 'Riyadh, Saudi Arabia'
                  : 'الرياض، المملكة العربية السعودية',
              style: const TextStyle(color: Color(0xffdce5dc), fontSize: 13),
            ),
          ],
        );
        final links = Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final item in [
              (english ? 'Explore stays' : 'اكتشف الإقامات', onExplore),
              (english ? 'My bookings' : 'حجوزاتي', onBookings),
              (english ? 'My account' : 'حسابي', onAccount),
            ])
              TextButton(
                onPressed: item.$2,
                style: TextButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Colors.transparent,
                  minimumSize: const Size(48, 48),
                ),
                child: Text(item.$1),
              ),
          ],
        );
        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (box.maxWidth >= 760)
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: identity),
                  const SizedBox(width: 32),
                  Flexible(child: links),
                ],
              )
            else ...[
              identity,
              const SizedBox(height: 24),
              links,
            ],
            const SizedBox(height: 28),
            const Divider(color: Color(0xff587464)),
            const SizedBox(height: 12),
            Text(
              english ? 'Sakan · A place to feel at home' : 'سكن · مساحة تشبهك',
              style: const TextStyle(color: Color(0xffd9c8aa), fontSize: 12),
            ),
          ],
        );
      },
    ),
  );
}

/// An editorial guide using existing booking actions, with no invented metrics.
class StayJourney extends StatelessWidget {
  final bool english;
  final VoidCallback onExplore;
  const StayJourney({
    required this.english,
    required this.onExplore,
    super.key,
  });

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      final wide = box.maxWidth >= 760;
      final copy = Padding(
        padding: EdgeInsets.all(wide ? 40 : 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              english
                  ? 'MAKE YOURSELF AT HOME'
                  : 'من أول اختيار، إلى لحظة الوصول',
              style: const TextStyle(color: Color(0xff786441), fontSize: 12),
            ),
            const SizedBox(height: 16),
            Text(
              english
                  ? 'Less planning.\nMore living.'
                  : 'خطوات بسيطة.\nوإقامة على راحتك.',
              style: TextStyle(
                fontSize: wide ? 32 : 26,
                height: 1.5,
                color: brand,
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 24),
            for (final step in [
              (
                '01',
                english ? 'Choose your dates' : 'حدّد وقتك',
                english
                    ? 'Set your arrival, departure and guests.'
                    : 'اختر تواريخ الوصول والمغادرة وعدد الضيوف.',
              ),
              (
                '02',
                english ? 'Find your space' : 'اختر مساحتك',
                english
                    ? 'Explore photos, amenities and prices.'
                    : 'تعرّف على الصور والمرافق وتفاصيل السعر.',
              ),
              (
                '03',
                english ? 'Keep everything close' : 'كل تفاصيلك معك',
                english
                    ? 'Follow your reservation in My bookings.'
                    : 'تابع حجزك وتفاصيل إقامتك من «حجوزاتي».',
              ),
            ])
              Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      step.$1,
                      style: const TextStyle(
                        fontSize: 14,
                        color: Color(0xff897653),
                      ),
                    ),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            step.$2,
                            style: const TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 5),
                          Text(
                            step.$3,
                            style: const TextStyle(
                              fontSize: 13,
                              height: 1.7,
                              color: Color(0xff5d685f),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            TextButton.icon(
              onPressed: onExplore,
              label: Text(english ? 'Explore stays' : 'اكتشف الإقامات'),
              icon: const Icon(Icons.arrow_forward, size: 18),
            ),
          ],
        ),
      );
      final image = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          children: [
            Image.network(
              photos[1],
              width: double.infinity,
              height: wide ? 560 : 240,
              fit: BoxFit.cover,
              errorBuilder: (_, e, s) => SizedBox(
                height: wide ? 560 : 240,
                child: const ColoredBox(
                  color: brand,
                  child: Center(child: BrandMark(light: true)),
                ),
              ),
            ),
            Positioned(
              bottom: 12,
              left: 12,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                color: const Color(0xaa1a3027),
                child: Text(
                  english ? 'Illustrative image' : 'صورة تعبيرية',
                  style: const TextStyle(color: Colors.white, fontSize: 10),
                ),
              ),
            ),
          ],
        ),
      );
      return Container(
        decoration: BoxDecoration(
          color: const Color(0xfff0eee6),
          borderRadius: BorderRadius.circular(18),
        ),
        padding: const EdgeInsets.all(8),
        child: wide
            ? Row(
                children: [
                  Expanded(child: copy),
                  Expanded(child: image),
                ],
              )
            : Column(children: [copy, image]),
      );
    },
  );
}
