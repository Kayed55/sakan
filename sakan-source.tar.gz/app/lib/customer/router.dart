import 'package:flutter/material.dart';
import '../core/routes.dart';
import '../core/models.dart';
import '../core/repository.dart';
import 'app.dart';
import 'auth.dart';
import 'booking.dart';
import '../chat/chat.dart';

const homePaths = [
  '/',
  '/search',
  '/map',
  '/favorites',
  '/bookings',
  '/account',
  '/account/details',
  '/account/payments',
  '/account/notifications',
  '/account/invoices',
];
GoRouter customerRouter(
  SakanRepository repo,
  bool Function() english,
  VoidCallback language, {
  String? initialLocation,
}) {
  GoRouter.optionURLReflectsImperativeAPIs = true;
  return GoRouter(
    initialLocation: initialLocation,
    errorBuilder: (_, s) => const RouteFailure(),
    routes: [
      for (final path in homePaths)
        GoRoute(
          path: path,
          pageBuilder: (context, state) => NoTransitionPage(
            key: const ValueKey('customer-home'),
            child: HomeShell(
              repo: repo,
              english: english(),
              onLanguage: language,
              location: state.uri,
            ),
          ),
        ),
      GoRoute(path: '/login', builder: (_, s) => LoginPage(repo)),
      GoRoute(
        path: '/notifications',
        builder: (_, s) =>
            CustomerGuard(repo: repo, builder: () => NotificationsPage(repo)),
      ),
      GoRoute(
        path: '/account/profile',
        builder: (_, s) =>
            CustomerGuard(repo: repo, builder: () => ProfilePage(repo)),
      ),
      GoRoute(
        path: '/units/:id',
        builder: (context, state) => unitRoute(repo, state, english(), false),
      ),
      GoRoute(
        path: '/checkout/:id',
        builder: (context, state) =>
            state.uri.queryParameters.containsKey('booking') ||
                state.uri.queryParameters['stage'] == 'guest'
            ? CustomerGuard(
                repo: repo,
                builder: () => unitRoute(repo, state, english(), true),
              )
            : unitRoute(repo, state, english(), true),
      ),
      GoRoute(
        path: '/bookings/:id',
        builder: (_, state) => CustomerGuard(
          repo: repo,
          builder: () => bookingRoute(repo, state, false),
        ),
      ),
      GoRoute(
        path: '/bookings/:id/chat',
        builder: (_, state) => CustomerGuard(
          repo: repo,
          builder: () => bookingRoute(repo, state, true),
        ),
      ),
    ],
  );
}

Widget unitRoute(
  SakanRepository repo,
  GoRouterState state,
  bool english,
  bool checkout,
) {
  late Stay stay;
  try {
    stay = stayFromUri(state.uri);
  } catch (_) {
    return const RouteFailure(
      'تواريخ الإقامة أو عدد الضيوف في الرابط غير صحيحة.',
    );
  }
  final id = state.pathParameters['id']!;
  return ResolvedRoute<Unit>(
    key: ValueKey(
      checkout
          ? 'checkout-$id-${state.uri.queryParameters['booking'] ?? ''}'
          : '${state.uri}',
    ),
    load: () => repo.unitById(id),
    builder: (unit) => checkout
        ? CheckoutPage(repo: repo, unit: unit, stay: stay, location: state.uri)
        : UnitPage(repo: repo, unit: unit, stay: stay, english: english),
  );
}

Widget bookingRoute(SakanRepository repo, GoRouterState state, bool chat) =>
    ResolvedRoute<Booking>(
      key: ValueKey(state.uri.toString()),
      load: () => repo.bookingById(state.pathParameters['id']!),
      builder: (b) => chat
          ? BookingChat(repo: repo, bookingId: b.id, bookingNumber: b.number)
          : BookingDetail(repo, b),
    );

class CustomerGuard extends StatefulWidget {
  final SakanRepository repo;
  final Widget Function() builder;
  const CustomerGuard({required this.repo, required this.builder, super.key});
  @override
  State<CustomerGuard> createState() => _CustomerGuardState();
}

class _CustomerGuardState extends State<CustomerGuard> {
  @override
  Widget build(BuildContext context) => widget.repo.signedIn
      ? widget.builder()
      : LoginPage(widget.repo, onAuthenticated: () => setState(() {}));
}
