import 'package:flutter/material.dart';
import '../core/models.dart';
import 'system.dart';

/// Pinned desktop header and independently scrolling rows; stacked mobile cards.
class ResponsiveRecords extends StatelessWidget {
  final List<Json> rows;
  final List<String> columns;
  final String Function(String) label;
  final Widget Function(String, Json) cell;
  final void Function(Json) open;
  final void Function(String) sort;
  final String? sorted;
  final bool ascending;
  const ResponsiveRecords({
    required this.rows,
    required this.columns,
    required this.label,
    required this.cell,
    required this.open,
    required this.sort,
    required this.sorted,
    required this.ascending,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      if (box.maxWidth < SakanLayout.tablet) {
        return ListView.separated(
          padding: const EdgeInsets.symmetric(vertical: 8),
          itemCount: rows.length,
          separatorBuilder: (_, i) => const SizedBox(height: 12),
          itemBuilder: (context, i) => Card(
            child: InkWell(
              borderRadius: BorderRadius.circular(18),
              onTap: () => open(rows[i]),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (final k in columns)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              label(k),
                              style: const TextStyle(
                                fontSize: 11,
                                color: Color(0xff5d685f),
                              ),
                            ),
                            const SizedBox(height: 4),
                            cell(k, rows[i]),
                          ],
                        ),
                      ),
                    Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: TextButton.icon(
                        onPressed: () => open(rows[i]),
                        icon: const Icon(Icons.arrow_forward, size: 18),
                        label: const Text('فتح السجل'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      }
      final width = (columns.length * 190.0 + 72).clamp(
        box.maxWidth,
        double.infinity,
      );
      return Card(
        clipBehavior: Clip.antiAlias,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: width,
            height: box.maxHeight,
            child: Column(
              children: [
                Container(
                  color: const Color(0xffedf1ec),
                  child: Row(
                    children: [
                      for (final k in columns)
                        Expanded(
                          child: TextButton(
                            onPressed: () => sort(k),
                            child: Row(
                              children: [
                                Expanded(child: Text(label(k))),
                                if (sorted == k)
                                  Icon(
                                    ascending
                                        ? Icons.arrow_upward
                                        : Icons.arrow_downward,
                                    size: 16,
                                  ),
                              ],
                            ),
                          ),
                        ),
                      const SizedBox(
                        width: 72,
                        child: Center(child: Text('إجراء')),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.separated(
                    itemCount: rows.length,
                    separatorBuilder: (_, i) => const Divider(height: 1),
                    itemBuilder: (context, i) => InkWell(
                      onTap: () => open(rows[i]),
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(minHeight: 72),
                        child: Row(
                          children: [
                            for (final k in columns)
                              Expanded(
                                child: Padding(
                                  padding: const EdgeInsets.all(14),
                                  child: cell(k, rows[i]),
                                ),
                              ),
                            SizedBox(
                              width: 72,
                              child: IconButton(
                                tooltip: 'فتح السجل',
                                onPressed: () => open(rows[i]),
                                icon: const Icon(Icons.chevron_left),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
