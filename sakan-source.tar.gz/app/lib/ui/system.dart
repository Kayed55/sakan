import 'package:flutter/material.dart';
import '../core/models.dart';

/// Logical pixels: Flutter's density-independent equivalent of responsive CSS.
abstract final class SakanLayout {
  static const compact = 600.0, tablet = 900.0, desktop = 1100.0;
  static const content = 1280.0, form = 720.0;
  static const gap = 16.0, radius = 16.0, touch = 48.0;
  static double gutter(BuildContext context) =>
      MediaQuery.sizeOf(context).width < compact ? 16 : 28;
  static EdgeInsets padding(BuildContext context) =>
      EdgeInsets.all(gutter(context));
}

/// Keeps the Navigator (including dialogs and sheets) inside device safe areas.
Widget sakanViewport(BuildContext context, Widget? child) =>
    SafeArea(child: child ?? const SizedBox.shrink());

class ContentFrame extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const ContentFrame({
    required this.child,
    this.maxWidth = SakanLayout.content,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.topCenter,
    child: ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: SizedBox(width: double.infinity, child: child),
    ),
  );
}

/// A route body with its own scrolling and a comfortable reading width.
class PageList extends StatelessWidget {
  final List<Widget> children;
  final double maxWidth;
  final EdgeInsetsGeometry? padding;
  const PageList({
    required this.children,
    this.maxWidth = SakanLayout.content,
    this.padding,
    super.key,
  });
  @override
  Widget build(BuildContext context) => ContentFrame(
    maxWidth: maxWidth,
    child: ListView(
      padding: padding ?? SakanLayout.padding(context),
      children: children,
    ),
  );
}

class FormSection extends StatelessWidget {
  final String title;
  final String? note;
  const FormSection(this.title, {this.note, super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: brand,
          ),
        ),
        if (note != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              note!,
              style: const TextStyle(color: Color(0xff5b6670), fontSize: 12),
            ),
          ),
        const Divider(),
      ],
    ),
  );
}

class StatusPill extends StatelessWidget {
  final String label;
  const StatusPill(this.label, {super.key});
  @override
  Widget build(BuildContext context) {
    final negative = RegExp(
      'ملغ|مرفوض|فشل|منتهي|موقوف|failed|cancelled|rejected|expired',
    ).hasMatch(label);
    final pending = RegExp(
      'معلق|مراجعة|مؤقت|انتظار|طلب|pending|hold|requested',
    ).hasMatch(label);
    final color = negative
        ? const Color(0xff963f3f)
        : pending
        ? const Color(0xff805719)
        : const Color(0xff4e5628);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        label,
        softWrap: true,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class PermissionView extends StatefulWidget {
  final Future<bool> Function() check;
  final Widget child;
  const PermissionView({required this.check, required this.child, super.key});
  @override
  State<PermissionView> createState() => _PermissionViewState();
}

class _PermissionViewState extends State<PermissionView> {
  late final Future<bool> permission = widget.check();
  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
    future: permission,
    builder: (_, s) => s.data == true ? widget.child : const SizedBox.shrink(),
  );
}

class MetricCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final bool compact;
  const MetricCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.compact,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(color: muted, fontSize: 13),
                  ),
                ),
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: brandCream,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: brand, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              value,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w500,
                color: brandInk,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Three equal progress tracks remain readable at 320 logical pixels.
class BookingProgress extends StatelessWidget {
  final int current;
  const BookingProgress(this.current, {super.key});
  @override
  Widget build(BuildContext context) => Row(
    children: [
      for (int i = 0; i < 3; i++)
        Expanded(
          child: Padding(
            padding: EdgeInsetsDirectional.only(end: i == 2 ? 0 : 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  height: 3,
                  decoration: BoxDecoration(
                    color: i <= current ? brand : outline,
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  '0${i + 1}  ${['مراجعة الحجز', 'بياناتك', 'الدفع'][i]}',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: i == current
                        ? FontWeight.w600
                        : FontWeight.w400,
                    color: i == current ? brandInk : muted,
                  ),
                ),
              ],
            ),
          ),
        ),
    ],
  );
}

class AccountLayout extends StatelessWidget {
  final Widget main, menu;
  final bool showDetail;
  final VoidCallback back;
  const AccountLayout({
    required this.main,
    required this.menu,
    required this.showDetail,
    required this.back,
    super.key,
  });
  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, box) {
      if (box.maxWidth >= 800) {
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(width: 280, child: menu),
            const SizedBox(width: 28),
            Expanded(child: main),
          ],
        );
      }
      if (!showDetail) return menu;
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: TextButton.icon(
              onPressed: back,
              icon: const Icon(Icons.arrow_forward),
              label: const Text('حسابي'),
            ),
          ),
          const SizedBox(height: 12),
          main,
        ],
      );
    },
  );
}

/// Desktop side panel / mobile full-width sheet, with persistent form actions.
class RecordSheet extends StatelessWidget {
  final Widget title, content;
  final List<Widget> actions;
  final bool scrollable;
  const RecordSheet({
    required this.title,
    required this.content,
    required this.actions,
    this.scrollable = true,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Dialog(
    alignment: AlignmentDirectional.centerEnd,
    insetPadding: EdgeInsets.zero,
    constraints: const BoxConstraints(maxWidth: 640),
    shape: const RoundedRectangleBorder(),
    backgroundColor: canvas,
    child: SafeArea(
      child: SizedBox(
        width: 640,
        height: MediaQuery.sizeOf(context).height,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
              child: Row(
                children: [
                  Expanded(
                    child: DefaultTextStyle(
                      style: Theme.of(context).textTheme.titleLarge!,
                      child: title,
                    ),
                  ),
                  IconButton(
                    tooltip: 'إغلاق',
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: content,
              ),
            ),
            const Divider(height: 1),
            ColoredBox(
              color: surface,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: OverflowBar(
                  spacing: 12,
                  overflowSpacing: 8,
                  alignment: MainAxisAlignment.end,
                  children: actions,
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
