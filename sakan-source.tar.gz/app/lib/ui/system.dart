import 'package:flutter/material.dart';
import '../core/models.dart';

/// Logical pixels: Flutter's density-independent equivalent of responsive CSS.
abstract final class SakanLayout {
  static const compact = 600.0, tablet = 900.0, desktop = 1100.0;
  static const content = 1240.0, form = 720.0;
  static const gap = 16.0, radius = 18.0, touch = 48.0;
  static double gutter(BuildContext context) =>
      MediaQuery.sizeOf(context).width < compact ? 16 : 28;
  static EdgeInsets padding(BuildContext context) =>
      EdgeInsets.all(gutter(context));
}

/// Keeps the Navigator (including dialogs and sheets) inside device safe areas.
Widget sakanViewport(BuildContext context, Widget? child) =>
    SafeArea(child: child ?? const SizedBox.shrink());

class ContentFrame extends StatelessWidget {
  final Widget child;
  final double maxWidth;
  const ContentFrame({
    required this.child,
    this.maxWidth = SakanLayout.content,
    super.key,
  });
  @override
  Widget build(BuildContext context) => Align(
    alignment: Alignment.topCenter,
    child: ConstrainedBox(
      constraints: BoxConstraints(maxWidth: maxWidth),
      child: SizedBox(width: double.infinity, child: child),
    ),
  );
}

/// A route body with its own scrolling and a comfortable reading width.
class PageList extends StatelessWidget {
  final List<Widget> children;
  final double maxWidth;
  final EdgeInsetsGeometry? padding;
  const PageList({
    required this.children,
    this.maxWidth = SakanLayout.content,
    this.padding,
    super.key,
  });
  @override
  Widget build(BuildContext context) => ContentFrame(
    maxWidth: maxWidth,
    child: ListView(
      padding: padding ?? SakanLayout.padding(context),
      children: children,
    ),
  );
}

class FormSection extends StatelessWidget {
  final String title;
  final String? note;
  const FormSection(this.title, {this.note, super.key});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 16),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w700,
            color: brand,
          ),
        ),
        if (note != null)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
              note!,
              style: const TextStyle(color: Color(0xff5d685f), fontSize: 12),
            ),
          ),
        const Divider(),
      ],
    ),
  );
}

class StatusPill extends StatelessWidget {
  final String label;
  const StatusPill(this.label, {super.key});
  @override
  Widget build(BuildContext context) {
    final negative = RegExp(
      'ملغ|مرفوض|فشل|منتهي|موقوف|failed|cancelled|rejected|expired',
    ).hasMatch(label);
    final pending = RegExp(
      'معلق|مراجعة|مؤقت|انتظار|طلب|pending|hold|requested',
    ).hasMatch(label);
    final color = negative
        ? const Color(0xff963f3f)
        : pending
        ? const Color(0xff805719)
        : brand;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(
        label,
        softWrap: true,
        style: TextStyle(
          color: color,
          fontSize: 12,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}

class PermissionView extends StatefulWidget {
  final Future<bool> Function() check;
  final Widget child;
  const PermissionView({required this.check, required this.child, super.key});
  @override
  State<PermissionView> createState() => _PermissionViewState();
}

class _PermissionViewState extends State<PermissionView> {
  late final Future<bool> permission = widget.check();
  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
    future: permission,
    builder: (_, s) => s.data == true ? widget.child : const SizedBox.shrink(),
  );
}

class MetricCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final bool compact;
  const MetricCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.compact,
    super.key,
  });
  @override
  Widget build(BuildContext context) {
    final symbol = Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xfff1f2e9),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(icon, color: brand, size: 22),
    );
    final copy = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: compact ? 26 : 28,
            fontWeight: FontWeight.w700,
            color: brand,
          ),
        ),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(color: Color(0xff5d685f))),
      ],
    );
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: compact
            ? Row(
                children: [
                  symbol,
                  const SizedBox(width: 16),
                  Expanded(child: copy),
                ],
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [symbol, const SizedBox(height: 20), copy],
              ),
      ),
    );
  }
}
