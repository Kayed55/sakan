import 'package:flutter/material.dart';
import 'core/bootstrap.dart';
import 'admin/app.dart';

Future<void> main() async {
  try {
    runApp(AdminApp(repo: await bootstrap()));
  } catch (e) {
    runApp(FailureApp(e));
  }
}
