import 'dart:async';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../core/models.dart';
import '../core/repository.dart';

String chatTime(dynamic value) {
  final d = DateTime.tryParse('$value')?.toLocal();
  return d == null
      ? ''
      : '${d.day}/${d.month}  ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
}

class BookingChat extends StatefulWidget {
  final SakanRepository repo;
  final String bookingId, bookingNumber;
  final bool support;
  const BookingChat({
    super.key,
    required this.repo,
    required this.bookingId,
    required this.bookingNumber,
    this.support = false,
  });
  @override
  State<BookingChat> createState() => _BookingChatState();
}

class _BookingChatState extends State<BookingChat> with WidgetsBindingObserver {
  final draft = TextEditingController();
  final scroll = ScrollController();
  List<Json> messages = [];
  Timer? timer;
  bool loading = true,
      fetching = false,
      sending = false,
      more = true,
      active = true;
  String? error, request, requestBody;
  int readId = 0;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    scroll.addListener(markRead);
    refresh();
    timer = Timer.periodic(const Duration(seconds: 3), (_) {
      if (visible) refresh();
    });
  }

  bool get visible =>
      active && mounted && (ModalRoute.of(context)?.isCurrent ?? true);
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    active = state == AppLifecycleState.resumed;
    if (active) refresh();
  }

  @override
  void dispose() {
    timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    draft.dispose();
    scroll.dispose();
    super.dispose();
  }

  void merge(List<Json> rows) {
    final byId = {
      for (final m in messages) m['id']: m,
      for (final m in rows) m['id']: m,
    };
    messages = byId.values.toList()
      ..sort((a, b) => (b['id'] as int).compareTo(a['id'] as int));
  }

  Future<void> refresh({bool older = false}) async {
    if (fetching) return;
    fetching = true;
    try {
      final rows = await widget.repo.chatMessages(
        widget.bookingId,
        before: older && messages.isNotEmpty
            ? messages.last['id'] as int
            : null,
      );
      if (!mounted) return;
      // Fill a polling gap before advancing the read watermark.
      final latestKnown = messages.isEmpty ? null : messages.first['id'] as int;
      if (!older && latestKnown != null && rows.length == 50) {
        var page = rows;
        while (page.isNotEmpty && (page.last['id'] as int) > latestKnown) {
          page = await widget.repo.chatMessages(
            widget.bookingId,
            before: page.last['id'] as int,
          );
          rows.addAll(page);
          if (!mounted) return;
        }
      }
      setState(() {
        if (older || loading) more = rows.length >= 50;
        merge(rows);
        loading = false;
        error = null;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) => markRead());
    } catch (_) {
      if (mounted) {
        setState(() {
          error = 'تعذر تحديث المحادثة. تحقق من اتصالك وأعد المحاولة.';
          loading = false;
        });
      }
    } finally {
      fetching = false;
    }
  }

  Future<void> markRead() async {
    if (!visible ||
        messages.isEmpty ||
        !scroll.hasClients ||
        scroll.offset > 40) {
      return;
    }
    final id = messages.first['id'] as int;
    if (id <= readId) return;
    readId = id;
    try {
      await widget.repo.readChat(widget.bookingId, id, support: widget.support);
    } catch (_) {
      readId = 0;
    }
  }

  Future<void> send() async {
    final body = draft.text.trim();
    if (sending || body.isEmpty) return;
    if (requestBody != body) {
      request = const Uuid().v4();
      requestBody = body;
    }
    setState(() => sending = true);
    try {
      final row = await widget.repo.sendChat(
        widget.bookingId,
        body,
        request!,
        support: widget.support,
      );
      if (!mounted) return;
      setState(() {
        merge([row]);
        draft.clear();
        request = null;
        requestBody = null;
        error = null;
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.jumpTo(0);
        markRead();
      });
    } catch (e) {
      if (mounted) {
        setState(
          () => error = e.toString().contains('CHAT_RATE_LIMIT')
              ? 'أرسلت رسائل كثيرة. انتظر دقيقة ثم أعد الإرسال.'
              : 'لم يتم تأكيد الإرسال. رسالتك محفوظة هنا، اضغط إرسال للمحاولة مجددًا.',
        );
      }
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(widget.support ? 'محادثة العميل' : 'خدمة عملاء سكن'),
          Text(
            'الحجز ${widget.bookingNumber}',
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    ),
    body: Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 850),
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.all(14),
              child: Text(
                'تواصل معنا بخصوص إقامتك. تُحدّث الرسائل تلقائيًا.',
                style: TextStyle(color: Colors.black54),
              ),
            ),
            if (error != null)
              MaterialBanner(
                content: Text(error!),
                actions: [
                  TextButton(
                    onPressed: () => refresh(),
                    child: const Text('تحديث'),
                  ),
                ],
              ),
            Expanded(
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : messages.isEmpty
                  ? const Center(
                      child: Text(
                        'كيف نقدر نخدمك؟\nاكتب رسالتك لبدء المحادثة.',
                        textAlign: TextAlign.center,
                      ),
                    )
                  : ListView.builder(
                      controller: scroll,
                      reverse: true,
                      padding: const EdgeInsets.all(16),
                      itemCount: messages.length + (more ? 1 : 0),
                      itemBuilder: (context, index) {
                        if (index == messages.length) {
                          return TextButton(
                            onPressed: () => refresh(older: true),
                            child: const Text('عرض رسائل أقدم'),
                          );
                        }
                        final m = messages[index];
                        final mine = widget.support
                            ? m['sender_kind'] == 'support'
                            : m['sender_kind'] == 'customer';
                        return Align(
                          alignment: mine
                              ? AlignmentDirectional.centerEnd
                              : AlignmentDirectional.centerStart,
                          child: Container(
                            constraints: BoxConstraints(
                              maxWidth:
                                  MediaQuery.sizeOf(
                                    context,
                                  ).width.clamp(0, 850) *
                                  .78,
                            ),
                            margin: const EdgeInsets.only(bottom: 12),
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: mine
                                  ? const Color(0xff234c3c)
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  m['sender_kind'] == 'support'
                                      ? 'خدمة العملاء'
                                      : 'العميل',
                                  style: TextStyle(
                                    fontSize: 11,
                                    color: mine
                                        ? Colors.white70
                                        : Colors.black54,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                SelectableText(
                                  '${m['body']}',
                                  style: TextStyle(
                                    color: mine ? Colors.white : Colors.black87,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  chatTime(m['created_at']),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: mine
                                        ? Colors.white70
                                        : Colors.black45,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: TextField(
                        controller: draft,
                        readOnly: sending,
                        minLines: 1,
                        maxLines: 4,
                        maxLength: 4000,
                        decoration: const InputDecoration(
                          hintText: 'اكتب رسالتك…',
                          counterText: '',
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    IconButton.filled(
                      tooltip: 'إرسال',
                      onPressed: sending ? null : send,
                      icon: sending
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.send),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}

class ChatInbox extends StatefulWidget {
  final SakanRepository repo;
  const ChatInbox(this.repo, {super.key});
  @override
  State<ChatInbox> createState() => _ChatInboxState();
}

class _ChatInboxState extends State<ChatInbox> {
  Timer? timer;
  List<Json> rows = [];
  bool busy = false, loading = true;
  String? error;
  int page = 0;
  @override
  void initState() {
    super.initState();
    load();
    timer = Timer.periodic(const Duration(seconds: 5), (_) {
      if ((ModalRoute.of(context)?.isCurrent ?? true) &&
          WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) {
        load();
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> load() async {
    if (busy) return;
    busy = true;
    try {
      final data = await widget.repo.chatInbox(offset: page * 50);
      if (mounted) {
        setState(() {
          rows = data;
          loading = false;
          error = null;
        });
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          error = 'تعذر تحميل المحادثات';
          loading = false;
        });
      }
    } finally {
      busy = false;
    }
  }

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            const Expanded(
              child: Text(
                'محادثات الحجوزات',
                style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
            ),
            IconButton(
              onPressed: load,
              tooltip: 'تحديث',
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
      ),
      if (error != null) Text(error!),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : rows.isEmpty
            ? const Center(
                child: Text(
                  'لا توجد محادثات هنا بعد.\nستظهر رسالة العميل الأولى تلقائيًا.',
                  textAlign: TextAlign.center,
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: rows.length,
                itemBuilder: (context, i) {
                  final r = rows[i];
                  return Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(18),
                      leading: const CircleAvatar(
                        child: Icon(Icons.support_agent),
                      ),
                      title: Text(
                        '${r['customer_name']} · ${r['booking_number']}',
                      ),
                      subtitle: Text(
                        '${r['body']}\n${chatTime(r['created_at'])}',
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                      trailing: (r['unread_count'] as num) > 0
                          ? Badge(
                              label: Text('${r['unread_count']}'),
                              child: const Icon(Icons.chat_bubble_outline),
                            )
                          : const Icon(Icons.chevron_left),
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => BookingChat(
                              repo: widget.repo,
                              bookingId: r['booking_id'],
                              bookingNumber: r['booking_number'],
                              support: true,
                            ),
                          ),
                        );
                        load();
                      },
                    ),
                  );
                },
              ),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextButton(
            onPressed: page > 0 && !busy
                ? () {
                    setState(() => page--);
                    load();
                  }
                : null,
            child: const Text('السابق'),
          ),
          Text('${page + 1}'),
          TextButton(
            onPressed: rows.length == 50 && !busy
                ? () {
                    setState(() => page++);
                    load();
                  }
                : null,
            child: const Text('التالي'),
          ),
        ],
      ),
    ],
  );
}
